#!/usr/bin/env sh
# chromium_download_ccache.sh
# Download the ccache prebuilt binary from the official GitHub releases to <dest>.
#
# Uses the "musl-static" variant, which is a fully static binary (no glibc
# dependency), so it runs on any Linux distribution / glibc version. This
# sidesteps the glibc-matching problem when compiling Chromium on older Linux.
#
# - Single download attempt with a 120s timeout (no retry).
# - Skips downloading if <dest> already exists and is executable; if the
#   installed version is older than the latest release, it only prints a notice.

set -eu

chromium_download_ccache_usage() {
  cat <<'USAGE'
Usage: chromium_download_ccache.sh [dest] [--help]

Download the ccache prebuilt binary from the official GitHub releases to <dest>.

Arguments:
  dest       Path to the ccache binary (default: init_tools/ccache/ccache)
  -h, --help Show this help.

Behavior:
  - Uses the "musl-static" (fully static, glibc-independent) variant.
  - Single download attempt with a 120s timeout (no retry).
  - Skips downloading if <dest> already exists and is executable; if the
    installed version is older than the latest release, only prints a notice.
USAGE
}

case "${1:-}" in
  -h | --help)
    chromium_download_ccache_usage
    exit 0
    ;;
esac

dest="${1:-init_tools/ccache/ccache}"

api_url="https://api.github.com/repos/ccache/ccache/releases/latest"

# Already installed: skip download, only check for a newer version.
if [ -x "$dest" ]; then
  echo "ccache already exists: $dest"
  local_ver=$("$dest" --version 2>/dev/null | head -1 | awk '{print $3}')
  latest_tag=$(curl -fsSL --max-time 120 "$api_url" 2>/dev/null \
        | sed -n 's/.*"tag_name":[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)
  if [ -n "$local_ver" ] && [ -n "$latest_tag" ]; then
    latest_ver="${latest_tag#v}"
    if [ "$local_ver" != "$latest_ver" ]; then
      newer=$(printf '%s\n%s\n' "$local_ver" "$latest_ver" | sort -V | tail -1)
      if [ "$newer" = "$latest_ver" ]; then
        echo "NOTE: a newer ccache version is available: $latest_ver (installed: $local_ver)"
      fi
    fi
  fi
  exit 0
fi

# Detect architecture and map to ccache's asset arch name.
arch=$(uname -m)
case "$arch" in
  x86_64) cc_arch="x86_64" ;;
  aarch64 | arm64) cc_arch="aarch64" ;;
  riscv64) cc_arch="riscv64" ;;
  *)
    echo "Error: unsupported architecture: $arch" >&2
    exit 1
    ;;
esac

# musl-static = fully static binary, glibc-independent.
libc="musl-static"

glibc_ver=$(ldd --version 2>/dev/null | head -1 | awk '{print $NF}')
[ -n "$glibc_ver" ] || glibc_ver="unknown"
echo "arch=$cc_arch glibc=$glibc_ver libc=$libc (static, glibc-independent)"

# Query the latest release tag via the GitHub API (120s timeout, no retry).
tag=$(curl -fsSL --max-time 120 "$api_url" 2>/dev/null \
      | sed -n 's/.*"tag_name":[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)
if [ -z "$tag" ]; then
  echo "Warning: failed to query latest ccache release (120s timeout)" >&2
  exit 1
fi

version="${tag#v}"
asset="ccache-${version}-linux-${cc_arch}-${libc}.tar.xz"
url="https://github.com/ccache/ccache/releases/download/${tag}/${asset}"

tmpdir=$(mktemp -d)
tarball="$tmpdir/ccache.tar.xz"
trap 'rm -rf "$tmpdir"' EXIT

echo "downloading $url"
if ! curl -fSL --max-time 120 -o "$tarball" "$url"; then
  echo "Warning: ccache download failed or timed out (120s), skipped" >&2
  exit 1
fi

mkdir -p "$(dirname "$dest")"

tar -xf "$tarball" -C "$tmpdir"
bin=$(find "$tmpdir" -maxdepth 2 -type f -name ccache | head -1)
if [ -z "$bin" ]; then
  echo "Warning: ccache binary not found in archive" >&2
  exit 1
fi

cp "$bin" "$dest"
chmod 755 "$dest"

if "$dest" --version >/dev/null 2>&1; then
  echo "ccache installed: $dest ($("$dest" --version | head -1))"
else
  echo "Warning: downloaded ccache does not run on this system" >&2
  rm -f "$dest"
  exit 1
fi
