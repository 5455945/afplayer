#!/usr/bin/env sh
# chromium_build_crashpad.sh
# Build dump_syms and minidump_stackwalk (Chromium host tools) and copy them
# into <tools_dir>. If both binaries already exist, the build is skipped.
#
# The build is done for the host architecture (no target arch is specified).
# On success, generates <tools_dir>/crashpad.sh (only if it does not exist).

set -eu

chromium_build_crashpad_usage() {
  cat <<'USAGE'
Usage: chromium_build_crashpad.sh [tools_dir] [--help]

Build dump_syms and minidump_stackwalk for the host architecture and copy them
into <tools_dir>. If both binaries already exist, the build is skipped.

Arguments:
  tools_dir   Base directory (default: init_tools/tools).
              Expected layout: .../init_tools/<major>/tools
                - depot_tools is derived as <tools_dir>/../depot_tools
                - src root is derived as <tools_dir>/../../..
  -h, --help  Show this help.

On success, generates <tools_dir>/crashpad.sh (only if it does not exist yet).
USAGE
}

case "${1:-}" in
  -h | --help)
    chromium_build_crashpad_usage
    exit 0
    ;;
esac

tools_dir="${1:-init_tools/tools}"
case "$tools_dir" in
  /*) ;;
  *) tools_dir="$PWD/$tools_dir" ;;
esac
tools_dir="${tools_dir%/}"

dump_syms_dest="$tools_dir/dump_syms"
minidump_stackwalk_dest="$tools_dir/minidump_stackwalk"
crashpad_sh="$tools_dir/crashpad.sh"

# Derive src + depot_tools from tools_dir (tools_dir = <src>/init_tools/<major>/tools).
# Do NOT source env.sh here: env.sh self-locates via $0/BASH_SOURCE, which resolves
# to this script's own path when sourced from a non-bash shell (dash), yielding a
# wrong CHROMIUM_SRC.
CHROMIUM_SRC="$(dirname "$(dirname "$(dirname "$tools_dir")")")"
depot_tools_dir="$(dirname "$tools_dir")/depot_tools"

# Set up the toolchain PATH (depot_tools + gn + ninja) so gn/ninja/autoninja are found.
export PATH="$depot_tools_dir:$CHROMIUM_SRC/buildtools/linux64:$CHROMIUM_SRC/third_party/ninja:$PATH"
GN="$CHROMIUM_SRC/buildtools/linux64/gn"

build_dir="out/host_tools"

# Map host arch to the Chromium sysroot arch name.
case "$(uname -m)" in
  x86_64 | amd64) sysroot_arch="amd64" ;;
  aarch64 | arm64) sysroot_arch="arm64" ;;
  armv7l | armhf) sysroot_arch="arm" ;;
  *) sysroot_arch="" ;;
esac

if [ -x "$dump_syms_dest" ] && [ -x "$minidump_stackwalk_dest" ]; then
  echo "dump_syms and minidump_stackwalk already exist, skip build"
else
  cd "$CHROMIUM_SRC"

  gn_bin="${GN:-$CHROMIUM_SRC/buildtools/linux64/gn}"
  [ -x "$gn_bin" ] || { echo "Error: gn not found: $gn_bin" >&2; exit 1; }

  # gn gen requires the host sysroot; install it if missing.
  if [ -n "$sysroot_arch" ]; then
    sysroot_dir="$CHROMIUM_SRC/build/linux/debian_bullseye_${sysroot_arch}-sysroot"
    if [ ! -d "$sysroot_dir" ]; then
      echo "installing host sysroot: $sysroot_arch"
      "$CHROMIUM_SRC/build/linux/sysroot_scripts/install-sysroot.py" --arch="$sysroot_arch"
    fi
  fi

  # Re-run gn gen whenever build.ninja is missing (args.gn alone is not enough).
  if [ ! -f "$build_dir/build.ninja" ]; then
    echo "$gn_bin gen $build_dir --args='is_debug=false'"
    "$gn_bin" gen "$build_dir" --args='is_debug=false'
  fi

  echo "autoninja -C $build_dir dump_syms minidump_stackwalk"
  autoninja -C "$build_dir" dump_syms minidump_stackwalk

  mkdir -p "$tools_dir"
  echo "cp $build_dir/dump_syms $dump_syms_dest"
  cp "$build_dir/dump_syms" "$dump_syms_dest"
  chmod 755 "$dump_syms_dest"
  echo "cp $build_dir/minidump_stackwalk $minidump_stackwalk_dest"
  cp "$build_dir/minidump_stackwalk" "$minidump_stackwalk_dest"
  chmod 755 "$minidump_stackwalk_dest"
  echo "installed: $dump_syms_dest"
  echo "installed: $minidump_stackwalk_dest"
fi

if [ -x "$dump_syms_dest" ] && [ -x "$minidump_stackwalk_dest" ] && [ ! -f "$crashpad_sh" ]; then
  cat > "$crashpad_sh" <<'CRASHPAD_EOF'
#!/bin/bash

# =====================================================================
# Generate tools dump_syms and minidump_stackwalk in build.sh
# autoninja -j$jobs -C $OUTPUT_DIR $target_apk_webview domono_shell_apk minidump_stackwalk dump_syms || exit 1
# =====================================================================

if [ "$#" -lt 2 ]; then
    echo "error: Missing parameter."
    echo "usage: $0 <dump_file.dmp> <lib_path.so> [options]"
    echo "sample 32: $0 crash.dmp ./android_clang_arm/lib.unstripped/libwebviewchromium.so -c"
        echo "sample 64: $0 crash.dmp ./lib.unstripped/libwebviewchromium.so -c"
        echo "sample 64: $0 crash.dmp ./lib.unstripped/libwebviewchromium.so"
    exit 1
fi


DUMP_FILE="$1"
LIB_FILE="$2"
MODULE_NAME=$(basename "$LIB_FILE")
#echo "MODULE_NAME: ${MODULE_NAME}"


shift 2

if [[ ! "$DUMP_FILE" =~ \.[dD][mM][pP]$ ]]; then
    echo "Error: The first parameter must be a. dmp file."
    echo "Current input: $DUMP_FILE"
    exit 1
fi

if [[ ! "$LIB_FILE" =~ \.[sS][oO]$ ]]; then
    echo "Error: The second parameter must be a. so dynamic library file."
    echo "Current input: $LIB_FILE"
    exit 1
fi


if [ ! -f "$DUMP_FILE" ]; then
    echo "Error: Dump file not found: $DUMP_FILE"
    echo "Please check if the path is correct (supports relative or absolute paths)."
    exit 1
fi

if [ ! -f "$LIB_FILE" ]; then
    echo "Error: Dump file not found: $LIB_FILE"
    echo "Please check if the path is correct (supports relative or absolute paths)."
    exit 1
fi

echo "----------------------------------------"
echo "Dump file   : $DUMP_FILE"
echo "symbols file: $LIB_FILE"
echo "----------------------------------------"

OPT_CRASH_ONLY=false

while getopts "mscb" opt; do
    case $opt in
        c)
            OPT_CRASH_ONLY=true
            echo "[Option] Enable: Only display crashing threads (-c)"
            ;;
        h)
            echo "usage: $0 <dump.dmp> <lib.so> [-c] "
            echo "  -c : Output thread that causes crash or dump only"
            exit 0
            ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            exit 1
            ;;
    esac
done

shift $((OPTIND - 1))

OUTPUT_FILE="crashpad_report.txt"
if [ "$#" -gt 0 ]; then
    OUTPUT_FILE="$1"
    echo "Output file specified: $OUTPUT_FILE"
else
    echo "Using default output file: $OUTPUT_FILE"
fi

ARGS=""
if [ "$OPT_CRASH_ONLY" = true ]; then
    ARGS="$ARGS -c"
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SYMBOLS_DIR=syms_tmp
DUMP_SYMS="${SCRIPT_DIR}/dump_syms"
MINIDUMP_STACKWALK="${SCRIPT_DIR}/minidump_stackwalk"

echo "start time:$(date '+%Y-%m-%d %H:%M:%S')"

cur_dir=$(pwd)

DEBUG_ID=$("$DUMP_SYMS" -i "$LIB_FILE" | awk '/^MODULE/ {print $4}')

echo "mkdir -p \"${cur_dir}/${SYMBOLS_DIR}/${MODULE_NAME}/${DEBUG_ID}\""
mkdir -p "${cur_dir}/${SYMBOLS_DIR}/${MODULE_NAME}/${DEBUG_ID}"

echo "${DUMP_SYMS} $LIB_FILE > ${SYMBOLS_DIR}/${MODULE_NAME}/${DEBUG_ID}/${MODULE_NAME}.sym"
${DUMP_SYMS} ${LIB_FILE} > ${SYMBOLS_DIR}/${MODULE_NAME}/${DEBUG_ID}/${MODULE_NAME}.sym

echo "\"${MINIDUMP_STACKWALK}\" $ARGS ${DUMP_FILE} ${SYMBOLS_DIR}/ > \"${OUTPUT_FILE}\" 2>&1"
"${MINIDUMP_STACKWALK}" $ARGS ${DUMP_FILE} ${SYMBOLS_DIR}/ > "${OUTPUT_FILE}" 2>&1

echo rm "${SYMBOLS_DIR}/${MODULE_NAME}/${DEBUG_ID}/${MODULE_NAME}.sym"
rm -rf "${SYMBOLS_DIR}/${MODULE_NAME}/${DEBUG_ID}/${MODULE_NAME}.sym"

echo "======: The analysis results are in file \"${OUTPUT_FILE}\""

echo "end time $(date '+%Y-%m-%d %H:%M:%S')"
CRASHPAD_EOF
  chmod 755 "$crashpad_sh"
  echo "created: $crashpad_sh"
fi
