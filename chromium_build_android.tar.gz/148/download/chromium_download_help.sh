#!/usr/bin/env sh
# chromium_download_help.sh

chromium_download_usage() {
  cat <<'USAGE'
Usage: <your-script> [options]

Options:
  -b, --branch <branch>      Chromium branch number, e.g. 7778.
                             Default: 7778

  -t, --target-os <os>       gclient target_os.
                             Supported formats:
                               linux,android
                               ['linux', 'android']
                             Default: linux,android

  -a, --abs-dir <dir>        Base directory.
                             If it starts with /, it is used as an absolute path.
                             Otherwise it is under $HOME.
                             Default: workspace1

  -r, --rel-dir <dir>        Extra relative directory under base dir.
                             Use --rel-dir= if you want it empty.
                             Default: git2

  -s, --src-name <name>      Rename the src checkout directory to <name>
                              after the download and commits complete.
                              <name> must be a plain directory name
                              (not a path). Default: src (no rename).

  --skip-rm-bak              Keep git.bak and gitignore.bak directories
                              (do not clean them up after committing).

  --sync-retry <n>           Retry gclient sync on failure <n> times.
                              Default: 3

  -h, --help                 Show this help.

Examples:
  ./chromium_download.sh --help

  ./chromium_download.sh \
    --branch 7778 \
    --target-os linux,android \
    --abs-dir workspace1 \
    --rel-dir git2 \
    --src-name chromium

  ./chromium_download.sh \
    -b 7778 \
    -t linux,android \
    -a workspace1 \
    -r git2 \
    -s chromium
USAGE
}

_chromium_download_error() {
  echo "Error: $1" >&2
  echo >&2
  chromium_download_usage >&2
  exit 1
}

chromium_download_normalize_target_os() {
  # Trim leading/trailing whitespace
  git_target_os=$(printf '%s' "$git_target_os" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

  # If the user already passed a Python list like ['linux', 'android'], leave it as-is
  case "$git_target_os" in
    \[*\])
      return 0
      ;;
  esac

  # Convert linux,android into ['linux', 'android']
  _cb_old_ifs=$IFS
  IFS=','

  _cb_result="["
  _cb_first=1

  for _cb_item in $git_target_os; do
    _cb_item=$(printf '%s' "$_cb_item" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

    if [ -z "$_cb_item" ]; then
      continue
    fi

    if [ "$_cb_first" -eq 1 ]; then
      _cb_result="$_cb_result'$_cb_item'"
      _cb_first=0
    else
      _cb_result="$_cb_result, '$_cb_item'"
    fi
  done

  IFS=$_cb_old_ifs

  _cb_result="$_cb_result]"
  git_target_os=$_cb_result
}

chromium_download_validate() {
  case "$git_branch" in
    '' | *[!0-9]*)
      _chromium_download_error "--branch must be numeric, e.g. 7778. Current value: '$git_branch'"
      ;;
  esac

  if [ -z "$abs_dir" ]; then
    _chromium_download_error "--abs-dir cannot be empty"
  fi

  if [ "$git_target_os" = "[]" ]; then
    _chromium_download_error "--target-os cannot be empty"
  fi

  # src_name must be a plain directory name, not a path
  case "$src_name" in
    '' ) ;;
    '.' | '..' )
      _chromium_download_error "--src-name must be a plain directory name: '$src_name'"
      ;;
    */* | *\\* )
      _chromium_download_error "--src-name must be a plain directory name, not a path: '$src_name'"
      ;;
  esac

  case "$sync_retry" in
    '' | *[!0-9]*)
      _chromium_download_error "--sync-retry must be numeric, e.g. 3. Current value: '$sync_retry'"
      ;;
  esac
}

chromium_download_compute_dirs() {
  # If abs_dir is absolute, use it directly; otherwise put it under $HOME
  case "$abs_dir" in
    /*)
      _cb_base_dir=$abs_dir
      ;;
    *)
      _cb_base_dir="$HOME/$abs_dir"
      ;;
  esac

  root_dir=$_cb_base_dir

  if [ -n "$rel_dir" ]; then
    root_dir="$root_dir/$rel_dir"
  fi

  # The directory where gclient actually downloads the Chromium source
  src_dir="$root_dir/src"

  export git_branch
  export git_target_os
  export abs_dir
  export rel_dir
  export root_dir
  export src_dir
  export src_name
  export skip_rm_bak
  export sync_retry
}

chromium_download_parse_args() {
  # Defaults
  # ${VAR:-default} is used here, so environment variable presets are also supported
  git_branch=${git_branch:-7778}
  git_target_os=${git_target_os:-linux,android}
  abs_dir=${abs_dir:-workspace1}
  rel_dir=${rel_dir:-git2}
  src_name=${src_name:-}
  skip_rm_bak=${skip_rm_bak:-false}
  sync_retry=${sync_retry:-3}

  while [ $# -gt 0 ]; do
    case "$1" in
      -h | --help)
        chromium_download_usage
        exit 0
        ;;

      -b | --branch)
        if [ $# -lt 2 ] || [ -z "$2" ]; then
          _chromium_download_error "option '$1' requires a non-empty value"
        fi
        git_branch=$2
        shift 2
        ;;

      --branch=*)
        git_branch=${1#--branch=}
        if [ -z "$git_branch" ]; then
          _chromium_download_error "--branch requires a non-empty value"
        fi
        shift
        ;;

      -t | --target-os)
        if [ $# -lt 2 ] || [ -z "$2" ]; then
          _chromium_download_error "option '$1' requires a non-empty value"
        fi
        git_target_os=$2
        shift 2
        ;;

      --target-os=*)
        git_target_os=${1#--target-os=}
        if [ -z "$git_target_os" ]; then
          _chromium_download_error "--target-os requires a non-empty value"
        fi
        shift
        ;;

      -a | --abs-dir)
        if [ $# -lt 2 ] || [ -z "$2" ]; then
          _chromium_download_error "option '$1' requires a non-empty value"
        fi
        abs_dir=$2
        shift 2
        ;;

      --abs-dir=*)
        abs_dir=${1#--abs-dir=}
        if [ -z "$abs_dir" ]; then
          _chromium_download_error "--abs-dir requires a non-empty value"
        fi
        shift
        ;;

      -r | --rel-dir)
        if [ $# -lt 2 ]; then
          _chromium_download_error "option '$1' requires a value, use empty string if needed"
        fi
        rel_dir=$2
        shift 2
        ;;

      --rel-dir=*)
        rel_dir=${1#--rel-dir=}
        shift
        ;;

      -s | --src-name)
        if [ $# -lt 2 ] || [ -z "$2" ]; then
          _chromium_download_error "option '$1' requires a non-empty value"
        fi
        src_name=$2
        shift 2
        ;;

      --src-name=*)
        src_name=${1#--src-name=}
        if [ -z "$src_name" ]; then
          _chromium_download_error "--src-name requires a non-empty value"
        fi
        shift
        ;;

      --skip-rm-bak)
        skip_rm_bak=true
        shift
        ;;

      --sync-retry)
        if [ $# -lt 2 ] || [ -z "$2" ]; then
          _chromium_download_error "option '$1' requires a non-empty value"
        fi
        sync_retry=$2
        shift 2
        ;;

      --sync-retry=*)
        sync_retry=${1#--sync-retry=}
        if [ -z "$sync_retry" ]; then
          _chromium_download_error "--sync-retry requires a non-empty value"
        fi
        shift
        ;;

      *)
        _chromium_download_error "unknown argument: $1"
        ;;
    esac
  done

  chromium_download_normalize_target_os
  chromium_download_validate
  chromium_download_compute_dirs
}

# If chromium_download_help.sh is executed directly, only show the help
if [ "${0##*/}" = "chromium_download_help.sh" ]; then
  chromium_download_usage
  exit 0
fi

