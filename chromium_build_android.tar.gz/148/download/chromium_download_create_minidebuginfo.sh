#!/usr/bin/env sh
# chromium_download_create_minidebuginfo.sh
# Download create_minidebuginfo (and its libc++.so dependency) from AOSP
# prebuilts/build-tools to <tools_dir>.
#
# - Single download attempt with a 120s timeout (no retry).
# - Skips downloading if both files already exist; if the locally recorded
#   AOSP build-tools HEAD commit is older than the latest, only prints a notice.

set -eu

chromium_download_create_minidebuginfo_usage() {
  cat <<'USAGE'
Usage: chromium_download_create_minidebuginfo.sh [tools_dir] [--help]

Download create_minidebuginfo (and its libc++.so dependency) from AOSP
prebuilts/build-tools.

Arguments:
  tools_dir   Base directory (default: init_tools/tools).
              - binary: <tools_dir>/create_minidebuginfo
              - libc++: <tools_dir>/lib64/libc++.so
  -h, --help  Show this help.

Behavior:
  - Single download attempt with a 120s timeout (no retry).
  - Skips downloading if both files already exist; if the local version is
    older than the latest, only prints a notice.
USAGE
}

case "${1:-}" in
  -h | --help)
    chromium_download_create_minidebuginfo_usage
    exit 0
    ;;
esac

tools_dir="${1:-init_tools/tools}"

bin_dest="$tools_dir/create_minidebuginfo"
lib_dest="$tools_dir/lib64/libc++.so"
ver_file="$tools_dir/.create_minidebuginfo.version"

repo="https://android.googlesource.com/platform/prebuilts/build-tools"
bin_url="$repo/+/refs/heads/master/linux-x86/bin/create_minidebuginfo?format=TEXT"
lib_url="$repo/+/refs/heads/master/linux-x86/lib64/libc++.so?format=TEXT"
log_url="$repo/+log/refs/heads/master/?format=JSON&n=1"

# Derive the major version from tools_dir: .../init_tools/<major>/tools
major_version=$(basename "$(dirname "$tools_dir")")
case "$major_version" in
  '' | *[!0-9]*) major_version="128" ;;
esac

# Write the usage/documentation file if it does not exist yet.
md_file="$tools_dir/create_minidebuginfo.md"
if [ ! -f "$md_file" ]; then
  mkdir -p "$tools_dir"
  cat > "$md_file" <<EOF
aosp/prebuilts/build-tools/linux-x86/bin/create_minidebuginfo
aosp/prebuilts/build-tools/linux-x86/lib64/libc++.so


./third_party/llvm-build/Release+Asserts/bin/llvm-strip --strip-all --keep-section=.ARM.attributes --remove-section=.comment out/DefaultSys/lib.unstripped/libwebviewchromium.so -o out/DefaultSys/libwebviewchromium.so.tmp
./third_party/llvm-build/Release+Asserts/bin/llvm-objcopy --decompress-debug-sections out/DefaultSys/lib.unstripped/libwebviewchromium.so out/DefaultSys/libwebviewchromium.so.dec
./init_tools/${major_version}/tools/create_minidebuginfo out/DefaultSys/libwebviewchromium.so.dec out/DefaultSys/libwebviewchromium.so.mini_debuginfo.xz
./third_party/llvm-build/Release+Asserts/bin/llvm-objcopy --add-section .gnu_debugdata=out/DefaultSys/libwebviewchromium.so.mini_debuginfo.xz out/DefaultSys/libwebviewchromium.so.tmp out/DefaultSys/libwebviewchromium.so
rm -f out/DefaultSys/libwebviewchromium.so.tmp out/DefaultSys/libwebviewchromium.so.dec out/DefaultSys/libwebviewchromium.so.mini_debuginfo.xz

./third_party/llvm-build/Release+Asserts/bin/llvm-strip --strip-all --keep-section=.ARM.attributes --remove-section=.comment out/DefaultSys/exe.unstripped/libcrashpad_handler_trampoline.so -o out/DefaultSys/libcrashpad_handler_trampoline.so.tmp
./third_party/llvm-build/Release+Asserts/bin/llvm-objcopy --decompress-debug-sections out/DefaultSys/exe.unstripped/libcrashpad_handler_trampoline.so out/DefaultSys/libcrashpad_handler_trampoline.so.dec
./init_tools/${major_version}/tools/create_minidebuginfo out/DefaultSys/libcrashpad_handler_trampoline.so.dec out/DefaultSys/libcrashpad_handler_trampoline.so.mini_debuginfo.xz
./third_party/llvm-build/Release+Asserts/bin/llvm-objcopy --add-section .gnu_debugdata=out/DefaultSys/libcrashpad_handler_trampoline.so.mini_debuginfo.xz out/DefaultSys/libcrashpad_handler_trampoline.so.tmp out/DefaultSys/libcrashpad_handler_trampoline.so
rm -f out/DefaultSys/libcrashpad_handler_trampoline.so.tmp out/DefaultSys/libcrashpad_handler_trampoline.so.dec out/DefaultSys/libcrashpad_handler_trampoline.so.mini_debuginfo.xz

./third_party/llvm-build/Release+Asserts/bin/llvm-strip --strip-all --keep-section=.ARM.attributes --remove-section=.comment out/DefaultSys/android_clang_arm/lib.unstripped/libwebviewchromium.so -o out/DefaultSys/android_clang_arm/libwebviewchromium.so.tmp
./third_party/llvm-build/Release+Asserts/bin/llvm-objcopy --decompress-debug-sections out/DefaultSys/android_clang_arm/lib.unstripped/libwebviewchromium.so out/DefaultSys/android_clang_arm/libwebviewchromium.so.dec
./init_tools/${major_version}/tools/create_minidebuginfo out/DefaultSys/android_clang_arm/libwebviewchromium.so.dec out/DefaultSys/android_clang_arm/libwebviewchromium.so.mini_debuginfo.xz
./third_party/llvm-build/Release+Asserts/bin/llvm-objcopy --add-section .gnu_debugdata=out/DefaultSys/android_clang_arm/libwebviewchromium.so.mini_debuginfo.xz out/DefaultSys/android_clang_arm/libwebviewchromium.so.tmp out/DefaultSys/android_clang_arm/libwebviewchromium.so
rm -f out/DefaultSys/android_clang_arm/libwebviewchromium.so.tmp out/DefaultSys/android_clang_arm/libwebviewchromium.so.dec out/DefaultSys/android_clang_arm/libwebviewchromium.so.mini_debuginfo.xz

./third_party/llvm-build/Release+Asserts/bin/llvm-strip --strip-all --keep-section=.ARM.attributes --remove-section=.comment out/DefaultSys/android_clang_arm/exe.unstripped/libcrashpad_handler_trampoline.so -o out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so.tmp
./third_party/llvm-build/Release+Asserts/bin/llvm-objcopy --decompress-debug-sections out/DefaultSys/android_clang_arm/exe.unstripped/libcrashpad_handler_trampoline.so out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so.dec
./init_tools/${major_version}/tools/create_minidebuginfo out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so.dec out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so.mini_debuginfo.xz
./third_party/llvm-build/Release+Asserts/bin/llvm-objcopy --add-section .gnu_debugdata=out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so.mini_debuginfo.xz out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so.tmp out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so
rm -f out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so.tmp out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so.dec out/DefaultSys/android_clang_arm/libcrashpad_handler_trampoline.so.mini_debuginfo.xz
EOF
  echo "created: $md_file"
fi

# Fetch the latest HEAD commit SHA of the AOSP build-tools repo (version id).
fetch_latest_sha() {
  curl -fsSL --max-time 120 "$log_url" 2>/dev/null \
    | sed "1s/^)]}'//" \
    | grep -oE '"commit": *"[a-f0-9]+"' \
    | head -1 \
    | grep -oE '[a-f0-9]{40}' \
    | head -1
}

# Download a gitiles base64 object and decode it to <dest>.
download_decode() {
  # $1 = url, $2 = dest
  local url="$1" dest="$2" tmp
  tmp=$(mktemp)
  if ! curl -fSL --max-time 120 -o "$tmp" "$url"; then
    rm -f "$tmp"
    return 1
  fi
  if ! base64 -d "$tmp" > "$dest" 2>/dev/null; then
    rm -f "$tmp"
    return 1
  fi
  rm -f "$tmp"
  return 0
}

if [ -x "$bin_dest" ] && [ -f "$lib_dest" ]; then
  echo "create_minidebuginfo already exists: $bin_dest"
  latest_sha=$(fetch_latest_sha)
  local_sha=""
  [ -f "$ver_file" ] && local_sha=$(cat "$ver_file")
  if [ -n "$local_sha" ] && [ -n "$latest_sha" ] && [ "$local_sha" != "$latest_sha" ]; then
    echo "NOTE: a newer create_minidebuginfo is available (commit $latest_sha, installed: $local_sha)"
  fi
  exit 0
fi

mkdir -p "$tools_dir/lib64"

echo "downloading $bin_url"
if ! download_decode "$bin_url" "$bin_dest"; then
  echo "Warning: create_minidebuginfo download failed or timed out (120s)" >&2
  exit 1
fi
chmod 755 "$bin_dest"

echo "downloading $lib_url"
if ! download_decode "$lib_url" "$lib_dest"; then
  echo "Warning: libc++.so download failed or timed out (120s)" >&2
  exit 1
fi

# Verify the binary can load its libc++.so dependency.
load_err=$(LD_LIBRARY_PATH="$tools_dir/lib64" "$bin_dest" 2>&1 || true)
if printf '%s' "$load_err" | grep -q "error while loading shared libraries"; then
  echo "Warning: downloaded create_minidebuginfo failed to load: $load_err" >&2
  exit 1
fi

latest_sha=$(fetch_latest_sha)
[ -n "$latest_sha" ] && printf '%s\n' "$latest_sha" > "$ver_file"

echo "create_minidebuginfo installed: $bin_dest"
echo "libc++.so installed: $lib_dest"
