#!/usr/bin/env sh

set -eu

git_branch=7778
git_target_os="['linux', 'android']"

# A link under a root directory, usable as an absolute path (parameter)
abs_dir=workspace1
# Relative directory (parameter, may contain multiple levels)
rel_dir="git2"
# Working directory
root_dir="$HOME/$abs_dir"
if [ "$rel_dir" != "" ]; then
  root_dir="$HOME/$abs_dir/$rel_dir"
fi

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

# Source the argument parsing script
. "$SCRIPT_DIR/chromium_download_help.sh"

# Parse command-line arguments
chromium_download_parse_args "$@"

# If running from the committed copies under src, they will be deleted by the
# git checkout during download. Relocate them to a safe temp dir first.
case "$SCRIPT_DIR" in
  "$src_dir"/*)
    _reloc_dir="/tmp/chromium_scripts"
    rm -rf "$_reloc_dir"
    mkdir -p "$_reloc_dir"
    for _rs in chromium_download.sh chromium_download_help.sh chromium_gen_env.sh chromium_download_ccache.sh chromium_download_create_minidebuginfo.sh chromium_build_crashpad.sh build_android.sh build_android_def.sh build_android_help.sh; do
      [ -f "$SCRIPT_DIR/$_rs" ] && cp -a "$SCRIPT_DIR/$_rs" "$_reloc_dir/"
    done
    SCRIPT_DIR="$_reloc_dir"
    echo "=== scripts relocated to $SCRIPT_DIR (safe from git checkout) ==="
    ;;
esac

echo "=== Parsed parameters ==="
echo "git_branch   : $git_branch"
echo "git_target_os: $git_target_os"
echo "abs_dir      : $abs_dir"
echo "rel_dir      : $rel_dir"
echo "root_dir     : $root_dir"
echo "src_dir      : $src_dir"
echo "src_name     : $src_name"
echo "skip_rm_bak  : $skip_rm_bak"
echo "sync_retry   : $sync_retry"


# Prompt the user to configure the git commit identity (used to commit the source)
chromium_prompt_git_identity() {
  echo "=== Configure git commit identity ==="
  echo "A git name and email are required before committing the source (press Enter to use defaults):"
  echo "  demo: chromium_builder / chromium_builder@gmail.com"

  _ci_name=""
  printf 'git name  [chromium_builder]: '
  read -r _ci_name || true
  [ -n "$_ci_name" ] || _ci_name="chromium_builder"

  _ci_email=""
  printf 'git email [chromium_builder@gmail.com]: '
  read -r _ci_email || true
  [ -n "$_ci_email" ] || _ci_email="chromium_builder@gmail.com"

  export CHROMIUM_GIT_NAME="$_ci_name"
  export CHROMIUM_GIT_EMAIL="$_ci_email"
  echo "Will use: $CHROMIUM_GIT_NAME <$CHROMIUM_GIT_EMAIL>"
}

# Initialize the workspace directories (link under /, cd into root_dir)
chromium_init_dirs() {
  echo mkdir -p "$root_dir"
  mkdir -p "$root_dir"
  echo sudo ln -sfn "$HOME/$abs_dir" "/${abs_dir}"
  sudo ln -sfn "$HOME/$abs_dir" "/${abs_dir}"

  echo "=== Script dir: $(dirname "$(readlink -f "$0")")"
  echo cd "$root_dir"
  cd "$root_dir"
  echo "=== Current dir: $root_dir"
}

# Generate .gclient content (single function, easy to compare with an existing file)
cb_gclient_content() {
  cat <<EOF
solutions = [
  {
    "name": "src",
    "url": "https://chromium.googlesource.com/chromium/src.git",
    "managed": False,
    "custom_deps": {
    },
    "custom_vars": {
      "checkout_clang_coverage_tools": True,
      "checkout_pgo_profiles": True,
    },
  },
]
target_os = $git_target_os
EOF
}

# Retry a command up to <retries> times after the first failure.
# Usage: chromium_retry <retries> <command...>
chromium_retry() {
  local retries attempt
  retries=$1
  shift
  attempt=0
  while :; do
    attempt=$((attempt + 1))
    if "$@"; then
      return 0
    fi
    if [ "$attempt" -gt "$retries" ]; then
      echo "command failed after $attempt attempts: $*" >&2
      return 1
    fi
    echo "command failed (attempt $attempt), retrying in 5s: $*" >&2
    sleep 5
  done
}

# Download the Chromium source (system update -> depot_tools -> .gclient -> sync -> deps -> runhooks)
chromium_download_code() {
  # Update the system before downloading the code
  sudo apt update -y
  sudo apt upgrade -y
  sudo apt install -y git vim curl wget
  git config --global core.editor "vim"
  git config --global core.deltaBaseCacheLimit 2g
  git config --global init.defaultBranch main


  # cd "$root_dir"
  # Download depot_tools
  if [ ! -d depot_tools ]; then
    git clone https://chromium.googlesource.com/chromium/tools/depot_tools.git
  fi

  # Set PATH so depot_tools comes first; set it in the current terminal to avoid affecting the environment
  export PATH="$root_dir/depot_tools:$PATH"

  # Check out the appropriate version, or default to main
  # cd depot_tools

  # Update depot_tools; slow, please wait
  gclient --version


  ## 03 Download the Chromium source

  # Official reference docs: https://chromium.googlesource.com/chromium/src/+/main/docs/android_build_instructions.md

  # Download android or chromium: fetch --nohooks --no-history chromium
  #fetch --nohooks --no-history android
  #

  gclient_file="$root_dir/.gclient"

  # Issue 1: do not blindly overwrite .gclient if it already exists.
  #   - does not exist: create it
  #   - exists and identical: keep it (do not overwrite, preserve history)
  #   - exists but different: overwrite it
  if [ -f "$gclient_file" ]; then
    if [ "$(cb_gclient_content)" = "$(cat "$gclient_file")" ]; then
      echo "=== .gclient already exists with identical config, keeping it (preserve history) ==="
    else
      echo "=== .gclient already exists with different config, overwriting ==="
      cb_gclient_content > "$gclient_file"
    fi
  else
    echo "=== .gclient does not exist, creating ==="
    cb_gclient_content > "$gclient_file"
  fi

  echo "=== .gclient content ==="
  cat "$gclient_file"

  # Sync the code; default is the $git_branch branch
  # Issue 2: on re-runs, `gclient sync --force` would re-download the existing src as a
  # full repo (27GB+), which contradicts the shallow-clone intent of --no-history / --depth 1.
  # Core idea: only download a shallow copy of the specified branch.
  #   - first run: init + fetch --depth 1 to shallow-clone the branch
  #   - re-run: when the repo already fully exists, only update that branch in shallow mode
  #     (fetch --depth 1), without re-downloading the full repo
  src_repo="$root_dir/src"
  src_url="https://chromium.googlesource.com/chromium/src.git"
  branch_ref="refs/branch-heads/$git_branch"
  local_branch="b$git_branch"

  if [ -d "$src_repo/.git" ]; then
    echo "=== src repo already exists, shallow-updating branch $branch_ref ==="
    git -C "$src_repo" fetch --depth 1 origin "$branch_ref"
    git -C "$src_repo" checkout -B "$local_branch" FETCH_HEAD
  else
    echo "=== src repo does not exist, shallow-cloning branch $branch_ref ==="
    mkdir -p "$src_repo"
    git -C "$src_repo" init
    git -C "$src_repo" remote add origin "$src_url"
    git -C "$src_repo" fetch --depth 1 origin "$branch_ref"
    git -C "$src_repo" checkout -B "$local_branch" FETCH_HEAD
  fi

  # Sync dependencies (shallow). src has been manually shallow-cloned to the target branch,
  # so gclient does not need to re-download the full src.
  # Drop --force to avoid a full re-download on re-runs; drop --revision to avoid gclient
  # re-fetching to resolve refs/branch-heads/$git_branch.
  echo "gclient sync --nohooks --no-history -D (retry=$sync_retry)"
  chromium_retry "$sync_retry" gclient sync --nohooks --no-history -D

  # Enter the source repository directory
  cd "$root_dir/src"
  echo "PWD: $PWD"
  git checkout "b$git_branch"
  # Update dependencies
  # On ubuntu18.04/ubuntu16.04, add --unsupported
  #./build/install-build-deps.sh
  echo ./build/install-build-deps.sh --android
  ./build/install-build-deps.sh --android

  # Usually the amd64/arm64 sysroots are needed; download all sysroots for this version here.
  # gclient sync may have already downloaded them as GCS deps, so skip if already present.
  # [amd64] is x64, [arm64] is the arm64 (aarch64) version used for in-vehicle/auto
  for _sa in amd64 i386 arm64 arm; do
    _sd="build/linux/debian_bullseye_${_sa}-sysroot"
    [ "$_sa" = "arm" ] && _sd="build/linux/debian_bullseye_armhf-sysroot"
    if [ -d "$_sd" ] && [ -n "$(ls -A "$_sd" 2>/dev/null)" ]; then
      echo "sysroot $_sa already present ($_sd), skip install-sysroot.py"
    else
      echo ./build/linux/sysroot_scripts/install-sysroot.py --arch="$_sa"
      ./build/linux/sysroot_scripts/install-sysroot.py --arch="$_sa"
    fi
  done


  cd "$root_dir"
  # Update the toolchain locally
  echo gclient runhooks
  gclient runhooks
  # m108 runhooks has 120 items, updating as shown below
  # Running hooks: 100% (120/120), done.
}

# Second commit: after runhooks, copy depot_tools, gclient config, build scripts and env.sh
# into src/init_tools/<major version>/, then commit them on top of the clean chromium snapshot.
chromium_backup_init_tools() {
  local version init_base f s bak_git bak_gi tmp_list rel

  version=$(sed -n 's/^MAJOR=//p' "$src_dir/chrome/VERSION" | head -n 1)
  [ -n "$version" ] || version="0"

  init_base="$src_dir/init_tools/$version"
  mkdir -p "$init_base"

  # 1) Copy depot_tools to src/init_tools/<major version>/depot_tools
  if [ -d "$root_dir/depot_tools" ]; then
    echo "cp -a $root_dir/depot_tools $init_base/depot_tools"
    rm -rf "$init_base/depot_tools"
    cp -a "$root_dir/depot_tools" "$init_base/depot_tools"
  fi

  # 2) Copy the .gclient-related config to src/init_tools/<major version>/android_conf/
  mkdir -p "$init_base/android_conf"
  for f in .gclient .gclient_entries .gclient_previous_custom_vars .gclient_previous_sync_commits .gcs_entries; do
    if [ -f "$root_dir/$f" ]; then
      echo "cp -a $root_dir/$f $init_base/android_conf/"
      cp -a "$root_dir/$f" "$init_base/android_conf/"
    fi
  done

  # 3) Clean __pycache__ and .pyc inside the copied depot_tools
  find "$init_base" -type d -name __pycache__ -prune -exec rm -rf {} +
  find "$init_base" -type f -name '*.pyc' -exec rm -f {} +

  # 4) Flatten the copied depot_tools: back up and remove all its .git and .gitignore
  bak_git="$root_dir/git.bak"
  bak_gi="$root_dir/gitignore.bak"
  mkdir -p "$bak_git" "$bak_gi"

  tmp_list=$(mktemp)
  find "$init_base/depot_tools" -name .git -prune -print > "$tmp_list"
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    rel=${f#"$src_dir"/}
    mkdir -p "$bak_git/$(dirname "$rel")"
    rm -rf "$bak_git/$rel"
    mv "$f" "$bak_git/$rel"
  done < "$tmp_list"
  rm -f "$tmp_list"

  tmp_list=$(mktemp)
  find "$init_base/depot_tools" -type f -name .gitignore > "$tmp_list"
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    rel=${f#"$src_dir"/}
    mkdir -p "$bak_gi/$(dirname "$rel")"
    rm -f "$bak_gi/$rel"
    mv "$f" "$bak_gi/$rel"
  done < "$tmp_list"
  rm -f "$tmp_list"

  # 5) Copy the build scripts into src/init_tools/<major version>/download/
  mkdir -p "$init_base/download"
  for s in chromium_download.sh chromium_download_help.sh chromium_gen_env.sh chromium_download_ccache.sh chromium_download_create_minidebuginfo.sh chromium_build_crashpad.sh; do
    if [ -f "$SCRIPT_DIR/$s" ]; then
      echo "cp -a $SCRIPT_DIR/$s $init_base/download/"
      cp -a "$SCRIPT_DIR/$s" "$init_base/download/"
    fi
  done

  # Copy the android build scripts into src/init_tools/build/ (version-independent).
  mkdir -p "$src_dir/init_tools/build"
  for s in build_android.sh build_android_def.sh build_android_help.sh; do
    if [ -f "$SCRIPT_DIR/$s" ]; then
      echo "cp -a $SCRIPT_DIR/$s $src_dir/init_tools/build/"
      cp -a "$SCRIPT_DIR/$s" "$src_dir/init_tools/build/"
    fi
  done

  # Create a convenience symlink src/build_android.sh -> init_tools/build/build_android.sh
  # (like src/env.sh), so build_android.sh can be run directly from the src root.
  if [ -f "$src_dir/init_tools/build/build_android.sh" ]; then
    echo "ln -sfn init_tools/build/build_android.sh $src_dir/build_android.sh"
    ln -sfn "init_tools/build/build_android.sh" "$src_dir/build_android.sh"
  fi

  # Clean up the temp scripts dir (if it exists) now that scripts are copied into init_tools.
  if [ -d "/tmp/chromium_scripts" ]; then
    rm -rf "/tmp/chromium_scripts"
    echo "cleaned up /tmp/chromium_scripts"
  fi

  # 6) Generate env.sh under src (Java / Android SDK environment variables) for CLI debugging
  if [ -x "$SCRIPT_DIR/chromium_gen_env.sh" ]; then
    echo "$SCRIPT_DIR/chromium_gen_env.sh --src \"$src_dir\""
    "$SCRIPT_DIR/chromium_gen_env.sh" --src "$src_dir"
  fi

  # 7) Download ccache (glibc-independent static binary, 120s timeout, non-fatal)
  if [ -x "$SCRIPT_DIR/chromium_download_ccache.sh" ]; then
    "$SCRIPT_DIR/chromium_download_ccache.sh" "$src_dir/init_tools/ccache/ccache" || \
      echo "Warning: ccache download skipped (non-fatal)"
  fi

  # 8) Download create_minidebuginfo (+ libc++.so, 120s timeout, non-fatal)
  if [ -x "$SCRIPT_DIR/chromium_download_create_minidebuginfo.sh" ]; then
    "$SCRIPT_DIR/chromium_download_create_minidebuginfo.sh" "$init_base/tools" || \
      echo "Warning: create_minidebuginfo download skipped (non-fatal)"
  fi

  # 9) Build dump_syms + minidump_stackwalk (host tools) + generate crashpad.sh (non-fatal)
  if [ -x "$SCRIPT_DIR/chromium_build_crashpad.sh" ]; then
    "$SCRIPT_DIR/chromium_build_crashpad.sh" "$init_base/tools" || \
      echo "Warning: crashpad tools build skipped (non-fatal)"
  fi

  # 10) Commit the init_tools content (depot_tools + scripts) as the second commit
  echo "git -C \"$src_dir\" add -A"
  git -C "$src_dir" add -A

  # Restore all depot_tools .gitignore files so they are included in the same commit
  tmp_list=$(mktemp)
  find "$bak_gi/init_tools/$version/depot_tools" -type f -name .gitignore > "$tmp_list"
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    rel=${f#"$bak_gi"/}
    mkdir -p "$src_dir/$(dirname "$rel")"
    cp -a "$f" "$src_dir/$rel"
  done < "$tmp_list"
  rm -f "$tmp_list"
  echo "git -C \"$src_dir\" add -A"
  git -C "$src_dir" add -A

  echo "git -C \"$src_dir\" commit -m \"Add init_tools (depot_tools and download scripts)\""
  git -C "$src_dir" commit -m "Add init_tools (depot_tools and download scripts)" || true
}

# First commit: flatten the original src (without init_tools) into a single repository,
# so the first commit is the complete, clean chromium branch.
#   1) back up and remove all .gitignore -> $root_dir/gitignore.bak (keep the dir layout relative to src)
#   2) back up and remove all nested .git -> $root_dir/git.bak (keep src's own .git)
#   3) clean up __pycache__ and .pyc
#   4) git add all of src into the repository
#   5) copy .gitignore back from gitignore.bak
chromium_flatten_src_to_repo() {
  local bak_gi bak_git f rel tmp_list version flag_file

  # Run only once at init time; skip if the flag file exists (delete it manually to re-run)
  version=$(sed -n 's/^MAJOR=//p' "$src_dir/chrome/VERSION" | head -n 1)
  [ -n "$version" ] || version="0"
  flag_file="$src_dir/init_tools/$version/flatten_done.flag"
  if [ -f "$flag_file" ]; then
    echo "=== $flag_file already exists, skipping flatten (delete the flag file to redo) ==="
    return 0
  fi

  bak_gi="$root_dir/gitignore.bak"
  bak_git="$root_dir/git.bak"

  rm -rf "$bak_gi" "$bak_git"
  mkdir -p "$bak_gi" "$bak_git"

  # 1) Back up and remove all .gitignore files
  tmp_list=$(mktemp)
  find "$src_dir" -type f -name .gitignore > "$tmp_list"
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    rel=${f#"$src_dir"/}
    mkdir -p "$bak_gi/$(dirname "$rel")"
    cp -a "$f" "$bak_gi/$rel"
    rm -f "$f"
  done < "$tmp_list"
  rm -f "$tmp_list"

  # 2) Back up and remove all nested .git (-mindepth 2 excludes src's own .git)
  tmp_list=$(mktemp)
  find "$src_dir" -mindepth 2 -name .git > "$tmp_list"
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    rel=${f#"$src_dir"/}
    mkdir -p "$bak_git/$(dirname "$rel")"
    mv "$f" "$bak_git/$rel"
  done < "$tmp_list"
  rm -f "$tmp_list"

  # 3) Clean up __pycache__ and .pyc
  find "$src_dir" -type d -name __pycache__ -prune -exec rm -rf {} +
  find "$src_dir" -type f -name '*.pyc' -exec rm -f {} +

  # 4) Add all of src into the repository
  echo "git -C \"$src_dir\" add -A"
  git -C "$src_dir" add -A

  # 5) Restore .gitignore files
  tmp_list=$(mktemp)
  find "$bak_gi" -type f > "$tmp_list"
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    rel=${f#"$bak_gi"/}
    mkdir -p "$src_dir/$(dirname "$rel")"
    cp -a "$f" "$src_dir/$rel"
  done < "$tmp_list"
  rm -f "$tmp_list"

  # 6) add again after restoring .gitignore so they are included, then commit once
  echo "git -C \"$src_dir\" add -A"
  git -C "$src_dir" add -A

  # Configure this repo's user.name/email using the identity chosen above (or the default)
  git -C "$src_dir" config user.name "${CHROMIUM_GIT_NAME:-chromium_builder}"
  git -C "$src_dir" config user.email "${CHROMIUM_GIT_EMAIL:-chromium_builder@gmail.com}"

  echo "git -C \"$src_dir\" commit -m \"Snapshot chromium $version source\""
  git -C "$src_dir" commit -m "Snapshot chromium $version source" || true

  # On success, write the flag file to prevent re-running
  mkdir -p "$(dirname "$flag_file")"
  touch "$flag_file"
  echo "created: $flag_file"
}

# Clean up the backup directories (unless --skip-rm-bak is given)
chromium_cleanup_bak() {
  if [ "${skip_rm_bak:-false}" = "true" ]; then
    echo "=== --skip-rm-bak set, keeping $root_dir/git.bak and $root_dir/gitignore.bak ==="
    return 0
  fi
  echo "rm -rf $root_dir/git.bak $root_dir/gitignore.bak $root_dir/_bad_scm"
  rm -rf "$root_dir/git.bak" "$root_dir/gitignore.bak" "$root_dir/_bad_scm"
}

# Rename the src checkout directory to src_name (after everything is done)
chromium_rename_src() {
  if [ -z "$src_name" ] || [ "$src_name" = "src" ]; then
    return 0
  fi

  local target_name answer n

  target_name="$src_name"
  if [ -e "$root_dir/$target_name" ]; then
    printf '%s already exists. Overwrite? [y/N] (10s timeout -> auto-suffix): ' \
      "$root_dir/$target_name" >&2
    answer=""
    if command -v timeout >/dev/null 2>&1; then
      answer=$(timeout 10 sh -c 'IFS= read -r a; printf "%s" "$a"' 2>/dev/null || true)
    else
      IFS= read -r answer || true
    fi
    case "$answer" in
      y | Y | yes | YES )
        echo "overwrite $root_dir/$target_name"
        rm -rf "$root_dir/$target_name"
        ;;
      * )
        n=1
        while [ -e "$root_dir/${src_name}${n}" ]; do
          n=$((n + 1))
        done
        target_name="${src_name}${n}"
        ;;
    esac
  fi

  echo "mv $src_dir $root_dir/$target_name"
  mv "$src_dir" "$root_dir/$target_name"
}

# Temporarily enable passwordless sudo for the duration of this script.
chromium_sudo_setup() {
  local user sudoers_file rule tmp_rule SUDO_PASS

  user=$(id -un)
  sudoers_file="/etc/sudoers.d/zz-${user}-nopasswd"
  rule="$user ALL=(ALL:ALL) NOPASSWD: ALL"

  # Already passwordless? nothing to do.
  if sudo -n true 2>/dev/null; then
    echo "=== sudo already passwordless, skip setup ==="
    return 0
  fi

  # Prompt for the sudo password once (only needed to install the NOPASSWD rule).
  printf 'sudo password (one-time, to enable unattended build): '
  stty -echo 2>/dev/null || true
  SUDO_PASS=""
  IFS= read -r SUDO_PASS || true
  stty echo 2>/dev/null || true
  printf '\n'

  if [ -z "$SUDO_PASS" ]; then
    echo "Warning: no sudo password provided; later sudo commands may fail" >&2
    return 0
  fi

  tmp_rule=$(mktemp)
  printf '%s\n' "$rule" > "$tmp_rule"

  if printf '%s\n' "$SUDO_PASS" | sudo -S sh -c 'install -m 440 "$1" "$2"' _ "$tmp_rule" "$sudoers_file" 2>/dev/null \
     && sudo -n true 2>/dev/null; then
    echo "=== passwordless sudo enabled ==="
  else
    echo "Warning: failed to enable passwordless sudo (wrong password?)" >&2
  fi

  rm -f "$tmp_rule"
  SUDO_PASS=""
}

# Remove the temporary passwordless sudo rule (restores password requirement).
chromium_sudo_cleanup() {
  local sudoers_file
  sudoers_file="/etc/sudoers.d/zz-$(id -un)-nopasswd"
  if [ -f "$sudoers_file" ]; then
    sudo rm -f "$sudoers_file" 2>/dev/null || true
    echo "=== passwordless sudo rule removed ==="
  fi
}

# Unified function calls (in execution order)
main() {
  chromium_sudo_setup
  trap chromium_sudo_cleanup EXIT
  trap 'exit 1' INT TERM HUP

  chromium_prompt_git_identity
  chromium_init_dirs
  chromium_download_code
  chromium_flatten_src_to_repo
  chromium_backup_init_tools
  chromium_cleanup_bak
  chromium_rename_src
}

main
