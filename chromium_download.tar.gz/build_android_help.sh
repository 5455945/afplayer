#!/usr/bin/env bash
#############################################################################
# build_android_help.sh
#
# Handles build parameter input and prints help information.
#
# This file can be used in two ways:
#   * Sourced by build_android.sh to obtain parse_build_params() and print_help().
#   * Executed directly (e.g. `./build_android_help.sh`) to print help only.
#
# Defaults come from build_android_def.sh (loaded automatically from this
# script's directory).
#############################################################################

_THIS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Load defaults (idempotent; safe to source more than once).
if [ -f "$_THIS_DIR/build_android_def.sh" ]; then
  # shellcheck source=build_android_def.sh
  source "$_THIS_DIR/build_android_def.sh"
fi

print_help() {
  cat <<EOF
Usage: ./build_android.sh [options]

Architecture / build mode:
  --arch=<cpu>            Target architecture: arm64 | arm | x64 | x86
                          (default: ${BUILD_ARCH_DEFAULT})
  --cpu=<cpu>             Alias of --arch
  --target_cpu=<cpu>
                          Alias of --arch

  --mode=<mode>           Build mode: debug | release
                          (default: ${BUILD_MODE_DEFAULT})
  --type=<mode>           Alias of --mode
  --build-type=<mode>     Alias of --mode
  --debug                 Shortcut for --mode=debug
  --release               Shortcut for --mode=release

Target / sanitizer / misc:
  --target_apk=<apk>      Target apk: system_webview_apk |
                          webview_instrumentation_apk | chrome_public_apk
                          (default: ${TARGET_APK_DEFAULT})

  --asan                  Enable ASAN build (equivalent to XMAKE_WITH_ASAN=true)
  --hwasan                Enable HWASAN build (arm64 only)
  --is_hwasan=<bool>  Enable/disable HWASAN (default: ${IS_HWASAN_DEFAULT})
  --only_64bit=<bool> 64-bit only build (default: ${ONLY_64BIT_DEFAULT})
  --dir_fix=<suffix>      Extra suffix appended to the output directory
  --usebuildid            Record git commit hash as the build id
  --no-ccache             Disable ccache
  --jobs=<n>, -j<n>       Parallel jobs for autoninja (default: ${BUILD_JOBS_DEFAULT})
  --gn-args="k=v ..."     Extra chromium GN args (can override the defaults above)
  --gn-arg=k=v            Extra chromium GN arg (repeatable, alias of --gn-args)

  -h, --help              Show this help message

Environment variables:
  XMAKE_WITH_ASAN         Set to "true" to enable an ASAN build
  CCACHE_DIR              ccache cache directory

Output directories:
  out/<arch><mode>        arm64d arm64r armd armr x64d x64r x86d x86r
  Additional suffixes are appended as needed:
    non-default target apk -> _sdk / _chrome
    ASAN                     -> _asan
    HWASAN                   -> _hwasan

Examples:
  ./build_android.sh --arch=arm64 --mode=release
  ./build_android.sh --debug --arch=x64
  ./build_android.sh --release --target_apk=chrome_public_apk --arch=arm64
  ./build_android.sh --asan --arch=arm64 --only_64bit=true
EOF
}

# parse_build_params "$@"
#
# Populates the following variables (defaults first, then command-line
# overrides):
#   target_cpu  build_mode  target_apk_webview  dir_fix
#   is_hwasan   only_64bit  asan_enabled
#   use_build_id       no_ccache
#   jobs               PARSE_HELP (set to 1 when help was requested)
parse_build_params() {
  PARSE_HELP=0

  # Start from the defaults defined in build_android_def.sh.
  target_cpu="${BUILD_ARCH_DEFAULT}"
  build_mode="${BUILD_MODE_DEFAULT}"
  target_apk_webview="${TARGET_APK_DEFAULT}"
  is_hwasan="${IS_HWASAN_DEFAULT}"
  only_64bit="${ONLY_64BIT_DEFAULT}"
  dir_fix="${DIR_FIX_DEFAULT}"
  use_build_id="${USE_BUILD_ID_DEFAULT}"
  no_ccache="${NO_CCACHE_DEFAULT}"
  jobs="${BUILD_JOBS_DEFAULT}"
  extra_gn_args="${EXTRA_GN_ARGS_DEFAULT}"
  asan_enabled=false

  local arg lower_arg
  while [ $# -gt 0 ]; do
    arg="$1"; shift
    lower_arg="$(printf '%s' "$arg" | tr '[:upper:]' '[:lower:]')"
    case "$lower_arg" in
      -h|--help)              PARSE_HELP=1 ;;
      --arch=*|--cpu=*|--target_cpu=*)
                              target_cpu="${arg#*=}" ;;
      --mode=*|--type=*|--build-type=*)
                              build_mode="${arg#*=}" ;;
      --debug)                build_mode=debug ;;
      --release)              build_mode=release ;;
      --target_apk=*)         target_apk_webview="${arg#*=}" ;;
      --is_hwasan=*)   is_hwasan="${arg#*=}" ;;
      --only_64bit=*)  only_64bit="${arg#*=}" ;;
      --dir_fix=*)            dir_fix="${arg#*=}" ;;
      --usebuildid|--use-build-id) use_build_id=true ;;
      --no-ccache)            no_ccache=true ;;
      --asan)                 asan_enabled=true ;;
      --hwasan)               is_hwasan=true ;;
      --jobs=*)               jobs="${arg#*=}" ;;
      --jobs)                 jobs="${1:-}"; shift ;;
      --gn-args=*)            extra_gn_args="${extra_gn_args:+${extra_gn_args} }${arg#*=}" ;;
      --gn-arg=*)             extra_gn_args="${extra_gn_args:+${extra_gn_args} }${arg#*=}" ;;
      -j=*)                   jobs="${arg#*=}" ;;
      -j[0-9]*)               jobs="${arg#-j}" ;;
      -j)                     jobs="${1:-}"; shift ;;
      *)                      echo "WARNING: unknown option ignored: $arg" >&2 ;;
    esac
  done

  # Normalise case-sensitive values.
  target_cpu="$(printf '%s' "$target_cpu" | tr '[:upper:]' '[:lower:]')"
  build_mode="$(printf '%s' "$build_mode" | tr '[:upper:]' '[:lower:]')"
  is_hwasan="$(printf '%s' "$is_hwasan" | tr '[:upper:]' '[:lower:]')"
  only_64bit="$(printf '%s' "$only_64bit" | tr '[:upper:]' '[:lower:]')"

  # Validate architecture.
  case "$target_cpu" in
    arm64|arm|x64|x86) ;;
    *)
      echo "ERROR: unsupported architecture '$target_cpu' (arm64|arm|x64|x86)" >&2
      PARSE_HELP=1
      ;;
  esac

  # Validate build mode.
  case "$build_mode" in
    debug|release) ;;
    *)
      echo "ERROR: unsupported build mode '$build_mode' (debug|release)" >&2
      PARSE_HELP=1
      ;;
  esac

  # Validate target apk.
  case "$target_apk_webview" in
    system_webview_apk|webview_instrumentation_apk|chrome_public_apk) ;;
    *)
      echo "ERROR: unsupported target_apk '$target_apk_webview'" >&2
      PARSE_HELP=1
      ;;
  esac
}

# When executed directly, just print the help text.
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  print_help
  exit 0
fi
