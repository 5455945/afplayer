#!/usr/bin/env bash
#############################################################################
# build_android_def.sh
#
# Default build parameters.
#
# This file is sourced by build_android.sh (and by build_android_help.sh).
# Every value defined here is used as the fallback when the matching
# command-line argument is not supplied. See build_android_help.sh for the
# full list of accepted arguments and their defaults.
#############################################################################

# Chromium branch version (used to locate init_tools paths, ccache
# directory, depot_tools, ...).
M_VERSION=148

# Default target architecture: arm64 | arm | x64 | x86
BUILD_ARCH_DEFAULT=arm64

# Default build mode: debug | release
BUILD_MODE_DEFAULT=release

# Default target apk: system_webview_apk | webview_instrumentation_apk | chrome_public_apk
TARGET_APK_DEFAULT=system_webview_apk

# Default boolean / string flags
IS_HWASAN_DEFAULT=false
ONLY_64BIT_DEFAULT=false
DIR_FIX_DEFAULT=""
USE_BUILD_ID_DEFAULT=false
NO_CCACHE_DEFAULT=false

# Extra chromium GN args appended verbatim to the generated args
# (e.g. "--gn-args='key=value ...'" or "--gn-arg=key=value").
EXTRA_GN_ARGS_DEFAULT=""

# Parallel jobs passed to autoninja (default: number of CPU cores).
BUILD_JOBS_DEFAULT="$(nproc)"
