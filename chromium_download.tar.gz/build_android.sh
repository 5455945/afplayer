#!/usr/bin/env bash
#############################################################################
# build_android.sh - Android (Chromium) build driver (shell only).
#
# Shell implementation:
#   * build_android_def.sh  - default parameter values
#   * build_android_help.sh - parameter parsing + help text
#   * build_android.sh      - build orchestration (this file)
#
# The script lives in init_tools/build/ and resolves the repository root as two
# levels up from its own location. It can be invoked from the repository root
# (via the build_android.sh symlink), from an arbitrary external directory, or
# directly from inside init_tools/build/.
#############################################################################

SCRIPT_PATH="$(readlink -f "$0")"
SCRIPT_DIR="$(cd "$(dirname "$SCRIPT_PATH")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
START_DIR="$(pwd)"

# ---------------------------------------------------------------------------
# Source parameter defaults + help/parsing helpers.
# ---------------------------------------------------------------------------
# shellcheck source=build_android_def.sh
source "$SCRIPT_DIR/build_android_def.sh"
# shellcheck source=build_android_help.sh
source "$SCRIPT_DIR/build_android_help.sh"

# ---------------------------------------------------------------------------
# Global constants
# ---------------------------------------------------------------------------
Asan_dir="_asan"
hwasan_dir="_hwasan"

LOG_FILE=""

# ---------------------------------------------------------------------------
# Logging helpers
#
#   log ...      -> timestamped line (stdout + log file)
#   run_log ...  -> timestamped command line + execution (stdout + log file)
# ---------------------------------------------------------------------------
log() {
  local ts
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  if [ -n "$LOG_FILE" ]; then
    printf '[%s] %s\n' "$ts" "$*" | tee -a "$LOG_FILE"
  else
    printf '[%s] %s\n' "$ts" "$*"
  fi
}

run_log() {
  local desc="$1"; shift
  log ">>> $desc"
  log "RUN: $*"
  if [ -n "$LOG_FILE" ]; then
    "$@" 2>&1 | tee -a "$LOG_FILE"
  else
    "$@"
  fi
  return "${PIPESTATUS[0]}"
}

# ---------------------------------------------------------------------------
# ccache
# ---------------------------------------------------------------------------
setup_ccache() {
  if [[ "$no_ccache" == "true" ]]; then
    log "ccache disabled (--no-ccache)"
    return 0
  fi

  if [[ -z "${CCACHE_DIR:-}" ]]; then
    if [ -d /workspace ]; then
      CCACHE_DIR="/workspace/.ccache/chromium${M_VERSION}"
    else
      CCACHE_DIR="$HOME/.ccache/chromium${M_VERSION}"
      log "WARNING: /workspace does not exist, fallback to ccache dir: $CCACHE_DIR"
    fi
  fi
  export CCACHE_DIR
  export CCACHE_BIN="$REPO_ROOT/init_tools/ccache/ccache"
  export CCACHE_MAX_SIZE=0            # no limit
  export CCACHE_UNIFY=1               # unify hashing across architectures
  export CCACHE_COMPILERCHECK=content
  export CCACHE_CPP2=true
  export CACHE_UMASK=002
  export CCACHE_NOHASHDIR=true
  export CCACHE_BASEDIR="$REPO_ROOT"
  export CCACHE_TEMPDIR="$REPO_ROOT/out/.tmp/"
  mkdir -p "$CCACHE_TEMPDIR"
  export CCACHE_DEPEND=1              # depend_mode for -fmodules support
  export CCACHE_SLOPPINESS="file_macro,time_macros,include_file_mtime,include_file_ctime,pch_defines,modules,clang_index_store"

  run_log "ccache reset stats" "$CCACHE_BIN" -z
  run_log "ccache set max size" "$CCACHE_BIN" -M 100GB
}

show_ccache_stats() {
  [[ "$no_ccache" == "true" ]] && return 0
  [[ -n "${CCACHE_BIN:-}" ]] || return 0
  run_log "ccache stats" "$CCACHE_BIN" -s
}

# ---------------------------------------------------------------------------
# Target / output resolution
# ---------------------------------------------------------------------------
# Derive the apk base name from target_apk_webview (no dedicated variable).
get_target_apk_name() {
  case "$target_apk_webview" in
    "webview_instrumentation_apk") printf '%s' "WebViewInstrumentation"; return 0 ;;
    "chrome_public_apk")   printf '%s' "ChromePublic"; return 0 ;;
  esac

  # system_webview_apk (default): 64-bit only arm64/x64 produces a "64" suffix.
  if [[ "$only_64bit" == "true" ]]; then
    case "$target_cpu" in
      arm64|x64) printf '%s' "SystemWebView64"; return 0 ;;
    esac
  fi
  printf '%s' "SystemWebView"
}

resolve_output_dir() {
  local mode_letter target_suffix
  case "$build_mode" in
    debug)   mode_letter="d" ;;
    release) mode_letter="r" ;;
  esac

  case "$target_apk_webview" in
    "webview_instrumentation_apk") target_suffix="_sdk" ;;
    "chrome_public_apk")   target_suffix="_chrome" ;;
    *)                     target_suffix="" ;;
  esac

  OUTPUT_DIR="out/${target_cpu}${mode_letter}${target_suffix}${dir_fix}"
  if [[ "$asan_enabled" == "true" ]]; then
    OUTPUT_DIR="${OUTPUT_DIR}${Asan_dir}"
  fi
  if [[ "$hwasan_enabled" == "true" ]]; then
    OUTPUT_DIR="${OUTPUT_DIR}${hwasan_dir}"
  fi
  export OUTPUT_DIR
}

resolve_abi32() {
  abi32_cpu=""

  if [[ "$only_64bit" != "true" ]]; then
    case "$target_cpu" in
      arm64) abi32_cpu="arm" ;;
      x64)   abi32_cpu="x86" ;;
    esac
  fi
}

# ---------------------------------------------------------------------------
# Flags: asan / hwasan and their effect on strip
# ---------------------------------------------------------------------------
resolve_flags() {
  # ASAN can come from --asan or the XMAKE_WITH_ASAN environment variable.
  local xmake_asan="${XMAKE_WITH_ASAN:-false}"
  if [[ "$asan_enabled" == "true" ]]; then xmake_asan="true"; fi
  asan_flag="$(printf '%s' "$xmake_asan" | sed 's/^--*/ /' | tr -d ' ' | tr '[:upper:]' '[:lower:]')"
  asan_enabled=false
  [[ "$asan_flag" == "true" ]] && asan_enabled=true

  is_hwasan="$(printf '%s' "$is_hwasan" | sed 's/^--*/ /' | tr -d ' ' | tr '[:upper:]' '[:lower:]')"
  hwasan_enabled=false
  [[ "$is_hwasan" != "false" ]] && hwasan_enabled=true

  # ASAN and HWASAN are mutually exclusive.
  if [[ "$asan_enabled" == "true" && "$hwasan_enabled" == "true" ]]; then
    log "is_hwasan and is_asan should be mutually exclusive, ignore is_hwasan"
    hwasan_enabled=false
    is_hwasan=false
  fi

  # HWASAN is only valid for arm64.
  if [[ "$hwasan_enabled" == "true" && "$target_cpu" != "arm64" ]]; then
    log "$target_cpu != arm64 => ignore is_hwasan"
    hwasan_enabled=false
    is_hwasan=false
  fi

  need_strip=true
  if [[ "$asan_enabled" == "true" || "$hwasan_enabled" == "true" ]]; then
    need_strip=false
  fi
}

# ---------------------------------------------------------------------------
# Commit hash / LASTCHANGE
# ---------------------------------------------------------------------------
update_lastchange() {
  local file_lastchange="$REPO_ROOT/build/util/LASTCHANGE"
  if [ ! -f "$file_lastchange" ]; then
    echo "LASTCHANGE=b4fb3d3d5abf92fb434339f0b663400633d63849-refs/branch-heads/7778@{#4436}" > "$file_lastchange"
    echo "LASTCHANGE_YEAR=2026" >> "$file_lastchange"
  fi

  local file_lastchange_time="$REPO_ROOT/build/util/LASTCHANGE.committime"
  if [ ! -f "$file_lastchange_time" ]; then
    echo 1782695087 > "$file_lastchange_time"
  fi
}

update_build_id() {
  [[ "$use_build_id" != "true" ]] && return 0

  local COMMIT_HASH
  COMMIT_HASH="$(git -C "$REPO_ROOT" log -1 --format='%H' 2>/dev/null)"
  if [[ -n "$COMMIT_HASH" && ${#COMMIT_HASH} -eq 40 ]]; then
    sed -i "s/^\(LASTCHANGE=\)[0-9a-fA-F]\{40\}/\1$COMMIT_HASH/" "$REPO_ROOT/build/util/LASTCHANGE"
    BUILD_ID="$COMMIT_HASH"
    export BUILD_ID
    log "BUILD_ID=$BUILD_ID"
    echo "$BUILD_ID" > "$OUTPUT_DIR/build_id.txt"
  else
    echo "ERROR: build id hash is empty or not 40 characters."
  fi
  git -C "$REPO_ROOT" log -1 --format='%ct' > "$REPO_ROOT/build/util/LASTCHANGE.committime" 2>/dev/null || true
}

# ---------------------------------------------------------------------------
# gn gen
# ---------------------------------------------------------------------------
build_gn_args() {
  local is_debug_val="false" is_official="true"
  case "$build_mode" in
    debug)   is_debug_val="true";  is_official="false" ;;
    release) is_debug_val="false"; is_official="true" ;;
  esac

  local -a args=(
    "target_os=\"android\""
    "host_cpu=\"x64\""
    "target_cpu=\"${target_cpu}\""
    "system_webview_package_name=\"com.android.webview\""
    "use_remoteexec=false"
    "is_component_build=false"
    "ffmpeg_branding=\"Chrome\""
    "proprietary_codecs=true"
    "treat_warnings_as_errors=false"
    "android_channel=\"stable\""
    "enable_remoting=true"
    "symbol_level=1"
    "blink_symbol_level=1"
    "v8_symbol_level=1"
    "is_debug=${is_debug_val}"
    "is_official_build=${is_official}"
    "is_java_debug=false"
    "exclude_unwind_tables=false"
  )

  if [[ "$only_64bit" == "true" ]]; then
    args+=("enable_android_secondary_abi=false")
  fi
  if [[ -n "${BUILD_ID:-}" ]]; then
    args+=("afree_build_id=\"${BUILD_ID}\"")
  fi
  if [[ "$asan_enabled" == "true" ]]; then
    args+=("is_asan=true")
    args+=("is_debug=false")   # must match is_asan
    args+=("use_custom_libcxx=true")
    args+=("enable_full_stack_frames_for_profiling=true")
    args+=("is_official_build=false")
  fi
  if [[ "$hwasan_enabled" == "true" ]]; then
    args+=("is_hwasan=true")
    args+=("enable_full_stack_frames_for_profiling=true")
    args+=("is_official_build=false")
    args+=("dcheck_is_configurable=false")
    args+=("dcheck_always_on=false")
    args+=("v8_enable_sandbox=false")
    args+=("v8_enable_pointer_compression=false")
  fi
  if [[ -n "${CCACHE_BIN:-}" && "$no_ccache" != "true" ]]; then
    args+=("cc_wrapper=\"${CCACHE_BIN}\"")
  fi
  # Extra user-provided gn args are appended LAST so they override the defaults
  # above (GN's args.gn is evaluated top-to-bottom, last assignment wins).
  if [[ -n "${extra_gn_args:-}" ]]; then
    args+=("${extra_gn_args}")
  fi

  GN_ARGS="$(printf '%s ' "${args[@]}")"
}

run_gn_gen() {
  build_gn_args
  log "gn gen args: ${GN_ARGS}"
  run_log "gn gen" gn gen "$OUTPUT_DIR" --args="$GN_ARGS" || return 1
}

run_autoninja() {
  run_log "autoninja" autoninja -j"$jobs" -C "$OUTPUT_DIR" \
    "$target_apk_webview" system_webview_shell_apk minidump_stackwalk dump_syms || return 1
}

# ---------------------------------------------------------------------------
# so strip helpers
# ---------------------------------------------------------------------------
so_strip() {
  local infile=$1
  local outfile=$2
  local tmp=${outfile}.tmp
  local decom=${outfile}.dec
  local LLVM_BIN="$REPO_ROOT/third_party/llvm-build/Release+Asserts/bin"

  log "strip: $infile -> $outfile"
  run_log "llvm-strip" "$LLVM_BIN/llvm-strip" --strip-all \
    --keep-section=.ARM.attributes --remove-section=.comment "$infile" -o "$tmp" || return 1
  run_log "llvm-objcopy decompress" "$LLVM_BIN/llvm-objcopy" \
    --decompress-debug-sections "$infile" "$decom" || return 1
  run_log "create_minidebuginfo" "$REPO_ROOT/init_tools/${M_VERSION}/tools/create_minidebuginfo" \
    "$decom" "${outfile}.mini_debuginfo.xz" || return 1
  run_log "llvm-objcopy add gnu_debugdata" "$LLVM_BIN/llvm-objcopy" \
    --add-section ".gnu_debugdata=${outfile}.mini_debuginfo.xz" "$tmp" "$outfile" || return 1
  rm -f "$tmp" "$decom" "${outfile}.mini_debuginfo.xz"
}

# ---------------------------------------------------------------------------
# Repack apk via apkbuilder (kept as inline python: ninja command strings
# contain escape characters such as \ $: which are hard to handle in shell)
# ---------------------------------------------------------------------------
repack_apk_via_builder() {
  local ninja_file="$OUTPUT_DIR/toolchain.ninja"
  if [ ! -f "$ninja_file" ]; then
    echo "ERROR: toolchain.ninja does not exist: $ninja_file"
    return 1
  fi

  local apk_name
  apk_name="$(get_target_apk_name)"

  log "Extract the apkbuilder.py command from toolchain.ninja for ${apk_name}.apk"

  local PY3="$REPO_ROOT/init_tools/${M_VERSION}/depot_tools/python-bin/python3"
  log "RUN: apkbuilder repack (python)"
  "$PY3" - "$ninja_file" "$apk_name" "$OUTPUT_DIR" 2>&1 | tee -a "$LOG_FILE" <<'PYEOF'
import sys, subprocess

ninja_file = sys.argv[1]
target_name = sys.argv[2]
output_dir = sys.argv[3]

target_output = f"apks/{target_name}.apk"

found = False
with open(ninja_file, 'r') as f:
    for line in f:
        line = line.strip()
        if not line.startswith('command ='):
            continue
        if 'apkbuilder.py' not in line:
            continue
        if f'--output-apk={target_output}' not in line:
            continue
        found = True
        cmd = line[len('command = '):]
        break

if not found:
    print(f"ERROR: The apkbuilder.py command for output apk={target_output} was not found in toolchain.ninja", file=sys.stderr)
    sys.exit(1)

cmd = cmd.replace('$:', ':').replace('$ ', ' ')

ret = subprocess.call(cmd, shell=True, cwd=output_dir)
sys.exit(ret)
PYEOF
  return "${PIPESTATUS[0]}"
}

do_strip_and_repack() {
  [[ "$need_strip" != "true" ]] && return 0

  local primary_abi_toolchain_dir=""
  case "$target_cpu" in
    arm64)
      if [ -d "$OUTPUT_DIR/android_clang_arm64_webview" ]; then
        primary_abi_toolchain_dir="android_clang_arm64_webview"
      else
        primary_abi_toolchain_dir="android_clang_arm64"
      fi
      ;;
    arm) primary_abi_toolchain_dir="android_clang_arm" ;;
    x64) primary_abi_toolchain_dir="android_clang_x64" ;;
    x86) primary_abi_toolchain_dir="android_clang_x86" ;;
    *)   echo "WARNING: unknown target_cpu=$target_cpu, use default android_clang_${target_cpu}"
         primary_abi_toolchain_dir="android_clang_${target_cpu}" ;;
  esac
  log "Main abi toolchain directory: ${primary_abi_toolchain_dir}"

  case "$target_apk_webview" in
    "system_webview_apk")
      log "======== system_webview_apk android strip *.so ========"
      [ -f "$OUTPUT_DIR/lib.unstripped/libwebviewchromium.so" ] && \
        so_strip "$OUTPUT_DIR/lib.unstripped/libwebviewchromium.so" "$OUTPUT_DIR/libwebviewchromium.so"
      [ -f "$OUTPUT_DIR/${primary_abi_toolchain_dir}/lib.unstripped/libwebviewchromium.so" ] && \
        so_strip "$OUTPUT_DIR/${primary_abi_toolchain_dir}/lib.unstripped/libwebviewchromium.so" "$OUTPUT_DIR/${primary_abi_toolchain_dir}/libwebviewchromium.so"
      [ -f "$OUTPUT_DIR/exe.unstripped/libcrashpad_handler_trampoline.so" ] && \
        so_strip "$OUTPUT_DIR/exe.unstripped/libcrashpad_handler_trampoline.so" "$OUTPUT_DIR/libcrashpad_handler_trampoline.so"
      [ -f "$OUTPUT_DIR/${primary_abi_toolchain_dir}/exe.unstripped/libcrashpad_handler_trampoline.so" ] && \
        so_strip "$OUTPUT_DIR/${primary_abi_toolchain_dir}/exe.unstripped/libcrashpad_handler_trampoline.so" "$OUTPUT_DIR/${primary_abi_toolchain_dir}/libcrashpad_handler_trampoline.so"
      if [ -n "$abi32_cpu" ]; then
        [ -f "$OUTPUT_DIR/android_clang_${abi32_cpu}/lib.unstripped/libwebviewchromium.so" ] && \
          so_strip "$OUTPUT_DIR/android_clang_${abi32_cpu}/lib.unstripped/libwebviewchromium.so" "$OUTPUT_DIR/android_clang_${abi32_cpu}/libwebviewchromium.so"
        [ -f "$OUTPUT_DIR/android_clang_${abi32_cpu}/exe.unstripped/libcrashpad_handler_trampoline.so" ] && \
          so_strip "$OUTPUT_DIR/android_clang_${abi32_cpu}/exe.unstripped/libcrashpad_handler_trampoline.so" "$OUTPUT_DIR/android_clang_${abi32_cpu}/libcrashpad_handler_trampoline.so"
      fi
      ;;
    "webview_instrumentation_apk")
      log "======== webview_instrumentation_apk android strip *.so ========"
      so_strip "$OUTPUT_DIR/lib.unstripped/libstandalonelibwebviewchromium.so" "$OUTPUT_DIR/libstandalonelibwebviewchromium.so"
      so_strip "$OUTPUT_DIR/lib.unstripped/libtest_trace_processor.so" "$OUTPUT_DIR/libtest_trace_processor.so"
      ;;
    "chrome_public_apk")
      log "======== chrome_public_apk android strip *.so ========"
      [ -f "$OUTPUT_DIR/lib.unstripped/libchrome.so" ] && \
        so_strip "$OUTPUT_DIR/lib.unstripped/libchrome.so" "$OUTPUT_DIR/libchrome.so"
      [ -f "$OUTPUT_DIR/exe.unstripped/libchrome_crashpad_handler" ] && \
        so_strip "$OUTPUT_DIR/exe.unstripped/libchrome_crashpad_handler" "$OUTPUT_DIR/libchrome_crashpad_handler"
      if [ -n "$abi32_cpu" ]; then
        [ -f "$OUTPUT_DIR/android_clang_${abi32_cpu}/lib.unstripped/libchrome.so" ] && \
          so_strip "$OUTPUT_DIR/android_clang_${abi32_cpu}/lib.unstripped/libchrome.so" "$OUTPUT_DIR/android_clang_${abi32_cpu}/libchrome.so"
        [ -f "$OUTPUT_DIR/android_clang_${abi32_cpu}/lib.unstripped/libchrome_crashpad_handler.so" ] && \
          so_strip "$OUTPUT_DIR/android_clang_${abi32_cpu}/lib.unstripped/libchrome_crashpad_handler.so" "$OUTPUT_DIR/android_clang_${abi32_cpu}/libchrome_crashpad_handler.so"
      fi
      ;;
  esac

  log "Call apkbuilder.py to repackage $(get_target_apk_name).apk (without relinking)"
  repack_apk_via_builder || return 1
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
  log "begin time: $(date "+%Y-%m-%d %H:%M:%S")"

  cd "$REPO_ROOT" || exit 1

  resolve_output_dir
  mkdir -p "$OUTPUT_DIR" || exit 1
  LOG_FILE="$REPO_ROOT/$OUTPUT_DIR/build.log"

  log "================ android build ================"
  log "repo root     : $REPO_ROOT"
  log "target apk    : $target_apk_webview ($(get_target_apk_name))"
  log "architecture  : $target_cpu"
  log "build mode    : $build_mode"
  log "output dir    : $OUTPUT_DIR"

  resolve_flags
  resolve_abi32

  log "abi32_cpu     : ${abi32_cpu:-<none>}"
  log "asan          : $asan_enabled"
  log "hwasan        : $hwasan_enabled"
  log "only_64bit    : $only_64bit"
  log "use_build_id  : $use_build_id"
  log "need_strip    : $need_strip"

  setup_ccache

  export PYTHONDONTWRITEBYTECODE=1
  export DEPOT_TOOLS_UPDATE=0
  export PATH="$REPO_ROOT/init_tools/tools/ccache:$REPO_ROOT/init_tools/${M_VERSION}/depot_tools:$REPO_ROOT:$PATH"

  update_lastchange
  update_build_id

  log "jobs: $jobs"

  run_gn_gen || exit 1
  run_autoninja || exit 1

  do_strip_and_repack || exit 1

  show_ccache_stats

  cd "$START_DIR" || true
  log "end time: $(date "+%Y-%m-%d %H:%M:%S")"
}

parse_build_params "$@"
if [ "${PARSE_HELP:-0}" -eq 1 ]; then
  print_help
  exit 0
fi

main
