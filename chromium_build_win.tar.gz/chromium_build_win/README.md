# Chromium Windows 构建脚本

在 Windows 10/11 上下载并编译 Chromium。

> **重要（Windows 工具链）**：Chromium 自带的 clang 会随依赖自动下载；但 MSVC 头文件/库与
> Windows SDK 来自 **本机安装的 Visual Studio**（`DEPOT_TOOLS_WIN_TOOLCHAIN=0`）或
> **Google 内部预编译工具链**（`=1`，`gs://chrome-wintoolchain`，非公开）。经实测，该预编译
> 工具链的 bucket **拒绝匿名访问（401/403）**，官方文档也要求外部用户安装 VS 并设为 0。
> 因此**外部用户必须安装 Visual Studio / Build Tools**（见“系统要求”）。

- 下载源码、依赖、clang 及 Windows 平台所需组件。
- 强制使用 **浅拷贝**（`--no-history`，depth 1），让各仓库 `.git` 尽量小。
- 可在命令行指定 **版本分支 / tag / milestone**，找不到时回退到最新稳定版。
- 默认构建 `chrome`、`content_shell`、`headless_shell`、`mini_installer`。

## 文件说明

| 文件 | 作用 |
| --- | --- |
| `chromium_build_win.ps1` | 主脚本（全部逻辑） |
| `chromium_build_win.bat` | 启动器，转发参数给 `.ps1`，并做执行策略预检 |
| `find_depot_tools_version.ps1` | 查找某个 Chromium 版本对应的 depot_tools commit |
| `find_depot_tools_version.bat` | 上者的启动器 |
| `prepare_win_toolchain.ps1` | 下载/静默安装 VS 2026（可选 buildtools/community/professional/enterprise，可带 Windows SDK），并打成 Chromium 可用的 win_toolchain 归档（供 `--win-toolchain-url` 使用，免在编译机装 VS）。**只依赖 depot_tools**，无 Chromium 源码也可打包 |
| `prepare_win_toolchain.bat` | 上者的启动器 |

## 快速开始

```powershell
# 最新稳定版（默认下载到脚本所在目录）
.\chromium_build_win.bat

# 指定下载目录
.\chromium_build_win.bat --dir D:\download

# 指定分支（Chromium 的 branch number，对应 refs/branch-heads/7871）
.\chromium_build_win.bat --dir D:\download --version 7871

# 指定精确 tag
.\chromium_build_win.bat --dir D:\download --version 131.0.6778.85

# 指定 milestone 的最新稳定版
.\chromium_build_win.bat --dir D:\download --milestone 131

# release 配置 + 只构建部分目标
.\chromium_build_win.bat --dir D:\download --release --targets chrome,content_shell

# 只准备 depot_tools（不下载 Chromium），之后可手动/离线使用
.\chromium_build_win.bat --dir D:\download --depot-tools-only
```

`--depot-tools-only` 完成后会打印如何把它加入 `PATH` 并设置
`DEPOT_TOOLS_WIN_TOOLCHAIN`；之后要拉 Chromium 时，去掉该参数重跑本脚本即可。

下载目录结构：

```
<dir>\
  depot_tools\        # 浅克隆
  chromium\
    .gclient
    src\              # Chromium 源码（浅拷贝）
    _bad_scm\         # gclient 冲突恢复目录，可删
  tools\git\          # 若系统没有 git，自动下载的 PortableGit
```

## 主脚本参数

| 参数 | 说明 |
| --- | --- |
| `--dir PATH` | 下载/构建根目录，默认脚本所在目录。路径**不能含空格** |
| `--version VER` | 版本，见下方“版本语义” |
| `--milestone N` | 改用某 milestone 的最新稳定版 |
| `--target NAME` | 追加一个构建目标（可重复） |
| `--targets A,B,C` | 逗号分隔的目标列表。默认 `chrome,content_shell,headless_shell,mini_installer` |
| `--build-dir DIR` | GN 输出目录，默认 `out\Default` |
| `--release` / `--debug` | `is_debug=false` / 默认 debug |
| `--jobs N` | 覆盖并行编译任务数 |
| `--gn-args "ARGS"` | 额外 GN 参数，如 `--gn-args "is_component_build=true"` |
| `--retries N` | 首次 fetch 失败时的重试次数，默认 2（应对 429 限流等瞬时故障） |
| `--win-toolchain auto\|0\|1` | 设置 `DEPOT_TOOLS_WIN_TOOLCHAIN`，**默认 auto**：检测到本机 VS 用 `0`，否则用 `1` |
| `--no-win-toolchain` | 等价 `--win-toolchain 0`（使用本机已装的 Visual Studio） |
| `--win-toolchain-url URL` | 用预编译工具链归档替代本机 VS/内部 bucket：设置 `DEPOT_TOOLS_WIN_TOOLCHAIN_BASE_URL`，隐含 `--win-toolchain 1`，**无需安装 VS**（详见下文） |
| `--win-toolchain-hash H` | 本地打包归档的 `<H>.zip`：设置 `GYP_MSVS_HASH_<canonical>=H`，让自建工具链被接受（本地目录可自动探测，http 需显式指定） |
| `--with-branch-heads` | 切分支时给 gclient 加 `--with_branch_heads`，会抓**所有** release 分支，可能让 `src\.git` 增加十几 GB；默认关闭，仅当 gclient 报错时再开 |
| `--with-tags` | 切 tag 时给 gclient 加 `--with_tags`，会抓**所有** tag，体积也可能很大；默认关闭 |
| `--pinned` | **只抓指定 revision**，跳过先抓 main 的浅同步——已知版本时 `.git` 最小 |
| `--gc` | checkout 后执行 `git gc --prune=now`，回收不可达对象 |
| `--pgo` | 下载并使用 Windows PGO profile：在 `.gclient` 写入 `checkout_pgo_profiles=True`，让 `runhooks` 下载 `src/chrome/build/pgo_profiles/*.profdata`，并加 GN `chrome_pgo_phase=2`（同时强制 release） |
| `--arch ARCH` | 目标 CPU：`x64`（主机默认）、`x86`、`arm64`；映射为 GN `target_cpu`，x86/arm64 在 x64 主机上交叉编译 |
| `--full-deps` | 一次性下载一整套可离线使用的可选依赖（clang-tidy、clangd、覆盖率工具、PGO profile、bazelisk、libaom/libvpx 测试数据、WPR 归档） |
| `--deps K=V,...` | 直接设置任意 `.gclient` `custom_vars`（DEPS 变量），在 sync 之前生效，如 `--deps "checkout_clangd=True"` |
| `--add-defender-exclusions` | 把下载根目录和 `~/.cipd` 加入 Windows Defender 排除（需管理员） |
| `--skip-fetch` | 不下载，使用已有 checkout |
| `--skip-hooks` | 不跑 `gclient runhooks`（也不下载工具链） |
| `--skip-build` | 只下载/配置，不编译 |
| `--depot-tools-only` | 只把 depot_tools 克隆并 bootstrap 到可用状态（git 配置、python/CIPD），**不下载 Chromium/依赖/工具链，不编译**，随后退出 |
| `--no-bootstrap-git` | 不自动下载 PortableGit |
| `-h, --help` | 帮助 |

### 版本语义

| 输入 | 解释 |
| --- | --- |
| `stable` / `latest` | Chromium Dash 上的最新稳定版 tag（默认） |
| `154.0.8037.17`（四段数字） | 精确 release tag |
| `7871`（纯数字） | 分支 → `refs/branch-heads/7871` |
| `branch-heads/7871`、`refs/...`、`main` | 分支/ref 原样使用 |

纯数字是**分支号**，不是 milestone；milestone 请用 `--milestone N`。
指定的版本若拉取失败，会自动回退到最新稳定版。

## 工作原理

1. 检查 git；若没有，自动下载 PortableGit（可用 `--no-bootstrap-git` 关闭）。
2. 浅克隆 depot_tools（`git clone --depth 1`）。
3. `gclient` 首次运行会 bootstrap python 等。
4. `fetch --nohooks --no-history chromium` 浅拷贝源码和依赖。
5. 解析版本；自己 `git fetch --depth 1 <ref>` + `git checkout` 到目标版本，再
   `gclient sync --nohooks --no-history` **只同步依赖**（不用 `gclient sync --revision`，
   原因见“切版本时 .git 暴涨”）。
6. `gclient runhooks` —— 执行工具链相关 hook。
7. `gn gen` + `autoninja` 逐个构建目标（单个目标失败不影响其余，最后汇总）。

### 工具链在哪一步下载

- 源码**浅拷贝**发生在 `fetch`（`--no-history`）或脚本自己的浅取。
- **Chromium 自带的 clang**：由 DEPS 的 gcs 依赖在 **`gclient sync`** 阶段下载到
  `third_party/llvm-build/Release+Asserts`（公开 bucket，可正常下载）。
- **MSVC 头文件/库 + Windows SDK**（二选一）：
  - `DEPOT_TOOLS_WIN_TOOLCHAIN=0`：使用**本机已安装的 Visual Studio**（外部用户必须）。
  - `DEPOT_TOOLS_WIN_TOOLCHAIN=1`：`runhooks` 执行 `build/vs_toolchain.py update`，从
    `gs://chrome-wintoolchain` 按 SHA 拉取预编译工具链并缓存。**该 bucket 为 Google 内部，
    匿名访问会返回 401/403**，外部用户不可用（实测 `storage.googleapis.com/chrome-wintoolchain/...`
    返回 403，而公开的 clang bucket 返回 200）。
- 因此脚本默认 `--win-toolchain auto`：检测到本机 VS 就用 0，否则用 1。
- CIPD 包（如 `chrome_win_x86`）是在 `gclient sync` 阶段安装的，与工具链是两回事。

## 免安装 VS：使用工具链归档（`--win-toolchain-url`）

如果不想/不能在编译机上安装 Visual Studio，可以让 `runhooks` 从一份工具链归档解压使用。

原理（都是 Chromium 官方机制）：

- `build/vs_toolchain.py` 读取 `DEPOT_TOOLS_WIN_TOOLCHAIN_BASE_URL`，从该目录取 `<hash>.zip`。
- 它支持把“规范 hash”映射到你自建的 hash：
  ```python
  key = 'GYP_MSVS_HASH_%s' % TOOLCHAIN_HASH
  return [os.environ.get(key, TOOLCHAIN_HASH)]
  ```
  即设置 `GYP_MSVS_HASH_<canonical>=<your-hash>`，自建归档就会被采用。

### 一键生成归档：`prepare_win_toolchain`

`prepare_win_toolchain.ps1` 会：下载并静默安装 **VS 2026**（可选版本），再用 depot_tools 自带的
`win_toolchain/package_from_installed.py` 打包成 `<local-hash>.zip`，并写出映射文件。内置：

- **VS 版本选择** `--vs-edition buildtools|community|professional|enterprise`（默认 `buildtools`）。
- **Windows SDK 检查/安装**：检查所需 SDK（来自 `build/vs_toolchain.py` 的 `SDK_VERSION`，本仓库
  `10.0.26100.0`）及调试器；缺失时给出官方安装说明，`--install-sdk` 会用 VS 组件
  `Microsoft.VisualStudio.Component.Windows11SDK.26100` 自动装上；`--sdk-installer <winsdksetup.exe>`
  还能自动装 “Debugging Tools for Windows”。

```powershell
# 管理员运行；下载并静默安装 Build Tools（数 GB）
.\prepare_win_toolchain.bat --dir D:\wt --chromium-src D:\download\chromium\src

# 个人使用：Community；公司内部：用 buildtools 或 professional/enterprise
.\prepare_win_toolchain.bat --dir D:\wt --vs-edition community
.\prepare_win_toolchain.bat --dir D:\wt --vs-edition professional
.\prepare_win_toolchain.bat --dir D:\wt --no-arm64          # 仅 x86/x64（默认含 ARM64）

# 同时自动安装所需 Windows SDK（及其调试器，若给了 installer）
.\prepare_win_toolchain.bat --dir D:\wt --install-sdk
.\prepare_win_toolchain.bat --dir D:\wt --install-sdk --sdk-installer C:\Downloads\winsdksetup.exe

# 已自行下好 bootstrapper，或 VS 已装好：
.\prepare_win_toolchain.bat --dir D:\wt --vs-bootstrapper C:\Downloads\vs_BuildTools.exe
.\prepare_win_toolchain.bat --dir D:\wt --skip-install
```

**只依赖 depot_tools（没有 Chromium 源码也能打包）**

打包器 `win_toolchain/package_from_installed.py` 就在 **depot_tools 本身**里，所以只打包 zip 时
**不需要 Chromium 源码**；只有“自动读取 canonical hash / SDK 版本”这一步才需要源码，可以用参数替代：

- `--canonical-hash <hash>`：目标 Chromium revision 的 `TOOLCHAIN_HASH`（用于写映射）。可从该 revision 的
  `build/vs_toolchain.py`、或一次 `gclient sync` 失败日志里的 `desired_hash:`、或主脚本 checkouts 里获取。可省略。
- `--sdk-version <ver>`：打包用的 SDK 版本（应与目标 Chromium 的 `SDK_VERSION` 一致）。无源码时**必填**
  （或机器上只装了一个 SDK 时脚本会自动采用）。
- `--depot-tools DIR`：指定 depot_tools（提供 packager 与 `python3.bat`）。

```powershell
# 只有 depot_tools，没有 Chromium 源码
.\prepare_win_toolchain.bat --dir D:\wt --depot-tools D:\download\depot_tools `
    --canonical-hash e66617bc68 --sdk-version 10.0.26100.0 --skip-install

# 有 Chromium 源码时（自动读 hash 与 SDK 版本，可省略上面两个参数）
.\prepare_win_toolchain.bat --dir D:\wt --chromium-src D:\download\chromium\src
```

说明：
- `--chromium-src` 现在是**可选**：给了就读 `build/vs_toolchain.py`；没给就要求 `--sdk-version`
  （`--canonical-hash` 可省，只是 `TOOLCHAIN_INFO.txt` 里不写 `GYP_MSVS_HASH_*`，之后用主脚本的
  `--win-toolchain-hash <local-hash>` 补上即可）。
- packager 查找顺序：`--depot-tools\win_toolchain\...` → `<root>\depot_tools\win_toolchain\...` →
  `<chromium-src>\third_party\depot_tools\win_toolchain\...`。

**按版本作用域 + 逐组件检查 + 只用指定版本**

脚本现在是“实例感知”的，严格按你指定的版本工作：

- **只认指定版本**：`--vs-edition` 决定 VS 产品 ID（Community/Professional/Enterprise/BuildTools）。
  只检查/安装该产品；机器上别的版本**一律忽略**，打包也**只从指定版本的这个实例**取（脚本会生成一个
  小 wrapper 强制 `package_from_installed.py` 使用该实例路径，避免它误选其它版本）。
- **逐组件检查、缺啥装啥**：对每个必需组件用 `vswhere -requires` 检查（VC 工具集、ATLMFC、以及
  `--install-sdk` 时的 `Windows11SDK.<build>`、ARM64 组件（**默认包含**，用 `--no-arm64` 关闭））。已装则跳过；
  只把**缺失的组件**传给安装器（对已存在实例执行“增量添加”）；整个版本没装才全新安装。
- **可选用系统已有**：`--prefer-installed` 时，若机器上**任意**版本的 VS 2026 实例已具备全部必需组件，
  就直接复用它、不安装（仍会校验组件）。
- 版本范围锁定为 **VS 2026（productLineVersion 18）**，VS 2022 等不会被匹配。

**VS 版本与许可（按许可选，不是按喜好）**

| `--vs-edition` | 说明 |
| --- | --- |
| `buildtools`（默认） | 免费、无 IDE，推荐用于 CI；个人/公司都可用（公司使用请查 EULA） |
| `community` | 免费 IDE，**仅限个人/小型组织**（约 <250 台设备且 <100 万美元收入）；大型企业**不可用** |
| `professional` / `enterprise` | 公司内部开发应使用（或公司已有的 VS 批量授权） |

**Windows SDK**

- Chromium 需要**某一个特定版本**（`build/vs_toolchain.py` 的 `SDK_VERSION`），并非越新越好。
- 安装途径：上面的 `--install-sdk`（VS 组件）或 `--sdk-installer`（独立 SDK），也可手动到
  https://developer.microsoft.com/windows/downloads/windows-sdk/ 下载 `winsdksetup.exe` 并勾选
  “Debugging Tools for Windows”。
- `package_from_installed.py` **必须**有 SDK 调试器目录 `Windows Kits\10\Debuggers`，否则打包失败。

完成后在 `<out>\`（默认 `D:\wt\win_toolchain_archive`）得到 `<local-hash>.zip` 与
`TOOLCHAIN_INFO.txt`（含 `GYP_MSVS_HASH_<canonical>=<local-hash>` 以及
`DEPOT_TOOLS_WIN_TOOLCHAIN_BASE_URL`）。

然后编译（主脚本对**本地目录**会自动探测 zip 并设置映射）：

```powershell
# 本地归档
.\chromium_build_win.bat --dir D:\download --version 7871 --win-toolchain-url "file://D:/wt/win_toolchain_archive/"

# http 镜像（无法列目录，需显式给 hash）
.\chromium_build_win.bat --dir D:\download --version 7871 --win-toolchain-url "https://mirror.corp/win_toolchain/" --win-toolchain-hash <local-hash>
```

约定与注意：

- URL 是**目录**（不是 zip 本身）；本地用 `file://D:/.../`（或 `file:///D:/.../`），http 结尾自动补 `/`。
- `--win-toolchain-url` 隐含 `--win-toolchain 1`，并设置 `DEPOT_TOOLS_WIN_TOOLCHAIN_BASE_URL`。
- “规范 hash”（canonical）来自当前 revision 的 `build/vs_toolchain.py` 的 `TOOLCHAIN_HASH`
  （本仓库为 `e66617bc68`），脚本会自动读取。
- `package_from_installed.py` 只支持 **VS 2026**，并且要求装好 **Windows SDK 调试器**
  （`Windows Kits\10\Debuggers`），否则会报错。
- VS 2026 的 bootstrapper：脚本默认从 **`https://aka.ms/vs/stable/vs_<Edition>.exe`** 下载
  （`aka.ms/vs/stable/channel` 的清单就是 `VisualStudio.18.Release.chman`，确认 stable = VS 2026）。
  若该短链不可用（下载到的是网页而非 exe，脚本会校验并报错），请到
  https://visualstudio.microsoft.com/downloads/ 手动下载对应的 `vs_<Edition>.exe`，
  再用 `--vs-bootstrapper <路径>` 传入。数字大版本通道也可用：`--vs-channel 17` → `aka.ms/vs/17/release/...`。
- `prepare_win_toolchain.ps1` 需要**管理员**权限；本脚本编写环境无管理员/无 VS 下载，**未做端到端实测**。

### 许可与合规提示（非法律意见）

- **Chromium 源码**是 BSD 风格许可，可自由使用/修改/分发。
- **Visual Studio / MSVC / Windows SDK** 是微软产品，受其自身许可约束；用它们“编译”你的程序
  一般是被允许的，但**再分发**（如随产品附带 DLL、或把 SDK/工具链整体拷贝分发）有额外条件。
- **VS Community 版**对**大型企业**（大致为 >250 台设备或年收入 >100 万美元）**不在授权范围内**。
  大公司内部开发通常应使用 **Professional/Enterprise**（或公司已有的批量授权），不要用 Community。
  这正是 `prepare_win_toolchain` 提供 `--vs-edition` 的原因：个人用 `community`，公司用
  `professional`/`enterprise`（或 `buildtools`）。
- **Build Tools for Visual Studio** 是官方提供、可免费下载的“无 IDE”形态，常用于 CI；其许可条款
  与对应 VS 版本一致。是否可用于你司内部，请以安装器内的 EULA 为准。
- 把工具链归档**在公司内网**用 `--win-toolchain-url` 共享，属于公司内部再分发，**需先确认你司与
  微软的授权是否允许**（很多企业授权允许内部使用，但不允许对外分发）。

> 建议：在大规模落地前，把“使用 MSVC/Build Tools + Windows SDK 编译并内部共享工具链”的合规性
> 交给公司法务/IT 许可团队确认。脚本本身不改变任何许可条款。

## 常见问题

### Windows Defender 拦截（fetch 失败）

报错示例：

```
Failed to open the instance chromium/third_party/updater/chrome_win_x86:...
Operation did not complete successfully because the file contains a virus or
potentially unwanted software.
```

这是 Defender 误判并隔离了 CIPD 包（Chrome 更新器二进制），导致 `cipd ensure` 失败。
`_bad_scm` 相关输出只是 gclient 自我恢复的警告，非致命。

处理（管理员 PowerShell）：

```powershell
Add-MpPreference -ExclusionPath "D:\download"
Add-MpPreference -ExclusionPath "$env:USERPROFILE\.cipd"   # 可选
```

然后恢复（`.gclient` 已生成，无需重新 fetch）：

```powershell
cd D:\download\chromium\src
gclient sync --nohooks --no-history
```

或重跑脚本并加 `--add-defender-exclusions`，它会跳过 fetch、补齐 CIPD 包后再 runhooks。

### 源站限流 HTTP 429 / 下载长时间停顿

报错示例：

```
remote: RESOURCE_EXHAUSTED: Resource has been exhausted (e.g. check quota)
remote:   subject: "shared/shared_anonymous"
remote:   description: "Short term server-time rate limit exceeded"
fatal: unable to access 'https://webrtc.googlesource.com/src.git/': The requested URL returned error: 429
error: RPC failed; HTTP 429 curl 22 The requested URL returned error: 429
fatal: expected 'packfile'
```

或：

```
STALL DETECTED: gclient has been silent for 5 minutes.
   src/third_party/rust-toolchain:Win/rust-toolchain-....tar.xz (Running for 0:41:46)
```

这是 Google 源码服务器**短时限流**或某个大文件下载**卡住**，不是脚本问题，也和 Defender 无关。

处理：**直接重跑原脚本即可**。原因：`chromium\.gclient` 已经生成，脚本检测到后会
**跳过 fetch**，改为续传：

- 默认 `--version stable` → `gclient sync --no-history --revision src@<稳定版 tag>`
- `--version main` → `gclient sync --no-history --revision src@main --with_branch_heads`
- 已存在的项目会被快速跳过，只补下失败/缺失的项目。

建议：

1. 等几分钟再跑（429 是“短时限流”）。
2. 脚本默认对首次 fetch 重试 2 次、间隔递增；可用 `--retries N` 调整（`--retries 0` 关闭）。
   切换版本（`gclient sync --revision`）同样会重试。
3. 失败提示会区分：429 限流 / 下载停顿 / Defender / 网络，并给出重跑与续传命令。
4. **只有请求的 ref 确实不存在时才会回退到最新稳定版**。脚本先用
   `git ls-remote --exit-code` 判断 ref 是否存在（不下载对象）；若 ref 存在但同步失败，
   会视为瞬时故障并重试，**绝不会**因为一次 429 就偷偷换成别的版本。
4. 可选清理被隔离的冲突目录后再跑，回收磁盘：
   ```powershell
   Remove-Item -Recurse -Force D:\git\download\chromium\_bad_scm
   ```
   `_bad_scm` 每次失败都会累积，属正常现象；续传会逐个项目补齐。
5. 手动续传：
   ```powershell
   cd D:\git\download\chromium\src
   gclient sync --nohooks --no-history
   ```

### 切版本时 `src\.git` 暴涨（出现十几 GB 的 `tmp_pack_*`）

现象：用 `--version <分支/tag>` 重跑后，`chromium\src\.git\objects\pack\` 里出现一个
十几 GB 的 `tmp_pack_xxxx`，而初始浅拷贝的 pack 只有约 1.5 GB。

例如：

```
.git\objects\pack\
  pack-31e29592....pack       1.45 GB   <- 初始浅拷贝
  tmp_pack_JEu8zY            18.18 GB   <- 切版本时的临时 fetch pack
```

原因：这是 **“浅克隆 + 事后切换版本”** 的固有矛盾，不是参数写错，也不是仓库损坏。

- `7871` 会被正确解析为 `refs/branch-heads/7871`，参数本身没错。
- 但要从“main 的 depth=1 浅拷贝”切换到另一个分支，git 需要补足连通所需的对象；
  显式 `--revision` 的抓取往往不走浅拷贝，可能拉取大量历史。
- 旧默认还会加 `--with_branch_heads`/`--with_tags`，它们会抓取**所有分支/所有 tag**，
  是体积暴涨的主要放大器。
- `tmp_pack_*` 是 git 写入中的**临时** pack：fetch 正常结束后会被转正或清理；只有
  进程被中断时才会残留。

规避与处理：

1. 正在运行就让它跑完；`tmp_pack` 完成后会消失/转正。
2. 脚本**不再使用** `gclient sync --revision`：实测它对**主仓库**会忽略 `--no-history`，跑一条
   完整的 `git fetch origin --no-tags`，拉取十几 GB 历史并可能长时间卡住（STALL）。
   现在改为：
   - 自己执行 `git fetch --depth 1 origin <ref>` + `git checkout --detach <sha>`（浅取目标版本）；
   - 写入本地 `refs/remotes/origin/main` 与 `refs/remotes/origin/HEAD`，避免 gclient 触发网络的
     `git remote set-head -a origin`（同样会卡住）；
   - 再跑 `gclient sync --nohooks --no-history`，此时 `.gclient` 为 unmanaged，gclient **不动 src**，
     只浅同步依赖（日志可见各依赖都是 `--depth=1`）。
   这样 `src\.git` 始终保持目标版本的一份浅 pack（约 1–2 GB）。
   `--with_branch_heads`/`--with_tags` 仍为 opt-in（默认关），用于极端情况。
3. **脚本启动时会自动清理残留的临时包**：在 `src\.git\objects\pack\` 下查找 `tmp_*`
   （`tmp_pack_*`/`tmp_idx_*`/`tmp_rev_*`）并删除。这类文件 git 后续**不会读取**，是纯粹的
   磁盘垃圾；只有被中断的 fetch 才会残留。若文件正被其它 git 进程写入，Windows 会锁定，
   删除会失败并跳过（不会误删）。也可手动删除：
   ```powershell
   Remove-Item D:\git\download\chromium\src\.git\objects\pack\tmp_* -Force
   ```
4. 也可用 `--gc` 在 checkout 后执行 `git -C src gc --prune=now` 回收不可达对象。

#### 如何确保 `.git` 最小

关键是**不要让 gclient 先抓 main 再切版本**（那会多留一份 main 的对象，切不同分支还可能再拉历史）。
做法：

1. **一开始就确定版本**（branch / tag / milestone）。
2. 加 `--pinned`：脚本只做 `gclient config` + 一次 `gclient sync --no-history --revision src@<ref>`，
   不抓 main。结果就是**只含目标版本的一份浅 pack（约 1–2 GB）**：
   ```powershell
   .\chromium_build_win.bat --dir D:\download --version 7871 --pinned
   .\chromium_build_win.bat --dir D:\download --version 154.0.8037.17 --pinned
   .\chromium_build_win.bat --dir D:\download --milestone 131 --pinned
   ```
3. 如果已有旧 checkout、想换成最小：先删掉源码目录再按上面重来（依赖的 `.git` 也会重新浅取）：
   ```powershell
   Remove-Item -Recurse -Force D:\download\chromium\src
   .\chromium_build_win.bat --dir D:\download --version 7871 --pinned
   ```
   删掉 `src` 但保留 `chromium\.gclient` 也没关系：脚本会检测到“有 `.gclient`、没有 `src`”，
   直接复用该配置并通过 `gclient sync` 重建 `src`（不会再先抓 main）。
4. `git gc --prune=now` 只能清理**不可达**对象。若你反复来回切换版本，两个版本都可达，就删不掉；
   真正要“最小”还是按上面的方式重建。

> 注意：`--pinned` 适合“只构建一个版本”。如果你会频繁在多个版本间切换，保留 main 的浅拷贝反而
> 更省事，此时不必加 `--pinned`。

### PowerShell 被限制

脚本会自检并给出提示：

- **执行策略**为 `Restricted`/`AllSigned`：
  ```powershell
  Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
  ```
  或始终通过 `.bat` 启动（它使用 `-ExecutionPolicy Bypass`）。
- **文件来自网络**（Mark of the Web）：
  ```powershell
  Unblock-File -Path .\chromium_build_win.ps1
  ```
- **ConstrainedLanguage / AppLocker / WDAC**（受管机器）：由策略强制，用户无法用单条命令
  关闭。检查：
  ```powershell
  Get-AppLockerPolicy -Effective -Xml
  Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard
  ```
  需管理员放开策略，或改用非受管机器。`.bat` 启动前会实际试跑一次脚本，失败时打印
  PowerShell 的原始报错及上述处理办法。

## depot_tools 历史版本

### 有没有官方对应关系？

**没有。** depot_tools 不是 Chromium 的依赖，不出现在 `DEPS` 里，因此不存在“某 Chromium tag
对应某 depot_tools commit”的官方映射表。可行做法是**按时间戳近似关联**：

1. 把 Chromium 版本解析成它的 commit 及其 commit 日期（gitiles / Chromium Dash）。
2. 在 depot_tools `main` 历史里取“该日期当天或之前”的最后一个 commit。

### 查找脚本

```powershell
.\find_depot_tools_version.bat --version 131.0.6778.85
.\find_depot_tools_version.bat --version 7871
.\find_depot_tools_version.bat --milestone 108
.\find_depot_tools_version.bat --date 2022-12-12
.\find_depot_tools_version.bat --version 108.0.5359.125 --checkout
```

参数：`--version`、`--milestone`、`--date`、`--chromium-hash`、`--depot-tools PATH`、
`--num`（log 页大小）、`--max-pages`、`--checkout`。

示例结果：

- `131.0.6778.85`（2024-11-18）→ depot_tools `f37e7f46`（2024-11-18）
- `108.0.5359.125`（2022-12-12）→ depot_tools `a964ca12`（2022-12-09）

### 有必要把 depot_tools 切到历史版本吗？

**一般不需要。**

1. 最新 depot_tools 通常能正确处理旧 Chromium 的 DEPS，官方也推荐用最新版。
2. **Windows 工具链与 depot_tools 版本无关**：`win_toolchain` 由被检出的那个 Chromium
   revision 自身的 `build/vs_toolchain.py` + DEPS 里记录的 SHA 决定，会自动匹配当年版本。
3. 旧 depot_tools 反而可能缺少修复、对新 Windows / Python / 协议不兼容。
4. 只有用最新 depot_tools 同步旧版本确实报错时，才需要 pin。

pin 与恢复（脚本也会打印）：

```powershell
# pin
git -C .\depot_tools fetch --depth 1 origin <commit>
git -C .\depot_tools checkout --detach <commit>
$env:DEPOT_TOOLS_UPDATE = "0"     # 阻止 depot_tools 自动更新回 tip

# 恢复
git -C .\depot_tools fetch --depth 1 origin main
git -C .\depot_tools checkout -B main FETCH_HEAD
Remove-Item Env:\DEPOT_TOOLS_UPDATE
```

局限：这是按日期的近似（“当天或之前”）；查更早的版本可增大 `--num` / `--max-pages`。

## 可选依赖开关（下载环境 ≠ 开发环境时）

Chromium 很多额外内容用 `DEPS` 里的变量做开关，**默认 False**，普通 `gclient sync` **不会**下载。
如果“联网下载”和“离线开发”是两台机器，最好在**联网阶段**把这些开关打开、一次下全。

脚本提供：

```powershell
# 一键：下载一整套可离线使用的 Windows 开发/测试依赖
.\chromium_build_win.bat --dir D:\download --full-deps

# 精细控制：直接写 custom_vars
.\chromium_build_win.bat --dir D:\download --deps "checkout_clangd=True,checkout_wpr_archives=True"
```

`--full-deps` 等价于启用下列这些（都可再单独用 `--deps` 覆盖）：

| DEPS 变量 | 内容 |
| --- | --- |
| `checkout_clang_tidy` | clang-tidy（与 clang 同目录） |
| `checkout_clangd` | clangd 语言服务器 |
| `checkout_clang_coverage_tools` | `llvm-cov` / `llvm-profdata`（`use_clang_coverage` 用） |
| `checkout_pgo_profiles` | Windows PGO profile（几百 MB，`--pgo` 也开这个） |
| `checkout_bazelisk` | 仅打包 `rust-toolchain` 用 |
| `download_libaom_testdata` | AV1 编解码测试数据 |
| `download_libvpx_testdata` | VP8/VP9 测试数据 |
| `checkout_wpr_archives` | Web Page Replay 归档（**较大**，跑 web 测试用） |

其余 Windows 相关但**默认关闭**的开关（按需用 `--deps` 开；有些需要 Google 权限，外部用户开不了）：

| DEPS 变量 | 默认 | 说明 |
| --- | --- | --- |
| `checkout_telemetry_dependencies` | False | 性能测试依赖，部分仅内部可见 |
| `checkout_clusterfuzz_data` | False | 模糊测试归档 |
| `checkout_chromium_autofill_test_dependencies` | False | 仅 Googler（超大网页捕获文件） |
| `checkout_chromium_password_manager_test_dependencies` | False | 仅 Googler（超大网页捕获文件） |
| `checkout_soda` | False | 需 `checkout_src_internal`（内部） |
| `checkout_glic_e2e_tests` | False | glic E2E 测试代码/归档 |
| `checkout_src_internal` / `checkout_google_internal` | False | Google 内部源码 |
| `download_remoteexec_cfg` / `download_reclient` | False / 依 ChromeOS | 远程执行配置/客户端 |
| `checkout_instrumented_libraries` | False | 仅 Linux MSan |
| `checkout_mutter` | False | 仅 Linux（Wayland compositor 测试） |
| `checkout_cast3p` | False | Cast3P |
| `checkout_android` / `checkout_fuchsia` / `checkout_chromeos` / `checkout_ios_*` | False | 其他平台，Windows 上无需 |

默认**已开启**（无需处理）：`checkout_js_coverage_modules`、`checkout_openxr`（Win 默认开）、
`checkout_gpu_meet_effects`、`checkout_press_benchmarks`（后两者在 `checkout_configuration="small"` 时关闭）。

补充：

- 想**减少**下载可用 `--deps "checkout_configuration=small"`（跳过一些非构建必需项）。
- 用 `--deps` 设置的值会写入 `.gclient` 的 `custom_vars`，**在 sync 之前**生效（脚本已调整顺序），
  因此当次 sync 就会把对应内容下下来。
- 真正“离线可构建”还需要：`clang`（默认会下）、`win_toolchain`（`gclient runhooks` 时下，
  脚本默认执行）、depot_tools 的 python/bootstrap。联网跑一次完整脚本（含 runhooks）即可缓存。
- 这些只是**额外**内容；**构建本身所需**的依赖在默认 sync 中已全部包含，离线构建通常无需 `--full-deps`。

## CPU 架构与交叉编译（--arch）

`--arch` 接受 `x64`、`x86`、`arm64`，脚本会转成 GN 参数 `target_cpu`：

```powershell
# 默认：按主机（x64）
.\chromium_build_win.bat --dir D:\download

# 32 位 x86
.\chromium_build_win.bat --dir D:\download --arch x86 --release

# arm64（在 x64 主机上交叉编译）
.\chromium_build_win.bat --dir D:\download --arch arm64 --release
```

说明：

- `--arch` 只是设置 `target_cpu`；`target_os` 仍为 `win`（我们在 Windows 上运行）。
- **工具链包含 ARM64 库**：`build/vs_toolchain.py` 注释为 “VS 2026 18 with 10.0.28000.2270 SDK
  with ARM64 libraries and UWP support”，且代码已处理 `target_cpu == 'arm64'` 的 VCRuntime 目录。
  Chromium 自带的 clang 是交叉编译器，可产出 arm64。
- 若用**本机 VS**（`DEPOT_TOOLS_WIN_TOOLCHAIN=0`，外部用户路径），需在 VS 安装器里额外勾选
  `Microsoft.VisualStudio.Component.VC.Tools.ARM64` 与 `VC.MFC.ARM64`，否则缺 arm64 库。
  （`DEPOT_TOOLS_WIN_TOOLCHAIN=1` 的 Google 内部预编译包已带 ARM64，但外部不可用。）
- **产物只能在其目标架构上运行**：arm64 产物需 Windows on Arm 才能运行（x64 Windows 不能直接跑 arm64 程序）。
- 若 `--arch` 值非法，脚本会告警并回退到主机默认。
- 也可继续用 `--gn-args "target_cpu=\"arm64\""` 达到同样效果；两者都提供时以 `--gn-args` 为准（脚本不重复添加）。

## PGO（Profile Guided Optimization）

**默认不会下载 PGO 文件。** Chromium 的 `DEPS` 里有下载 PGO profile 的 hook，但条件是
`checkout_pgo_profiles and checkout_win`，而 `checkout_pgo_profiles` 默认为 `False`
（见 `DEPS`）。所以即使执行了 `gclient runhooks` 也会跳过。

- profile 落地位置：`src\chrome\build\pgo_profiles\*.profdata`
  （配套文本配置在 `src\chrome\build\*.pgo.txt`）；由
  `src\tools\update_pgo_profiles.py` 下载，win32/win64/win-arm64 各一份，通常几百 MB。
- `chrome_pgo_phase` 的默认逻辑（`build/config/compiler/pgo/pgo.gni`）：
  普通构建为 `0`；仅当 `is_official_build` 且平台为 win/mac/linux 等时才自动设为 `2`。
  并且有断言 `!is_debug || chrome_pgo_phase == 0` —— 即 **debug 构建不能用 PGO**。

使用 `--pgo` 会自动：

1. 在 `.gclient` 的 `src` solution 写入 `custom_vars: { checkout_pgo_profiles: True }`
   （用 `gclient config --custom-var checkout_pgo_profiles=True`），使 `runhooks` 下载 profile；
2. 加 GN 参数 `chrome_pgo_phase=2`，并强制 release（`is_debug=false`）。

```powershell
.\chromium_build_win.bat --dir D:\download --version 7871 --pgo
```

说明与注意：

- 顺序很重要：**先下载 profile（runhooks），再 `gn gen`**；脚本已按此顺序执行。
  若用 `--skip-hooks --pgo`，profile 不会下载，构建会报错（脚本会提前警告）。
- `--pgo` 只加 `chrome_pgo_phase=2` + release。若要做**真正的官方级构建**，再加
  `--gn-args "is_official_build=true"`（此时 phase 默认即为 2），注意官方构建更慢、更吃内存。
- 想关闭 PGO 用 `--gn-args "chrome_pgo_phase=0"`。

## 系统要求

- Windows 10/11 x64
- 8 GB+ 内存（建议 16 GB+）
- 100 GB+ 空闲 NTFS 磁盘（FAT32 不行，部分 Git pack 超过 4 GB）
- 联网
- Git for Windows（缺失时自动下载 PortableGit）
- **Visual Studio 2026（或 Build Tools）**，需 “Desktop development with C++” 与 “MFC/ATL” 组件。
  这是外部用户的**硬性要求**（预编译工具链为 Google 内部资源）。安装命令示例：

  ```powershell
  # 以管理员运行 VS 安装器（Community 版）
  & "$env:TEMP\vs_Community.exe" `
      --add Microsoft.VisualStudio.Workload.NativeDesktop `
      --add Microsoft.VisualStudio.Component.VC.ATLMFC `
      --includeRecommended
  ```

  安装后脚本的 `--win-toolchain auto` 会自动检测并使用本机 VS（`DEPOT_TOOLS_WIN_TOOLCHAIN=0`）。
