# ============================================================================
#  prepare_win_toolchain.ps1
#  ---------------------------------------------------------------------------
#  Download + silently install a Visual Studio 2026 edition, then package it
#  into a Chromium-compatible win_toolchain archive so that
#  chromium_build_win.ps1 can consume it with --win-toolchain-url, WITHOUT
#  having to install Visual Studio on the build machine.
#
#  Editions (--vs-edition): buildtools (default, free, no IDE), community,
#  professional, enterprise. Choose by LICENSE: community is for individuals /
#  small orgs only; companies should use buildtools or professional/enterprise.
#  It can also check/install the required Windows SDK (--install-sdk,
#  --sdk-installer).
#
#  How it works (all pieces are official Chromium/depot_tools mechanisms):
#    1. depot_tools\win_toolchain\package_from_installed.py packages an
#       installed VS into "<sha1>.zip" (the exact layout Chromium expects).
#    2. Chromium's build/vs_toolchain.py supports mapping the canonical
#       toolchain hash to your own via the environment variable
#         GYP_MSVS_HASH_<canonical-hash>=<your-hash>
#       so a locally built archive is accepted.
#
#  Requirements
#    - Windows 10/11 x64, Administrator (VS install needs elevation)
#    - Several GB free disk, Internet access
#    - depot_tools (it ships win_toolchain\package_from_installed.py). A
#      Chromium checkout is OPTIONAL: it is only used to auto-read
#      TOOLCHAIN_HASH + SDK_VERSION, which you can pass via
#      --canonical-hash / --sdk-version instead.
#    - The VS 2026 bootstrapper. The script downloads it from
#      https://aka.ms/vs/stable/vs_<Edition>.exe (override with
#      --vs-boot-url / --vs-bootstrapper). If the short link is not reachable,
#      download "Build Tools for Visual Studio" from
#      https://visualstudio.microsoft.com/downloads/ and pass
#      --vs-bootstrapper <path-to-vs_BuildTools.exe>.
#
#  NOTE: this script performs a real VS install and was NOT executed in the
#  session that wrote it (no admin / no VS download). Treat it as best-effort
#  and follow the printed steps / Microsoft docs if an ID changes.
#
#  Examples
#    # Normal: download bootstrapper, install to .\BuildTools, package
#    .\prepare_win_toolchain.ps1 --dir D:\wt --chromium-src D:\download\chromium\src
#
#    # Use a bootstrapper you downloaded yourself, include ARM64
#    .\prepare_win_toolchain.ps1 --dir D:\wt `
#        --vs-bootstrapper C:\Downloads\vs_BuildTools.exe --with-arm64
#
#    # VS already installed: just package it
#    .\prepare_win_toolchain.ps1 --dir D:\wt --skip-install
# ============================================================================

$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
#  Options
# ---------------------------------------------------------------------------
$WorkDir        = $PSScriptRoot
$ChromiumSrc    = ''                 # optional: only needed to read TOOLCHAIN_HASH/SDK_VERSION
$CanonicalHash  = ''                 # optional: canonical TOOLCHAIN_HASH (if no chromium/src)
$OutDir         = ''
$VsInstallDir   = ''
$DepotTools     = ''                 # top-level depot_tools (packager + python3.bat)
$Bootstrapper   = ''                 # local path OR url to vs_<Edition>.exe
$BootUrl        = ''                 # '' -> derived from --vs-channel/--vs-edition
$VsWorkload     = ''                 # '' -> derived from --vs-edition
$VsEdition      = 'buildtools'       # buildtools | community | professional | enterprise
$VsChannel      = 'stable'           # aka.ms/vs/<channel>/... ; 'stable' == VS 2026
$Arm64          = $true              # ARM64 included by default (Chromium's own package does)
$SkipInstall    = $false
$PreferInstalled = $false            # use any existing compatible VS (any edition)
$SdkVersion     = ''
$InstallSdk     = $false             # add the Windows SDK (and try debuggers) silently
$SdkInstaller   = ''                 # winsdksetup.exe path or URL (standalone SDK)
$DryRun         = $false
$Help           = $false

$argv = @($args)
$i = 0
while ($i -lt $argv.Count) {
    $raw = [string]$argv[$i]
    $opt = $raw
    $inline = $null
    if ($raw -match '^(--?[^=]+)=(.*)$') { $opt = $matches[1]; $inline = $matches[2] }

    switch ($opt) {
        '--help'       { $Help = $true }
        '-h'           { $Help = $true }
        '/?'           { $Help = $true }
        '--with-arm64' { $Arm64 = $true }
        '--no-arm64'   { $Arm64 = $false }
        '--noarm'      { $Arm64 = $false }   # matches package_from_installed.py
        '--skip-install' { $SkipInstall = $true }
        '--prefer-installed' { $PreferInstalled = $true }
        '--install-sdk' { $InstallSdk = $true }
        '--dry-run'    { $DryRun = $true }
        default {
            $valueOptions = @('--dir', '--chromium-src', '--canonical-hash', '--out', '--vs-install-dir',
                              '--depot-tools', '--vs-bootstrapper', '--vs-boot-url', '--vs-workload',
                              '--sdk-version', '--vs-edition', '--vs-channel', '--sdk-installer')
            if ($valueOptions -contains $opt) {
                $v = $inline
                if ($null -eq $v) {
                    $i++
                    if ($i -ge $argv.Count) { throw "Option $opt requires a value." }
                    $v = [string]$argv[$i]
                }
                switch ($opt) {
                    '--dir'            { $WorkDir = $v }
                    '--chromium-src'   { $ChromiumSrc = $v }
                    '--canonical-hash' { $CanonicalHash = $v }
                    '--out'            { $OutDir = $v }
                    '--vs-install-dir' { $VsInstallDir = $v }
                    '--depot-tools'    { $DepotTools = $v }
                    '--vs-bootstrapper'{ $Bootstrapper = $v }
                    '--vs-boot-url'    { $BootUrl = $v }
                    '--vs-workload'    { $VsWorkload = $v }
                    '--sdk-version'    { $SdkVersion = $v }
                    '--vs-edition'     { $VsEdition = $v }
                    '--vs-channel'     { $VsChannel = $v }
                    '--sdk-installer'  { $SdkInstaller = $v }
                }
            } else {
                Write-Warning "Unknown option: $raw"
            }
        }
    }
    $i++
}

function Show-Help {
    Write-Host @"
Usage: prepare_win_toolchain.ps1 [options]

Downloads + installs VS 2026 Build Tools and packages a Chromium win_toolchain
archive usable with chromium_build_win.ps1 --win-toolchain-url.

Options:
  --dir DIR              Work directory. Default: this script's directory.
  --chromium-src DIR     OPTIONAL. A chromium/src checkout. If present, the
                         canonical TOOLCHAIN_HASH and SDK_VERSION are read from
                         its build/vs_toolchain.py. If absent, pass
                         --canonical-hash and --sdk-version instead: depot_tools
                         alone is enough to package (see below).
                         Default: auto-detected under --dir\chromium\src.
  --canonical-hash H     Canonical TOOLCHAIN_HASH of the Chromium revision you
                         will build (e.g. e66617bc68). Used only to write the
                         GYP_MSVS_HASH_<H>=<local> mapping into TOOLCHAIN_INFO.
                         Optional; without it the mapping is omitted.
  --depot-tools DIR      depot_tools clone. Provides
                         win_toolchain/package_from_installed.py + python3.bat.
                         Default: <root>\depot_tools, else the chromium/src
                         vendored copy, else python/python3 on PATH.
  --out DIR              Where the resulting <hash>.zip + mapping are written.
                         Default: <dir>\win_toolchain_archive.
  --vs-install-dir DIR   Install location for VS. Default: <dir>\<Edition>.
  --vs-edition E         buildtools (default) | community | professional |
                         enterprise. Pick by license, NOT by preference:
                           buildtools  - free, no IDE, recommended for CI;
                                         use for both individuals and companies
                                         (review the EULA for company use).
                           community   - free IDE, ONLY for individuals /
                                         small orgs (<250 users and <$1M
                                         revenue). NOT licensed for large
                                         enterprises.
                           professional/enterprise - use these (or your
                                         company's existing VS license) for
                                         internal company development.
  --vs-channel C         aka.ms channel. Default: stable (= VS 2026, i.e.
                         https://aka.ms/vs/stable/vs_<Edition>.exe). A numeric
                         major also works, e.g. 17 -> aka.ms/vs/17/release/...
  --vs-bootstrapper P    Path to vs_<Edition>.exe, or an http(s) URL.
                         Default: download from --vs-boot-url.
  --vs-boot-url URL      Override the bootstrapper URL. Default is derived:
                           named channel : https://aka.ms/vs/<channel>/vs_<Edition>.exe
                           numeric major : https://aka.ms/vs/<num>/release/vs_<Edition>.exe
                         (if this redirects to a web page, download the
                         installer manually from visualstudio.microsoft.com
                         and pass --vs-bootstrapper <path>).
  --vs-workload ID       Override the VS workload id. Default is derived from
                         --vs-edition (VCTools for buildtools, NativeDesktop
                         otherwise).
  --no-arm64             EXCLUDE the ARM64 tools. By default ARM64 IS included
                         (VC.Tools.ARM64 + VC.MFC.ARM64 + the arm SDK parts),
                         matching Chromium's own toolchain. Use --no-arm64
                         (alias --noarm) for a smaller x86/x64-only package.
  --with-arm64           Kept for compatibility; ARM64 is already the default.
  --sdk-version VER      Windows SDK version. Default: read from
                         build/vs_toolchain.py (SDK_VERSION), e.g. 10.0.26100.0.
  --install-sdk          Also install the required Windows SDK: adds the VS
                         component Microsoft.VisualStudio.Component.Windows11SDK.
                         <build>; with --sdk-installer it can also install the
                         "Debugging Tools for Windows" (which
                         package_from_installed.py requires).
  --sdk-installer P      winsdksetup.exe path or URL. With --install-sdk it is
                         run as: /quiet /norestart /features
                         OptionId.DesktopCPPx64 OptionId.WindowsDesktopDebuggers.
  --skip-install         Do not download/install; package an existing VS.
  --prefer-installed     If a compatible Visual Studio 2026 instance already
                         exists (ANY edition), use it instead of the requested
                         edition; components are still verified. Without this,
                         ONLY --vs-edition is considered/installed, and other
                         editions on the machine are ignored entirely.
  --dry-run              Only print what would run.
  -h, --help             Show this help.

Windows SDK note:
  Chromium needs ONE specific SDK version (SDK_VERSION in build/vs_toolchain.py),
  not necessarily the newest. Check/install with the official methods above or
  from https://developer.microsoft.com/windows/downloads/windows-sdk/ .

After it finishes:
  * The archive is <out>\<local-hash>.zip
  * <out>\TOOLCHAIN_INFO.txt contains the mapping:
        GYP_MSVS_HASH_<canonical>=<local-hash>
        DEPOT_TOOLS_WIN_TOOLCHAIN_BASE_URL=<out>\
  * Build with:
        chromium_build_win.ps1 --dir <work> --version <rev> --win-toolchain-url "file://<out>/"
    (the main script auto-detects <local-hash>.zip and sets the mapping).
"@
}
if ($Help) { Show-Help; exit 0 }

# ---- normalize the VS edition -----------------------------------------------
$VsEdition = ([string]$VsEdition).ToLowerInvariant()
if (@('buildtools', 'community', 'professional', 'enterprise') -notcontains $VsEdition) {
    throw "Invalid --vs-edition '$VsEdition' (expected buildtools|community|professional|enterprise)."
}
$editionExeName = @{ buildtools = 'BuildTools'; community = 'Community';
                     professional = 'Professional'; enterprise = 'Enterprise' }[$VsEdition]
$vsExeName = "vs_$editionExeName.exe"
if (-not $VsWorkload) {
    # Build Tools uses the VCTools workload; the IDE editions use NativeDesktop.
    $VsWorkload = if ($VsEdition -eq 'buildtools') {
        'Microsoft.VisualStudio.Workload.VCTools'
    } else {
        'Microsoft.VisualStudio.Workload.NativeDesktop'
    }
}
if (-not $BootUrl) {
    # aka.ms layout differs by channel name:
    #   named channel : https://aka.ms/vs/stable/vs_<Edition>.exe
    #   numeric major : https://aka.ms/vs/17/release/vs_<Edition>.exe
    if ($VsChannel -match '^\d+') {
        $BootUrl = "https://aka.ms/vs/$VsChannel/release/vs_$editionExeName.exe"
    } else {
        $BootUrl = "https://aka.ms/vs/$VsChannel/vs_$editionExeName.exe"
    }
}

function Write-Step { param([string]$T) Write-Host "==> $T" -ForegroundColor Cyan }
function Write-Ok   { param([string]$T) Write-Host "    $T" -ForegroundColor Green }
function Write-Warn2{ param([string]$T) Write-Host "    $T" -ForegroundColor Yellow }

function Invoke-Native {
    param([Parameter(Mandatory)][string]$FilePath, [string[]]$ArgumentList = @(), [string]$WorkingDirectory)
    Write-Host "  > $FilePath $($ArgumentList -join ' ')" -ForegroundColor DarkGray
    if ($DryRun) { return }
    if ($WorkingDirectory) { Push-Location -LiteralPath $WorkingDirectory }
    try { & $FilePath @ArgumentList } finally { if ($WorkingDirectory) { Pop-Location } }
    if ($null -ne $LASTEXITCODE -and $LASTEXITCODE -ne 0) {
        throw "Command failed ($LASTEXITCODE): $FilePath $($ArgumentList -join ' ')"
    }
}

# For GUI installers (the VS bootstrapper, winsdksetup): launch, WAIT, and read
# the real exit code. PowerShell's "&" does NOT wait for GUI apps, so
# $LASTEXITCODE can be empty and look like a failure.
function Invoke-Wait {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [string[]]$ArgumentList = @(),
        [string]$WorkingDirectory,
        [int[]]$SuccessCodes = @(0, 3010)   # 3010 = success, reboot required
    )
    # Start-Process joins ArgumentList without quoting, so quote spaces.
    $quoted = $ArgumentList | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } }
    $argStr = ($quoted -join ' ')
    Write-Host "  > $FilePath $argStr" -ForegroundColor DarkGray
    if ($DryRun) { return }
    $sp = @{ FilePath = $FilePath; ArgumentList = $argStr; PassThru = $true; Wait = $true; NoNewWindow = $true }
    if ($WorkingDirectory) { $sp['WorkingDirectory'] = $WorkingDirectory }
    $p = Start-Process @sp
    if ($SuccessCodes -notcontains $p.ExitCode) {
        throw "Command failed ($($p.ExitCode)): $FilePath $argStr"
    }
    Write-Ok "exit code $($p.ExitCode)"
}

# ---------------------------------------------------------------------------
#  Detect an installed Windows SDK (KitsRoot10) and whether the required
#  version and the "Debugging Tools for Windows" (Debuggers) are present.
#  package_from_installed.py REQUIRES both.
# ---------------------------------------------------------------------------
function Get-WindowsSdkInfo {
    param([string]$Version)
    $root = $null
    foreach ($reg in @('HKLM:\SOFTWARE\Microsoft\Windows Kits\Installed Roots',
                       'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows Kits\Installed Roots')) {
        if (Test-Path $reg) {
            $v = (Get-ItemProperty -Path $reg -Name KitsRoot10 -ErrorAction SilentlyContinue).KitsRoot10
            if ($v) { $root = $v.TrimEnd('\'); break }
        }
    }
    $res = [ordered]@{ Root = $root; HasVersion = $false; HasDebuggers = $false; Versions = @() }
    if ($root -and (Test-Path $root)) {
        $inc = Join-Path $root 'Include'
        if (Test-Path $inc) {
            $res.Versions = @(Get-ChildItem -LiteralPath $inc -Directory -ErrorAction SilentlyContinue |
                              ForEach-Object { $_.Name })
        }
        if ($Version -and (Test-Path (Join-Path $inc $Version))) { $res.HasVersion = $true }
        if (Test-Path (Join-Path $root 'Debuggers')) { $res.HasDebuggers = $true }
    }
    return $res
}

# True if the file exists and looks like a Windows PE executable (starts 'MZ',
# at least 1 MB). Used to reject HTML from a redirect / stale bad download.
function Test-PeFile {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    if ((Get-Item -LiteralPath $Path).Length -lt 1MB) { return $false }
    $first = (Get-Content -LiteralPath $Path -Encoding Byte -TotalCount 1)
    return ($first -eq 0x4D)     # 'M'
}

# ---------------------------------------------------------------------------
#  Visual Studio instance / component queries via vswhere.
#  Always scoped to VS 2026 (productLineVersion 18) so VS 2022 etc. never match.
# ---------------------------------------------------------------------------
$script:Vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'

function Get-Vs2026Instances {
    if (-not (Test-Path -LiteralPath $script:Vswhere)) { return @() }
    $json = & $script:Vswhere -prerelease -products '*' -format json 2>$null
    if (-not $json) { return @() }
    try { $all = @($json | ConvertFrom-Json) } catch { return @() }
    return @($all | Where-Object { $_.catalog_productLineVersion -eq '18' })
}

function Test-VsComponent {
    # True if the given PRODUCT (edition) has the COMPONENT installed (VS 2026).
    param([Parameter(Mandatory)][string]$ProductId, [Parameter(Mandatory)][string]$ComponentId)
    if (-not (Test-Path -LiteralPath $script:Vswhere)) { return $false }
    $p = & $script:Vswhere -prerelease -products $ProductId -version '[18.0,19.0)' `
            -requires $ComponentId -property installationPath 2>$null
    return [bool]$p
}

function Test-VsLayout {
    # Fallback: some environments (e.g. Windows Sandbox/WDAG) install the files
    # but never register the instance with vswhere. A real VS layout has
    # <path>\VC\Tools\MSVC\14.* and <path>\Common7.
    param([string]$Path)
    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return $false }
    $msvc = Join-Path $Path 'VC\Tools\MSVC'
    if (-not (Test-Path -LiteralPath $msvc)) { return $false }
    $tools = @(Get-ChildItem -LiteralPath $msvc -Directory -ErrorAction SilentlyContinue |
               Where-Object { $_.Name -like '14.*' })
    return ($tools.Count -gt 0)
}

$WorkDir = $WorkDir.TrimEnd('\','/')
if (-not $OutDir)      { $OutDir = Join-Path $WorkDir 'win_toolchain_archive' }
if (-not $VsInstallDir){ $VsInstallDir = Join-Path $WorkDir $editionExeName }

# ---- chromium/src (OPTIONAL) ------------------------------------------------
# Only used to auto-read TOOLCHAIN_HASH + SDK_VERSION. depot_tools alone is
# enough to package, if you pass --canonical-hash / --sdk-version.
if (-not $ChromiumSrc) {
    $scriptParent = Split-Path $PSScriptRoot -Parent
    $workParent   = Split-Path $WorkDir -Parent
    $srcCands = @()
    foreach ($base in @($WorkDir, $scriptParent, $PSScriptRoot, $workParent)) {
        if ($base) { $srcCands += (Join-Path $base 'chromium\src') }
    }
    $srcCands += (Join-Path $WorkDir 'src')
    foreach ($cand in $srcCands) {
        if ($cand -and (Test-Path (Join-Path $cand 'build\vs_toolchain.py'))) { $ChromiumSrc = $cand; break }
    }
}

# Auto-find depot_tools if not given (so the command line stays short).
if (-not $DepotTools) {
    $scriptParent = Split-Path $PSScriptRoot -Parent
    $workParent   = Split-Path $WorkDir -Parent
    $dtCands = @()
    foreach ($base in @($WorkDir, $scriptParent, $PSScriptRoot, $workParent)) {
        if ($base) { $dtCands += (Join-Path $base 'depot_tools') }
    }
    foreach ($dt in $dtCands) {
        if ($dt -and (Test-Path (Join-Path $dt 'win_toolchain\package_from_installed.py'))) { $DepotTools = $dt; break }
    }
}
if ($ChromiumSrc) { $ChromiumSrc = $ChromiumSrc.TrimEnd('\','/') }
$hasChromium = [bool]($ChromiumSrc -and (Test-Path (Join-Path $ChromiumSrc 'build\vs_toolchain.py')))
if ($ChromiumSrc -and -not $hasChromium) {
    Write-Warn2 "Ignoring --chromium-src '$ChromiumSrc' (no build\vs_toolchain.py found)."
    $ChromiumSrc = ''
}

# ---- depot_tools + the packager ---------------------------------------------
# package_from_installed.py ships inside depot_tools itself
# (<depot_tools>\win_toolchain\), so Chromium source is NOT required.
$dtRoot = ''                                      # <root> that contains depot_tools\ and chromium\
if ($ChromiumSrc) { $dtRoot = Split-Path (Split-Path $ChromiumSrc -Parent) -Parent }
$packagerCands = @()
if ($DepotTools)  { $packagerCands += (Join-Path $DepotTools 'win_toolchain\package_from_installed.py') }
if ($dtRoot)      { $packagerCands += (Join-Path $dtRoot 'depot_tools\win_toolchain\package_from_installed.py') }
if ($ChromiumSrc) { $packagerCands += (Join-Path $ChromiumSrc 'third_party\depot_tools\win_toolchain\package_from_installed.py') }
$Packager = $null
foreach ($c in $packagerCands) { if ($c -and (Test-Path -LiteralPath $c)) { $Packager = $c; break } }
if (-not $Packager) {
    throw @"
Could not find win_toolchain\package_from_installed.py.
Pass --depot-tools <a depot_tools clone> (it contains win_toolchain\),
or --chromium-src <chromium/src>.
"@
}

# Resolve a Python launcher. package_from_installed.py + its import are
# stdlib-only, so any python3 works; python3.bat (CIPD python) is preferred
# over vpython3.bat (which builds a venv and can be blocked by antivirus).
function Resolve-Python {
    param([string]$DepotToolsDir, [string]$ChromiumSrcDir, [string]$RootDir)
    $cands = @()
    if ($DepotToolsDir)  { $cands += (Join-Path $DepotToolsDir 'python3.bat') }
    if ($RootDir)        { $cands += (Join-Path $RootDir 'depot_tools\python3.bat') }
    if ($ChromiumSrcDir) { $cands += (Join-Path $ChromiumSrcDir 'third_party\depot_tools\vpython3.bat') }
    foreach ($c in $cands) { if ($c -and (Test-Path -LiteralPath $c)) { return $c } }
    foreach ($n in @('python3', 'python')) {
        $g = Get-Command $n -ErrorAction SilentlyContinue
        if ($g) { return $g.Source }
    }
    return $null
}
$Python3 = Resolve-Python -DepotToolsDir $DepotTools -ChromiumSrcDir $ChromiumSrc -RootDir $dtRoot
if (-not $Python3) {
    throw 'No Python 3 found. Install Python 3, or pass --depot-tools <path with python3.bat>.'
}

# ---- canonical hash + SDK version -------------------------------------------
# Explicit options win; otherwise read them from the Chromium checkout.
$canonicalHash = $CanonicalHash
if ($hasChromium) {
    $vsToolchainSrc = Get-Content -LiteralPath (Join-Path $ChromiumSrc 'build\vs_toolchain.py') -Raw
    if (-not $canonicalHash -and $vsToolchainSrc -match "TOOLCHAIN_HASH\s*=\s*'([0-9a-fA-F]+)'") { $canonicalHash = $matches[1] }
    if (-not $SdkVersion -and $vsToolchainSrc -match "SDK_VERSION\s*=\s*'([0-9.]+)'") { $SdkVersion = $matches[1] }
}
if (-not $SdkVersion) {
    # No Chromium: fall back to the only installed SDK, if unambiguous.
    $info = Get-WindowsSdkInfo -Version ''
    if ($info.Versions.Count -eq 1) {
        $SdkVersion = $info.Versions[0]
        Write-Warn2 "No --sdk-version given; using the only installed SDK: $SdkVersion"
    }
}
if (-not $SdkVersion) {
    throw 'SDK version is required. Pass --sdk-version <ver>, or --chromium-src to read it.'
}
if (-not $canonicalHash) {
    Write-Warn2 'No canonical hash; TOOLCHAIN_INFO.txt will omit GYP_MSVS_HASH_*.'
    Write-Warn2 'Set it later for the build via: --win-toolchain-hash <local-hash>.'
}

$sdkBuild = ''
if ($SdkVersion -match '^10\.0\.(\d+)\.') { $sdkBuild = $matches[1] }   # 10.0.26100.0 -> 26100
$sdkComponent = if ($sdkBuild) { "Microsoft.VisualStudio.Component.Windows11SDK.$sdkBuild" } else { '' }

# ---- VS product id + the exact components the packager needs ----------------
# Edition-scoped: we only ever touch the product id below (unless
# --prefer-installed). Other editions installed on the machine are ignored.
$editionProduct = @{
    buildtools   = 'Microsoft.VisualStudio.Product.BuildTools'
    community    = 'Microsoft.VisualStudio.Product.Community'
    professional = 'Microsoft.VisualStudio.Product.Professional'
    enterprise   = 'Microsoft.VisualStudio.Product.Enterprise'
}[$VsEdition]

$requiredComponents = @(
    'Microsoft.VisualStudio.Component.VC.Tools.x86.x64',   # MSVC toolset
    'Microsoft.VisualStudio.Component.VC.ATLMFC'           # ATL/MFC
)
if ($InstallSdk -and $sdkComponent) { $requiredComponents += $sdkComponent }
if ($Arm64) {
    $requiredComponents += 'Microsoft.VisualStudio.Component.VC.Tools.ARM64'
    $requiredComponents += 'Microsoft.VisualStudio.Component.VC.MFC.ARM64'
}

Write-Host '============================================================================'
Write-Host ' Prepare a Chromium Windows toolchain archive'
Write-Host '============================================================================'
Write-Host " Work dir        : $WorkDir"
Write-Host " depot_tools     : $DepotTools"
Write-Host " packager        : $Packager"
Write-Host " chromium/src    : $(if ($ChromiumSrc) { $ChromiumSrc } else { '(none - depot_tools only)' })"
Write-Host " Output dir      : $OutDir"
Write-Host " VS edition      : $VsEdition (workload $VsWorkload)"
Write-Host " VS install dir  : $VsInstallDir"
Write-Host " Canonical hash  : $(if ($canonicalHash) { $canonicalHash } else { '(not set)' })"
Write-Host " SDK version     : $SdkVersion (component Windows11SDK.$sdkBuild)"
Write-Host " Include ARM64   : $Arm64"
Write-Host " Install SDK     : $InstallSdk"
Write-Host " Prefer existing : $PreferInstalled"
Write-Host " Edition product : $editionProduct"
Write-Host " Required comps  : $($requiredComponents -join ', ')"
Write-Host '============================================================================'

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

# ---- 1. Windows SDK check ---------------------------------------------------
# package_from_installed.py needs the SDK version Chromium wants AND its
# "Debugging Tools for Windows" (Windows Kits\10\Debuggers).
$sdkInfo = Get-WindowsSdkInfo -Version $SdkVersion
if (-not $DryRun) {
    Write-Step "Checking Windows SDK $SdkVersion"
    $rootTxt = if ($sdkInfo.Root) { $sdkInfo.Root } else { '(not found)' }
    Write-Ok "KitsRoot10 : $rootTxt"
    Write-Ok "Version    : $(if ($sdkInfo.HasVersion) { 'installed' } else { 'MISSING' })"
    Write-Ok "Debuggers  : $(if ($sdkInfo.HasDebuggers) { 'installed' } else { 'MISSING' })"
    if ($sdkInfo.Versions.Count -gt 0) { Write-Ok ("Installed SDKs: " + ($sdkInfo.Versions -join ', ')) }
}
if (-not $sdkInfo.HasVersion -or -not $sdkInfo.HasDebuggers) {
    Write-Warn2 "Windows SDK $SdkVersion with 'Debugging Tools for Windows' is REQUIRED."
    Write-Warn2 'Official ways to install it:'
    if ($sdkComponent) {
        Write-Warn2 "  * VS installer: re-run the bootstrapper with --add $sdkComponent"
    } else {
        Write-Warn2 '  * VS installer: add Microsoft.VisualStudio.Component.Windows11SDK.<build>'
    }
    Write-Warn2 '  * Standalone SDK: https://developer.microsoft.com/windows/downloads/windows-sdk/'
    Write-Warn2 '    Download winsdksetup.exe, enable "Debugging Tools for Windows", or pass'
    Write-Warn2 '    --sdk-installer <path-or-url> together with --install-sdk to automate it.'
}

# ---- 2. decide the target VS instance (EDITION-SCOPED) ----------------------
# Only the requested edition's product id is ever considered/installed, unless
# --prefer-installed asks to reuse any existing compatible instance. Other
# editions on the machine are ignored.
$vsInstance       = $null      # @{ productId; installationPath; ... }
$missingComps     = @()
$needFreshInstall = $false

$instances = Get-Vs2026Instances
if ($instances.Count -gt 0) {
    Write-Step 'Installed Visual Studio 2026 instance(s):'
    foreach ($inst in $instances) {
        Write-Ok ("  {0}  {1}" -f $inst.productId, $inst.installationPath)
    }
}

if ($PreferInstalled) {
    foreach ($inst in $instances) {
        $miss = @()
        foreach ($c in $requiredComponents) {
            if (-not (Test-VsComponent -ProductId $inst.productId -ComponentId $c)) { $miss += $c }
        }
        if ($miss.Count -eq 0) { $vsInstance = $inst; break }
    }
    if ($vsInstance) {
        Write-Ok "Using existing instance (--prefer-installed): $($vsInstance.installationPath)"
    } else {
        Write-Warn2 'No existing VS 2026 instance has ALL required components.'
    }
}

if (-not $vsInstance) {
    $editionInst = @($instances | Where-Object { $_.productId -eq $editionProduct }) | Select-Object -First 1
    if ($editionInst) {
        $vsInstance = $editionInst
        foreach ($c in $requiredComponents) {
            if (-not (Test-VsComponent -ProductId $editionProduct -ComponentId $c)) { $missingComps += $c }
        }
        Write-Step "Using $VsEdition instance: $($vsInstance.installationPath)"
        if ($missingComps.Count -gt 0) {
            Write-Warn2 ('Missing component(s): ' + ($missingComps -join ', '))
        } else {
            Write-Ok 'All required components are already installed.'
        }
    } else {
        $needFreshInstall = $true
        Write-Step "$VsEdition is not installed -> will install it with all required components."
    }
}

$doInstall = $false
if ($needFreshInstall -or $missingComps.Count -gt 0) {
    if ($SkipInstall) {
        Write-Warn2 'Missing VS/components but --skip-install was given; packaging may fail.'
    } else {
        $doInstall = $true
    }
}

# ---- 3. install / update VS (only when something is missing) ----------------
if ($doInstall) {
    Write-Step "Obtaining the $VsEdition bootstrapper"
    $vsExe = $null
    if ($Bootstrapper -and (Test-Path -LiteralPath $Bootstrapper)) {
        $vsExe = (Resolve-Path -LiteralPath $Bootstrapper).Path
        Write-Ok "Using local bootstrapper: $vsExe"
    } else {
        $url = if ($Bootstrapper -match '^https?://') { $Bootstrapper } else { $BootUrl }
        $vsExe = Join-Path $WorkDir $vsExeName
        if ($DryRun) {
            Write-Step "Downloading $url"
        } else {
            # Download, validating it is a real PE. If a previous attempt left a
            # bad/HTML file (e.g. an aka.ms redirect), delete and retry once.
            $ok = $false
            for ($attempt = 1; $attempt -le 2 -and -not $ok; $attempt++) {
                if (-not (Test-PeFile -Path $vsExe)) {
                    if (Test-Path -LiteralPath $vsExe) {
                        Remove-Item -LiteralPath $vsExe -Force -ErrorAction SilentlyContinue
                    }
                    Write-Step "Downloading $url"
                    $old = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
                    try { Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $vsExe -MaximumRedirection 8 -TimeoutSec 1800 }
                    finally { $ProgressPreference = $old }
                }
                $ok = Test-PeFile -Path $vsExe
            }
            if (-not $ok) {
                $len = if (Test-Path -LiteralPath $vsExe) { (Get-Item -LiteralPath $vsExe).Length } else { 0 }
                throw @"
Downloaded file is not a real bootstrapper (size=$len). The URL probably
redirected to a web page:
    $url
Download the Visual Studio installer from
https://visualstudio.microsoft.com/downloads/ and re-run with:
    --vs-bootstrapper <path-to-$vsExeName>
"@
            }
            Write-Ok "Bootstrapper ready: $vsExe"
        }
    }

    $installArgs = @('--quiet', '--wait', '--norestart', '--nocache')
    if ($needFreshInstall) {
        $installArgs += @('--installPath', $VsInstallDir,
                          '--add', $VsWorkload,
                          '--add', 'Microsoft.VisualStudio.Component.VC.ATLMFC',
                          '--includeRecommended')
        if ($InstallSdk -and $sdkComponent) { $installArgs += @('--add', $sdkComponent) }
        if ($Arm64) {
            $installArgs += @('--add', 'Microsoft.VisualStudio.Component.VC.Tools.ARM64')
            $installArgs += @('--add', 'Microsoft.VisualStudio.Component.VC.MFC.ARM64')
        }
        Write-Step "Installing $VsEdition into $VsInstallDir (needs admin; several GB)"
    } else {
        # Update the existing instance, adding ONLY the missing components.
        $installArgs += @('--installPath', $vsInstance.installationPath)
        foreach ($c in $missingComps) { $installArgs += @('--add', $c) }
        Write-Step "Adding missing component(s) to $($vsInstance.installationPath) (needs admin)"
    }
    Invoke-Wait -FilePath $vsExe -ArgumentList $installArgs
    Write-Ok 'VS install/update step finished.'
} else {
    Write-Ok 'No VS install needed.'
}

# ---- 4. optional standalone Windows SDK / debuggers install -----------------
if ($InstallSdk -and $SdkInstaller) {
    $needDbg = -not (Get-WindowsSdkInfo -Version $SdkVersion).HasDebuggers
    if ($needDbg) {
        $sdkExe = $SdkInstaller
        if ($sdkExe -match '^https?://') {
            $out = Join-Path $WorkDir 'winsdksetup.exe'
            Write-Step "Downloading Windows SDK installer: $sdkExe"
            if (-not $DryRun) {
                $old = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
                try { Invoke-WebRequest -UseBasicParsing -Uri $sdkExe -OutFile $out -MaximumRedirection 8 -TimeoutSec 1800 }
                finally { $ProgressPreference = $old }
            }
            $sdkExe = $out
        }
        Write-Step 'Installing Windows SDK Debugging Tools (winsdksetup)'
        Invoke-Wait -FilePath $sdkExe -ArgumentList @('/quiet', '/norestart', '/features',
            'OptionId.DesktopCPPx64', 'OptionId.WindowsDesktopDebuggers')
    }
}

# ---- 5. resolve the target instance + final checks --------------------------
if (-not $DryRun) {
    # The VS installer can return 0 yet keep working asynchronously, so poll for
    # the instance we want (edition-scoped unless --prefer-installed).
    if (-not $vsInstance) {
        for ($w = 0; $w -lt 30 -and -not $vsInstance; $w++) {
            $cand = @((Get-Vs2026Instances) | Where-Object {
                if ($PreferInstalled) { $true } else { $_.productId -eq $editionProduct }
            }) | Select-Object -First 1
            if ($cand) { $vsInstance = $cand; break }
            Start-Sleep -Seconds 10
        }
    }

    # Fallback: some environments (Windows Sandbox/WDAG) install the files but
    # never register the instance with vswhere. If a real VS layout exists on
    # disk, use it directly for packaging.
    if (-not $vsInstance) {
        $layoutCands = @(
            $VsInstallDir,
            'C:\Program Files\Microsoft Visual Studio\2026\BuildTools',
            'C:\Program Files\Microsoft Visual Studio\2026\Community',
            'C:\Program Files (x86)\Microsoft Visual Studio\2026\BuildTools',
            'C:\Program Files (x86)\Microsoft Visual Studio\2026\Community'
        )
        foreach ($lp in $layoutCands) {
            if (Test-VsLayout -Path $lp) {
                Write-Warn2 "vswhere did not register an instance, but a VS layout exists at:"
                Write-Warn2 "  $lp"
                Write-Warn2 'Using it for packaging (fallback).'
                $vsInstance = [ordered]@{ productId = $editionProduct; installationPath = $lp }
                break
            }
        }
    }

    if ($vsInstance) {
        Write-Ok "Target VS instance: $($vsInstance.installationPath) [$($vsInstance.productId)]"
        $still = @()
        foreach ($c in $requiredComponents) {
            if (-not (Test-VsComponent -ProductId $vsInstance.productId -ComponentId $c)) { $still += $c }
        }
        if ($still.Count -gt 0) { Write-Warn2 ('Still missing: ' + ($still -join ', ')) }
        else { Write-Ok 'All required components present.' }
    } else {
        Write-Warn2 'No matching Visual Studio 2026 instance found.'
        Write-Warn2 'Common causes: cmd not elevated, not enough disk, package CDN blocked,'
        Write-Warn2 'a pending reboot, or an invalid component id.'
        # Dump the tail of the VS installer logs so the real cause is visible.
        $logs = @()
        foreach ($pat in @('dd_setup_*.log', 'dd_*.log')) {
            $logs += @(Get-ChildItem -LiteralPath $env:TEMP -Filter $pat -File -ErrorAction SilentlyContinue)
        }
        $logs = @($logs | Sort-Object LastWriteTime -Descending | Select-Object -First 2)
        foreach ($l in $logs) {
            Write-Warn2 "--- $($l.FullName) (last 25 lines) ---"
            Get-Content -LiteralPath $l.FullName -Tail 25 -ErrorAction SilentlyContinue |
                ForEach-Object { Write-Host ("    " + $_) -ForegroundColor DarkYellow }
        }
    }

    $sdkInfo = Get-WindowsSdkInfo -Version $SdkVersion
    $dbgRoot = if ($sdkInfo.Root) { $sdkInfo.Root } else { 'C:\Program Files (x86)\Windows Kits\10' }
    if (-not $sdkInfo.HasVersion) {
        Write-Warn2 "Windows SDK $SdkVersion not found; package_from_installed.py will fail."
        Write-Warn2 'Install it (see above) and re-run.'
    }
    if (-not $sdkInfo.HasDebuggers) {
        Write-Warn2 'Windows SDK Debuggers missing; required path:'
        Write-Warn2 ('  ' + (Join-Path $dbgRoot 'Debuggers'))
        Write-Warn2 'Install "Debugging Tools for Windows", or --install-sdk --sdk-installer <exe>.'
    }
}

# ---- 6. package FROM THE CHOSEN INSTANCE (edition-locked) --------------------
$packagePath = if ($vsInstance) { $vsInstance.installationPath } else { $VsInstallDir }
if ($DryRun) {
    Write-Step "Would package from: $packagePath"
} else {
    if (-not $vsInstance) {
        throw 'No matching Visual Studio instance to package from.'
    }
    Write-Step "Packaging from $($vsInstance.productId): $packagePath"
    # depot_tools' own GetVSPath() would pick ANY VS 2026 (possibly another
    # edition). Generate a tiny wrapper that forces THIS instance's path.
    $pkgDir  = Split-Path -Parent $Packager
    $wrapper = Join-Path $OutDir '_package_wrapper.py'
    # package_from_installed.py includes arm by default; pass --noarm when the
    # user asked for an x86/x64-only package.
    $armArg = if ($Arm64) { '' } else { ", '--noarm'" }
    $wrapperLines = @(
        'import sys'
        "sys.path.insert(0, r'$pkgDir')"
        'import package_from_installed as p'
        "p.GetVSPath = lambda: r'$packagePath'"
        "sys.argv = ['package_from_installed.py', '2026', '-w', '$SdkVersion'$armArg]"
        'sys.exit(p.main())'
    )
    Set-Content -LiteralPath $wrapper -Value $wrapperLines -Encoding ASCII
    Invoke-Native -FilePath $Python3 -ArgumentList @($wrapper) -WorkingDirectory $OutDir
}

# ---- 7. find the produced archive + write the mapping -----------------------
if ($DryRun) { Write-Ok 'Dry run complete.'; exit 0 }

$zip = Get-ChildItem -LiteralPath $OutDir -Filter '*.zip' -File -ErrorAction SilentlyContinue |
       Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $zip) { throw "package_from_installed.py did not produce a .zip in $OutDir" }

$localHash = $zip.BaseName
$infoPath  = Join-Path $OutDir 'TOOLCHAIN_INFO.txt'
$infoLines = @(
    '# Generated by prepare_win_toolchain.ps1'
    "canonical_hash=$canonicalHash"
    "local_hash=$localHash"
    "archive=$($zip.FullName)"
    "sdk_version=$SdkVersion"
    "DEPOT_TOOLS_WIN_TOOLCHAIN_BASE_URL=$OutDir\"
)
if ($canonicalHash) {
    $infoLines += "GYP_MSVS_HASH_$canonicalHash=$localHash"
} else {
    $infoLines += '# canonical hash unknown: set GYP_MSVS_HASH_<canonical>=' + $localHash + ' for your revision'
}
Set-Content -LiteralPath $infoPath -Value $infoLines -Encoding ASCII

Write-Host ''
Write-Host '============================================================================'
Write-Host ' Done'
Write-Host '============================================================================'
Write-Host " Archive : $($zip.FullName)"
Write-Host " SDK     : $SdkVersion"
if ($canonicalHash) {
    Write-Host " Mapping : GYP_MSVS_HASH_$canonicalHash=$localHash"
} else {
    Write-Host " Mapping : (unknown canonical) GYP_MSVS_HASH_<canonical>=$localHash"
}
Write-Host " Info    : $infoPath"
Write-Host ''
Write-Host ' Use it for a build (the main script auto-detects the local .zip):'
Write-Host "   .\chromium_build_win.bat --dir <work> --version <rev> --win-toolchain-url ""file://$OutDir/"""
if (-not $canonicalHash) {
    Write-Host "   (add --win-toolchain-hash $localHash when the canonical hash is known)"
}
Write-Host '============================================================================'
exit 0
