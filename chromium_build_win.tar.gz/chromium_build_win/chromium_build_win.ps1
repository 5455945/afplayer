# ============================================================================
#  chromium_build_win.ps1
#  ---------------------------------------------------------------------------
#  Download and build Chromium on Windows 10/11 (x64).
#
#  What it does
#    1. Bootstraps git (portable Git, if git is not installed) and depot_tools.
#    2. Shallow-fetches the Chromium source tree and its dependencies.
#    3. Optionally checks out a requested version / milestone / branch
#       (falls back to the latest stable release when the request does not
#       exist).
#    4. Runs gclient hooks. Chromium's clang is downloaded by the sync; the
#       Windows SDK/MSVC headers+libs come from either a locally installed
#       Visual Studio (DEPOT_TOOLS_WIN_TOOLCHAIN=0) or the prebuilt toolchain
#       (DEPOT_TOOLS_WIN_TOOLCHAIN=1). NOTE: the prebuilt toolchain is
#       Google-internal, so EXTERNAL users must have Visual Studio installed.
#    5. Builds chrome, content_shell, headless_shell and mini_installer.
#
#  Requirements
#    - Windows 10/11 x64, 8+ GB RAM (16+ recommended)
#    - 100+ GB free NTFS disk space (FAT32 will not work)
#    - Internet access
#    - Git for Windows is used when present; if it is missing, a portable
#      copy is downloaded automatically (disable with --no-bootstrap-git).
#    - Visual Studio 2026 (or Build Tools) with "Desktop development with C++"
#      and the "MFC/ATL" component. This is REQUIRED for external users: the
#      prebuilt win_toolchain is Google-internal. The script auto-detects VS
#      (--win-toolchain auto) and sets DEPOT_TOOLS_WIN_TOOLCHAIN accordingly.
#      ALTERNATIVE without installing VS: --win-toolchain-url <dir URL> pointing
#      at a folder containing "<toolchain-hash>.zip" (file:// or http/https).
#
#  Notes
#    - The download root defaults to THIS SCRIPT'S directory. Use --dir PATH
#      to put everything somewhere else.
#    - The full path must NOT contain spaces (Chromium requirement).
#    - The source is ALWAYS fetched with --no-history (shallow, depth 1) to
#      keep every .git directory as small as possible.
#
#  Examples
#    .\chromium_build_win.ps1
#    .\chromium_build_win.ps1 --dir D:\chromium
#    .\chromium_build_win.ps1 --version 131
#    .\chromium_build_win.ps1 --version 131.0.6778.85 --release
#    .\chromium_build_win.ps1 --version main
#    .\chromium_build_win.ps1 --targets chrome,content_shell
# ============================================================================

$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
#  Environment sanity checks (helpful hints when PowerShell is locked down)
# ---------------------------------------------------------------------------
function Test-PowerShellEnvironment {
    if ($PSVersionTable.PSVersion.Major -lt 5) {
        Write-Host "ERROR: Windows PowerShell 5.1 or newer is required (found $($PSVersionTable.PSVersion))." -ForegroundColor Red
        Write-Host 'It ships with Windows 10/11; no separate install should be needed.'
        exit 3
    }

    $mode = $ExecutionContext.SessionState.LanguageMode
    if ($mode -ne 'FullLanguage') {
        Write-Host ''
        Write-Host "NOTE: PowerShell language mode is '$mode'." -ForegroundColor Yellow
        Write-Host '  ConstrainedLanguage is normally enforced by WDAC / AppLocker / Device Guard'
        Write-Host '  (typical on managed corporate machines). Some operations may be blocked.'
        Write-Host '  There is no single command to turn it off; the policy must be relaxed:'
        Write-Host '    Get-AppLockerPolicy -Effective -Xml'
        Write-Host '    Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard'
        Write-Host '  If you own the machine, remove the WDAC/AppLocker policy, or build on an'
        Write-Host '  unmanaged PC. Ask your administrator otherwise.'
        Write-Host ''
    }

    $ep = Get-ExecutionPolicy
    if ($ep -eq 'Restricted' -or $ep -eq 'AllSigned') {
        Write-Host ''
        Write-Host "NOTE: PowerShell execution policy is '$ep'." -ForegroundColor Yellow
        Write-Host '  This run is fine (it was launched with -ExecutionPolicy Bypass), but to run'
        Write-Host '  .ps1 files normally, either:'
        Write-Host '    Set-ExecutionPolicy -Scope CurrentUser RemoteSigned'
        Write-Host '  or always start through chromium_build_win.bat (it passes Bypass for you).'
        Write-Host ''
    }
}

Test-PowerShellEnvironment

# ---------------------------------------------------------------------------
#  Defaults
# ---------------------------------------------------------------------------
$ScriptDir = $PSScriptRoot
if (-not $ScriptDir) { $ScriptDir = (Get-Location).Path }

$Root          = $ScriptDir                       # download root
$VersionReq    = 'stable'                         # stable | <tag> | <branch>
$MilestoneReq  = ''                               # optional: --milestone N
$ExplicitTargets = @()                            # empty -> use default targets
$DefaultTargets  = @('chrome', 'content_shell', 'headless_shell', 'mini_installer')
$BuildDir      = 'out\Default'
$Jobs          = 0                                # 0 -> let autoninja decide
$SkipFetch     = $false
$SkipHooks     = $false
$SkipBuild     = $false
$DepotToolsOnly = $false                          # only set up depot_tools, then stop
$Release       = $false                           # is_debug=false
$BootstrapGit  = $true
$Retries       = 2                                # fetch retries on transient failures
$WithBranchHeads = $false                         # gclient --with_branch_heads (heavy!)
$WithTags        = $false                         # gclient --with_tags (heavy!)
$Pinned        = $false                           # fetch ONLY the requested revision
$RunGc         = $false                           # git gc --prune=now after checkout
$Pgo           = $false                           # download + use Windows PGO profiles
$Arch          = ''                               # target_cpu: '' (host) | x64 | x86 | arm64
$FullDeps      = $false                           # preset: download extra optional deps
$DepsRaw       = ''                               # raw custom_vars: "key=value,key=value"
$WinToolchain  = 'auto'                           # auto | 0 (local VS) | 1 (internal prebuilt)
$WinToolchainUrl = ''                             # DEPOT_TOOLS_WIN_TOOLCHAIN_BASE_URL (file|http)
$WinToolchainHash = ''                            # local <hash>.zip is mapped via GYP_MSVS_HASH_*
$AddDefenderExclusions = $false
$ExtraGnArgs   = ''
$ShowHelp      = $false

# ---------------------------------------------------------------------------
#  Argument parsing (accepts both --name value and --name=value)
# ---------------------------------------------------------------------------
$argv = @($args)
$i = 0
while ($i -lt $argv.Count) {
    $raw = [string]$argv[$i]
    $opt = $raw
    $inline = $null
    if ($raw -match '^(--?[^=]+)=(.*)$') {
        $opt = $matches[1]
        $inline = $matches[2]
    }

    switch ($opt) {
        '--help'             { $ShowHelp = $true }
        '-h'                 { $ShowHelp = $true }
        '/?'                 { $ShowHelp = $true }
        '--release'          { $Release = $true }
        '--debug'            { $Release = $false }
        '--skip-fetch'       { $SkipFetch = $true }
        '--skip-hooks'       { $SkipHooks = $true }
        '--skip-build'       { $SkipBuild = $true }
        '--depot-tools-only' { $DepotToolsOnly = $true }
        '--only-depot-tools' { $DepotToolsOnly = $true }
        '--no-bootstrap-git' { $BootstrapGit = $false }
        '--no-win-toolchain' { $WinToolchain = '0' }
        '--with-branch-heads' { $WithBranchHeads = $true }
        '--with-tags'         { $WithTags = $true }
        '--pinned'            { $Pinned = $true }
        '--gc'                { $RunGc = $true }
        '--pgo'               { $Pgo = $true }
        '--full-deps'         { $FullDeps = $true }
        '--add-defender-exclusions' { $AddDefenderExclusions = $true }
        default {
            $valueOptions = @('--dir', '--version', '--milestone', '--target', '--targets', '--build-dir', '--jobs', '--gn-args', '--win-toolchain', '--win-toolchain-url', '--win-toolchain-hash', '--retries', '--arch', '--deps')
            if ($valueOptions -contains $opt) {
                $value = $inline
                if ($null -eq $value) {
                    $i++
                    if ($i -ge $argv.Count) { throw "Option $opt requires a value." }
                    $value = [string]$argv[$i]
                }
                switch ($opt) {
                    '--dir'       { $Root = $value }
                    '--version'   { $VersionReq = $value }
                    '--milestone' { $MilestoneReq = $value }
                    '--target'    { $ExplicitTargets += $value }
                    '--targets'   { $ExplicitTargets += ($value -split ',' | Where-Object { $_ -ne '' }) }
                    '--build-dir' { $BuildDir = $value }
                    '--jobs'      { $Jobs = [int]$value }
                    '--gn-args'   { $ExtraGnArgs = $value }
                    '--win-toolchain' { $WinToolchain = $value }
                    '--win-toolchain-url' { $WinToolchainUrl = $value }
                    '--win-toolchain-hash' { $WinToolchainHash = $value }
                    '--retries'   { $Retries = [int]$value }
                    '--arch'      { $Arch = $value }
                    '--deps'      { $DepsRaw = $value }
                }
            } else {
                Write-Warning "Unknown option: $raw"
            }
        }
    }
    $i++
}

if ($ExplicitTargets.Count -gt 0) { $Targets = $ExplicitTargets } else { $Targets = $DefaultTargets }

$WinToolchain = ([string]$WinToolchain).ToLowerInvariant()
if (@('auto', '0', '1') -notcontains $WinToolchain) {
    Write-Warning "Invalid --win-toolchain value '$WinToolchain' (expected auto, 0 or 1); using auto."
    $WinToolchain = 'auto'
}
if ($WinToolchainUrl) {
    # A toolchain archive URL is only honored by the prebuilt-toolchain code
    # path (DEPOT_TOOLS_WIN_TOOLCHAIN=1), so imply it.
    $WinToolchain = '1'
}

# Normalize/validate --arch. Empty means "let GN pick the host default" (x64 on
# an x64 host). Setting target_cpu lets an x64 host cross-compile for x86/arm64.
if ($Arch) {
    $Arch = $Arch.ToLowerInvariant()
    if (@('x64', 'x86', 'arm64') -notcontains $Arch) {
        Write-Warning "Invalid --arch value '$Arch' (expected x64, x86 or arm64); using the host default."
        $Arch = ''
    }
}

if ($Pgo) {
    # PGO profile data only applies to optimized builds. build/config/compiler/
    # pgo/pgo.gni asserts "!is_debug || chrome_pgo_phase == 0", so force release
    # (is_debug=false) whenever PGO is requested.
    $Release = $true
    if ($SkipHooks) {
        Write-Warning '--pgo needs "gclient runhooks" to download the profiles; --skip-hooks prevents that.'
    }
}

function Show-Help {
    Write-Host @"
Usage: chromium_build_win.ps1 [options]

Downloads Chromium, its dependencies and the complete Windows toolchain
(no Visual Studio required) and builds the selected targets.

Options:
  --dir PATH            Download/build under PATH.
                        Default: this script's directory.
  --version VER         Chromium revision (branch or tag) to build:
                          stable / latest      latest stable release (default)
                          131.0.6778.85        an exact release tag
                          7871                 a branch (refs/branch-heads/7871)
                          main / refs/heads/...  a branch/ref
                        If the requested revision cannot be found, the latest
                        stable release is used instead.
  --milestone N         Instead of --version, pick the latest stable release of
                        milestone N (e.g. --milestone 131).
  --target NAME         Add one build target (may be repeated).
  --targets A,B,C       Comma separated list of build targets.
                        Default: chrome,content_shell,headless_shell,mini_installer
  --build-dir DIR       GN output dir inside src. Default: out\Default
  --release             Configure a release build (is_debug=false).
  --debug               Configure a debug build (default).
  --jobs N              Override the number of parallel build jobs.
  --gn-args "ARGS"      Extra GN arguments, e.g. --gn-args "is_component_build=true".
  --retries N           Retry the initial fetch N times on transient failures
                        such as HTTP 429 rate limiting (default: 2).
  --win-toolchain V     DEPOT_TOOLS_WIN_TOOLCHAIN: auto (default), 0 or 1.
                        auto -> 0 if a local Visual Studio is present, else 1.
                        0 = use a locally installed Visual Studio. REQUIRED for
                            external users, because the prebuilt toolchain is
                            Google-internal.
                        1 = Google-internal prebuilt toolchain (internal network
                            or authenticated gsutil only).
  --no-win-toolchain    Shortcut for --win-toolchain 0.
  --win-toolchain-url URL
                        Use a prebuilt toolchain archive instead of a local
                        Visual Studio or the Google-internal bucket. This sets
                        DEPOT_TOOLS_WIN_TOOLCHAIN_BASE_URL and implies
                        --win-toolchain 1, so NO Visual Studio is needed.
                        URL is a DIRECTORY that contains "<toolchain-hash>.zip":
                          file://D:/win_toolchain/       (local folder)
                          https://host/win_toolchain/    (http/https mirror)
                        The required <toolchain-hash> is printed by a failing
                        run as "desired_hash: <hash>"; place <hash>.zip in that
                        folder. Obtain the .zip once from a machine that already
                        has the toolchain (copy
                        src\third_party\depot_tools\win_toolchain\vs_files) or
                        from your internal mirror. Example:
                          --win-toolchain-url "file://D:/win_toolchain/"
                        Note: get_toolchain_if_necessary.py also strips a
                        leading "file://", so "file:///D:/win_toolchain/" works.
                        If the archive was built locally with
                        prepare_win_toolchain.ps1 (its name is not the canonical
                        hash), the script maps it automatically for local dirs,
                        or pass --win-toolchain-hash <local-hash> (e.g. for
                        http). Build such an archive with:
                          prepare_win_toolchain.bat --dir D:\wt --chromium-src <src>
  --with-branch-heads   Pass --with_branch_heads to gclient when switching to a
                        branch. This fetches EVERY release branch and can add
                        many GB to src\.git - leave it off unless gclient fails.
  --with-tags           Pass --with_tags to gclient when switching to a tag
                        (fetches every tag; also potentially very large).
  --pinned              Fetch ONLY the requested revision (skip the intermediate
                        shallow sync of main). Smallest possible .git when you
                        know the version up front.
  --gc                  Run "git gc --prune=now" in src after checkout to
                        reclaim unreachable objects.
  --pgo                 Download and use the Windows PGO profiles:
                          * sets checkout_pgo_profiles=True in .gclient so the
                            gclient runhooks hook downloads src/chrome/build/
                            pgo_profiles/*.profdata (several hundred MB);
                          * adds chrome_pgo_phase=2 and forces a release build
                            (is_debug=false, required by PGO).
                        Profiles are NOT downloaded without this flag.
  --arch ARCH           Output CPU architecture: x64 (host default), x86 or
                        arm64. Sets GN target_cpu; x86/arm64 are cross-compiled
                        on an x64 host. arm64 output runs only on Windows on Arm.
  --full-deps           Enable a curated set of extra optional downloads so the
                        checkout works offline later: clang-tidy, clangd, clang
                        coverage tools, PGO profiles, bazelisk, libaom/libvpx
                        test data, WPR archives (the last is large).
  --deps K=V,K=V        Set arbitrary .gclient custom_vars (DEPS variables),
                        e.g. --deps "checkout_clangd=True,checkout_wpr_archives=True".
                        Applied before sync; use --help to see common gates.
  --add-defender-exclusions
                        Add this download root to Windows Defender exclusions
                        (needs Administrator). Helps prevent Defender from
                        quarantining CIPD packages during fetch.
  --skip-fetch          Do not fetch; use an existing checkout.
  --skip-hooks          Do not run gclient hooks (skips toolchain download).
  --skip-build          Download/configure only, do not build.
  --depot-tools-only    Only clone + bootstrap depot_tools to a usable state
                        (git config, python/CIPD bootstrap) and stop; do NOT
                        download Chromium, sync deps, run hooks or build.
                        Combine with --dir to choose where it lands.
  --no-bootstrap-git    Never auto-download PortableGit.
  -h, --help            Show this help.

If PowerShell refuses to run this script:
  * "running scripts is disabled on this system"
        Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
    or launch via chromium_build_win.bat (which uses -ExecutionPolicy Bypass).
  * File came from the Internet / "not digitally signed"
        Unblock-File -Path .\chromium_build_win.ps1
  * ConstrainedLanguage / AppLocker / WDAC on a managed PC
        Scripting may be blocked by policy and can only be changed by an
        administrator; otherwise run on an unmanaged machine.
"@
}

if ($ShowHelp) { Show-Help; exit 0 }

# ---------------------------------------------------------------------------
#  Paths / constants
# ---------------------------------------------------------------------------
$Root       = $Root.TrimEnd('\', '/')
$DepotTools = Join-Path $Root 'depot_tools'
$Chromium   = Join-Path $Root 'chromium'
$Src        = Join-Path $Chromium 'src'
$ToolsDir   = Join-Path $Root 'tools'

$FetchBat     = Join-Path $DepotTools 'fetch.bat'
$GclientBat   = Join-Path $DepotTools 'gclient.bat'
$GnBat        = Join-Path $DepotTools 'gn.bat'
$AutoninjaBat = Join-Path $DepotTools 'autoninja.bat'

$DashApi  = 'https://chromiumdash.appspot.com/fetch_releases?channel=Stable&platform=Windows&num={0}'
$GitRepoUrl    = 'https://chromium.googlesource.com/chromium/tools/depot_tools.git'
$ChromiumUrl   = 'https://chromium.googlesource.com/chromium/src.git'

# ---------------------------------------------------------------------------
#  Console helpers
# ---------------------------------------------------------------------------
function Write-Step  { param([string]$Text) Write-Host "==> $Text" -ForegroundColor Cyan }
function Write-Ok    { param([string]$Text) Write-Host "    $Text" -ForegroundColor Green }
function Write-Warn2 { param([string]$Text) Write-Host "    $Text" -ForegroundColor Yellow }
function Write-Err   { param([string]$Text) Write-Host "    $Text" -ForegroundColor Red }

# ---------------------------------------------------------------------------
#  External process helper (throws on non-zero exit code)
# ---------------------------------------------------------------------------
function Invoke-Native {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [string[]]$ArgumentList = @(),
        [string]$WorkingDirectory
    )
    $display = "$FilePath $($ArgumentList -join ' ')"
    Write-Host "  > $display" -ForegroundColor DarkGray

    if ($WorkingDirectory) { Push-Location -LiteralPath $WorkingDirectory }
    try {
        & $FilePath @ArgumentList
    } finally {
        if ($WorkingDirectory) { Pop-Location }
    }

    if ($LASTEXITCODE -ne 0) {
        throw "Command failed with exit code $LASTEXITCODE`: $display"
    }
}

function Get-RemoteFile {
    param([Parameter(Mandatory = $true)][string]$Uri, [Parameter(Mandatory = $true)][string]$OutFile)
    Write-Host "  > download $Uri" -ForegroundColor DarkGray
    $old = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try {
        Invoke-WebRequest -UseBasicParsing -Uri $Uri -OutFile $OutFile -TimeoutSec 1800
    } finally {
        $ProgressPreference = $old
    }
}

# ---------------------------------------------------------------------------
#  Git bootstrap (portable Git, no system install required)
# ---------------------------------------------------------------------------
function Ensure-Git {
    if (Get-Command git -ErrorAction SilentlyContinue) {
        Write-Ok "Using git: $((Get-Command git).Source)"
        return
    }

    if (-not $BootstrapGit) {
        throw "git was not found. Install Git for Windows (https://git-scm.com/download/win) or drop --no-bootstrap-git."
    }

    Write-Step 'git not found - downloading PortableGit'
    $gitDir = Join-Path $ToolsDir 'git'
    $gitExe = Join-Path $gitDir 'cmd\git.exe'

    if (-not (Test-Path -LiteralPath $gitExe)) {
        New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
        $rel = Invoke-RestMethod -UseBasicParsing -TimeoutSec 60 `
            -Headers @{ 'User-Agent' = 'chromium-build-script' } `
            -Uri 'https://api.github.com/repos/git-for-windows/git/releases/latest'
        $asset = @($rel.assets | Where-Object { $_.name -match '^PortableGit-.*-64-bit\.7z\.exe$' })[0]
        if ($null -eq $asset) { throw 'Could not find a PortableGit 64-bit asset on GitHub.' }

        $dl = Join-Path $ToolsDir $asset.name
        if (-not (Test-Path -LiteralPath $dl)) {
            Get-RemoteFile -Uri $asset.browser_download_url -OutFile $dl
        }
        Write-Step "Extracting PortableGit into $gitDir"
        & $dl "-o$gitDir" -y | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "Failed to extract PortableGit (exit $LASTEXITCODE)." }
        if (-not (Test-Path -LiteralPath $gitExe)) { throw "PortableGit extraction incomplete: $gitExe not found." }
    }

    $env:PATH = "$(Join-Path $gitDir 'cmd');$(Join-Path $gitDir 'bin');$env:PATH"
    Write-Ok "Using portable git: $gitExe"
}

# ---------------------------------------------------------------------------
#  Optional Windows Defender exclusions (avoids quarantine of CIPD packages)
# ---------------------------------------------------------------------------
function Add-DefenderExclusions {
    if (-not (Get-Command Add-MpPreference -ErrorAction SilentlyContinue)) {
        Write-Warn2 'Windows Defender cmdlets are not available; skipping exclusions.'
        return
    }
    $paths = @($Root, $Chromium, (Join-Path $env:USERPROFILE '.cipd'))
    foreach ($p in $paths) {
        try {
            Add-MpPreference -ExclusionPath $p -ErrorAction Stop
            Write-Ok "Defender exclusion added: $p"
        } catch {
            Write-Warn2 "Could not add Defender exclusion for '$p' (run as Administrator): $($_.Exception.Message)"
        }
    }
}

# ---------------------------------------------------------------------------
#  Detect a locally installed Visual Studio with the MSVC C++ tools.
#  Required when DEPOT_TOOLS_WIN_TOOLCHAIN=0 (the external-user path, because
#  the prebuilt toolchain at gs://chrome-wintoolchain is Google-internal).
# ---------------------------------------------------------------------------
function Test-VisualStudio {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (Test-Path -LiteralPath $vswhere) {
        $out = & $vswhere -latest -products '*' `
            -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
            -property installationPath 2>$null
        if ($LASTEXITCODE -eq 0 -and $out) { return $true }
    }
    if ($env:VSINSTALLDIR -or $env:VCINSTALLDIR) { return $true }
    if (Test-Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\SxS\VS7') { return $true }
    return $false
}

# ---------------------------------------------------------------------------
#  Read the canonical toolchain hash from the checked-out Chromium revision.
#  vs_toolchain.py maps it to our own hash via GYP_MSVS_HASH_<canonical>.
# ---------------------------------------------------------------------------
function Get-CanonicalToolchainHash {
    $f = Join-Path $Src 'build\vs_toolchain.py'
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    $txt = Get-Content -LiteralPath $f -Raw
    if ($txt -match "TOOLCHAIN_HASH\s*=\s*'([0-9a-fA-F]+)'") { return $matches[1] }
    return $null
}

# ---------------------------------------------------------------------------
#  Version resolution via Chromium Dash
# ---------------------------------------------------------------------------
function Get-StableReleases {
    param([int]$Num = 50, [int]$Milestone = 0)
    $uri = $DashApi -f $Num
    if ($Milestone -gt 0) { $uri = "$uri&milestone=$Milestone" }
    try {
        $data = Invoke-RestMethod -UseBasicParsing -Uri $uri -TimeoutSec 60
    } catch {
        Write-Warn2 "Could not reach Chromium Dash: $($_.Exception.Message)"
        return @()
    }
    $list = @($data)
    if ($Milestone -gt 0) {
        $list = @($list | Where-Object { [int]$_.milestone -eq $Milestone })
    }
    return $list
}

function Resolve-RequestedVersion {
    param([string]$Requested)

    $r = $Requested.Trim()
    $resolved = [ordered]@{ Kind = 'main'; Ref = 'main'; Note = 'main branch' }

    if ($r -eq '' -or $r -match '^(stable|latest|release)$') {
        $rel = Get-StableReleases -Num 5
        if ($rel.Count -gt 0) {
            $resolved.Kind = 'tag'; $resolved.Ref = $rel[0].version; $resolved.Note = 'latest stable release'
        } else {
            $resolved.Note = 'stable lookup failed, using main'
        }
        return $resolved
    }

    # Exact release tag, e.g. 131.0.6778.85
    if ($r -match '^\d+\.\d+\.\d+\.\d+$') {
        $resolved.Kind = 'tag'; $resolved.Ref = $r; $resolved.Note = 'release tag'
        return $resolved
    }

    # A bare number is a Chromium branch number, e.g. 7871 -> refs/branch-heads/7871
    if ($r -match '^\d+$') {
        $resolved.Kind = 'branch'; $resolved.Ref = "refs/branch-heads/$r"; $resolved.Note = "branch-heads/$r"
        return $resolved
    }

    if ($r -match '^branch-heads/') {
        $resolved.Kind = 'branch'; $resolved.Ref = "refs/$r"; $resolved.Note = $r
        return $resolved
    }

    # main / beta / refs/heads/... / any other ref
    $resolved.Kind = 'branch'; $resolved.Ref = $r; $resolved.Note = 'branch/ref'
    return $resolved
}

function Resolve-Milestone {
    param([int]$Milestone)

    $resolved = [ordered]@{ Kind = 'tag'; Ref = 'main'; Note = '' }
    $rel = Get-StableReleases -Num 50 -Milestone $Milestone
    if ($rel.Count -gt 0) {
        $resolved.Ref = $rel[0].version
        $resolved.Note = "latest stable of milestone $Milestone"
        return $resolved
    }

    Write-Warn2 "Milestone $Milestone not found in the stable channel - falling back to latest stable."
    $rel = Get-StableReleases -Num 5
    if ($rel.Count -gt 0) {
        $resolved.Ref = $rel[0].version
        $resolved.Note = 'latest stable (milestone fallback)'
    } else {
        $resolved.Kind = 'main'; $resolved.Ref = 'main'; $resolved.Note = 'stable lookup failed, using main'
    }
    return $resolved
}

# ---------------------------------------------------------------------------
#  Check whether a ref actually exists upstream.
#  Uses the gitiles +log endpoint (tiny HTTP request, no git objects):
#    200 with a commit -> found
#    404               -> missing
#    anything else     -> unknown (network problem; do NOT treat as missing)
# ---------------------------------------------------------------------------
function Get-ChromiumRefStatus {
    param([Parameter(Mandatory = $true)][string]$Ref)
    $uri = 'https://chromium.googlesource.com/chromium/src/+log/' + $Ref + '?format=JSON&n=1'
    try {
        $resp = Invoke-WebRequest -UseBasicParsing -Uri $uri -TimeoutSec 60
        $json = ($resp.Content -replace "^\)\]\}'\s*", "") | ConvertFrom-Json
        if ($json.log -and @($json.log).Count -gt 0 -and $json.log[0].commit) { return 'found' }
        return 'unknown'
    } catch {
        $code = $null
        try { $code = [int]$_.Exception.Response.StatusCode } catch { $code = $null }
        if ($code -eq 404) { return 'missing' }
        return 'unknown'
    }
}

# ---------------------------------------------------------------------------
#  Check out a resolved revision + sync dependencies
# ---------------------------------------------------------------------------
function Set-ChromiumRevision {
    param([Parameter(Mandatory = $true)][System.Collections.IDictionary]$Resolved)

    if ($Resolved.Kind -eq 'main') { return }

    # IMPORTANT: do NOT use "gclient sync --revision src@<ref>". For the main
    # solution gclient ignores --no-history and runs a *full*
    # "git fetch origin --no-tags", pulling gigabytes of history (and stalling).
    # Instead we shallow-fetch + check out the requested revision ourselves,
    # then let gclient sync dependencies only. .gclient is unmanaged
    # (managed=False), so gclient leaves the src checkout we just made alone.

    # If src is missing entirely (fresh --pinned checkout), initialise a bare
    # repo so the shallow fetch below has somewhere to go.
    if (-not (Test-Path -LiteralPath (Join-Path $Src '.git'))) {
        Write-Step "Initializing $Src"
        New-Item -ItemType Directory -Force -Path $Src | Out-Null
        Invoke-Native -FilePath 'git' -ArgumentList @('-C', $Src, 'init')
        Invoke-Native -FilePath 'git' -ArgumentList @('-C', $Src, 'remote', 'add', 'origin', $ChromiumUrl)
    }

    # Shallow-fetch the exact ref (depth 1 keeps .git small).
    Write-Step "Shallow-fetching $($Resolved.Ref) (depth 1)"
    Invoke-Native -FilePath 'git' -ArgumentList @('-C', $Src, 'fetch', '--depth', '1', 'origin', $Resolved.Ref)

    # Detach HEAD onto exactly what we fetched.
    $sha = ((& git -C $Src rev-parse FETCH_HEAD 2>$null) | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or -not $sha) {
        throw "Could not resolve FETCH_HEAD for '$($Resolved.Ref)'."
    }
    Write-Step "Checking out $sha ($($Resolved.Ref))"
    Invoke-Native -FilePath 'git' -ArgumentList @('-C', $Src, 'checkout', '--detach', $sha)

    # Provide a LOCAL default-branch ref. With an unmanaged solution gclient
    # still calls GetRemoteHeadRef() before it decides to skip src; without a
    # local refs/remotes/origin/HEAD it runs "git remote set-head -a origin",
    # a network round trip that can hang. Point origin/main at the commit we
    # just checked out so the lookup resolves locally.
    Invoke-Native -FilePath 'git' -ArgumentList @('-C', $Src, 'update-ref', 'refs/remotes/origin/main', $sha)
    Invoke-Native -FilePath 'git' -ArgumentList @('-C', $Src, 'symbolic-ref', 'refs/remotes/origin/HEAD', 'refs/remotes/origin/main')

    # Now sync dependencies for the checked-out revision. No --revision here, so
    # gclient only updates the DEPS sub-repos (shallow) and never re-fetches src.
    # --with_branch_heads / --with_tags fetch every branch/tag and can be huge,
    # so they stay opt-in.
    $syncArgs = @('sync', '--nohooks', '--no-history')
    if ($WithTags -and $Resolved.Kind -eq 'tag') { $syncArgs += '--with_tags' }
    if ($WithBranchHeads -and $Resolved.Kind -eq 'branch') { $syncArgs += '--with_branch_heads' }

    # gclient sync can fail on transient dependency errors (e.g. HTTP 429 on a
    # third_party repo), so retry a few times before giving up.
    Write-Step "Syncing dependencies for $($Resolved.Ref)"
    $attempts = $Retries + 1
    for ($attempt = 1; $attempt -le $attempts; $attempt++) {
        try {
            Invoke-Native -FilePath $GclientBat -ArgumentList $syncArgs -WorkingDirectory $Chromium
            break
        } catch {
            if ($attempt -lt $attempts) {
                $wait = 30 * $attempt
                Write-Warn2 "sync attempt $attempt/$attempts failed; retrying in $wait s..."
                Write-Warn2 '(dependency fetches are often rate-limited; this is usually transient.)'
                Start-Sleep -Seconds $wait
                continue
            }
            throw
        }
    }

    Write-Ok "Now at revision: $($Resolved.Ref)"
}

# ---------------------------------------------------------------------------
#  Optional dependency gates.
#
#  Chromium gates many extra downloads behind DEPS variables that default to
#  False (see the "vars" block in //DEPS). A plain "gclient sync" does NOT
#  download them, so enable the ones you may need while you still have Internet
#  access - handy when the build machine is later offline.
#
#    --pgo        -> checkout_pgo_profiles
#    --full-deps  -> the curated Windows dev/test set below
#    --deps k=v   -> any raw variable (e.g. --deps checkout_clangd=True)
#
#  Intentionally NOT auto-enabled: Google-internal gates
#  (checkout_src_internal / checkout_google_internal), Googler-only captured
#  site test data (checkout_chromium_*_test_dependencies), other platforms
#  (checkout_android / fuchsia / chromeos / ios), and
#  checkout_telemetry_dependencies (partly private).
# ---------------------------------------------------------------------------
function Get-RequestedCustomVars {
    $vars = [ordered]@{}

    # --full-deps: a self-contained Windows development/test environment.
    if ($FullDeps) {
        $vars['checkout_clang_tidy']            = 'True'  # clang-tidy beside clang
        $vars['checkout_clangd']                = 'True'  # clangd language server
        $vars['checkout_clang_coverage_tools']  = 'True'  # llvm-cov / llvm-profdata
        $vars['checkout_pgo_profiles']          = 'True'  # Windows PGO profiles
        $vars['checkout_bazelisk']              = 'True'  # for rust-toolchain packaging
        $vars['download_libaom_testdata']       = 'True'  # AV1 codec test data
        $vars['download_libvpx_testdata']       = 'True'  # VP8/VP9 codec test data
        $vars['checkout_wpr_archives']          = 'True'  # web page replay archives (large)
    }

    # --pgo (also implied by --full-deps).
    if ($Pgo) {
        $vars['checkout_pgo_profiles'] = 'True'
    }

    # --deps key=value,key=value  -> raw custom_vars overrides.
    if ($DepsRaw) {
        foreach ($pair in ($DepsRaw -split ',')) {
            $p = $pair.Trim()
            if (-not $p) { continue }
            if ($p -notmatch '=') {
                Write-Warning "Ignoring --deps entry without '=': $p"
                continue
            }
            $kv = $p -split '=', 2
            $vars[$kv[0].Trim()] = $kv[1].Trim()
        }
    }

    return $vars
}

# ---------------------------------------------------------------------------
#  Write the requested variables into the .gclient "custom_vars" section.
#  gclient's "config" command accepts repeated --custom-var key=value flags and
#  rewrites .gclient. This MUST run before the gclient sync that installs the
#  matching deps (and before runhooks for hook-based ones like PGO).
# ---------------------------------------------------------------------------
function Set-GclientCustomVars {
    param([Parameter(Mandatory = $true)][System.Collections.IDictionary]$Vars)
    if ($Vars.Count -eq 0) { return }

    $gclientFile = Join-Path $Chromium '.gclient'
    $content = ''
    if (Test-Path -LiteralPath $gclientFile) {
        $content = Get-Content -LiteralPath $gclientFile -Raw
    }

    $pending = @()
    foreach ($key in $Vars.Keys) {
        if ($content -notmatch $key) { $pending += $key }
    }
    if ($pending.Count -eq 0) {
        Write-Ok '.gclient already has all requested custom_vars.'
        return
    }

    Write-Step ('Enabling .gclient custom_vars: ' + (($pending | Sort-Object) -join ', '))
    $cfgArgs = @('config', '--name', 'src')
    foreach ($key in ($Vars.Keys | Sort-Object)) {
        $cfgArgs += @('--custom-var', ('{0}={1}' -f $key, $Vars[$key]))
    }
    $cfgArgs += $ChromiumUrl
    Invoke-Native -FilePath $GclientBat -ArgumentList $cfgArgs -WorkingDirectory $Chromium
}

# ---------------------------------------------------------------------------
#  Remove leftover git temporary packs (tmp_pack_* etc.)
#  These are written while git fetches/repacks. A completed fetch renames them
#  into pack-*; if a fetch was interrupted/crashed they are left behind, are
#  never read by later git commands, and can be many GB. Windows file locking
#  protects a pack that is still being written (Remove-Item then fails safely).
# ---------------------------------------------------------------------------
function Remove-StaleTmpPacks {
    $packDir = Join-Path $Src '.git\objects\pack'
    if (-not (Test-Path -LiteralPath $packDir)) { return }
    $tmp = @(Get-ChildItem -LiteralPath $packDir -File -Filter 'tmp_*' -ErrorAction SilentlyContinue)
    if ($tmp.Count -eq 0) { return }
    foreach ($f in $tmp) {
        try {
            $sizeGb = $f.Length / 1GB
            Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop
            Write-Ok ('Removed stale temp pack {0} ({1:N2} GB)' -f $f.Name, $sizeGb)
        } catch {
            Write-Warn2 "Left in place (probably still in use): $($f.Name)"
        }
    }
}

# ===========================================================================
#  Main
# ===========================================================================
# Resolve --win-toolchain=auto. The prebuilt toolchain (gs://chrome-wintoolchain)
# is Google-internal and NOT anonymously downloadable, so external users must use
# a locally installed Visual Studio (0). Prefer that when VS is present.
if ($WinToolchain -eq 'auto') {
    if (Test-VisualStudio) {
        $WinToolchain = '0'
        Write-Ok 'Visual Studio found -> DEPOT_TOOLS_WIN_TOOLCHAIN=0 (local VS).'
    } else {
        $WinToolchain = '1'
        Write-Warn2 'No Visual Studio found -> trying DEPOT_TOOLS_WIN_TOOLCHAIN=1 (Google-internal toolchain).'
    }
}
if ($WinToolchain -eq '0' -and -not (Test-VisualStudio)) {
    Write-Warn2 'DEPOT_TOOLS_WIN_TOOLCHAIN=0 requires Visual Studio, but none was found.'
    Write-Warn2 'Install Visual Studio 2026 (or Build Tools) with "Desktop development'
    Write-Warn2 'with C++" and the "MFC/ATL" component, then re-run.'
}
if ($WinToolchain -eq '1' -and -not (Test-VisualStudio) -and -not $WinToolchainUrl) {
    Write-Warn2 'DEPOT_TOOLS_WIN_TOOLCHAIN=1 downloads a Google-internal prebuilt toolchain'
    Write-Warn2 'and only works on Google''s internal network. External users should install'
    Write-Warn2 'Visual Studio and use --win-toolchain 0, or provide --win-toolchain-url.'
}

Write-Host '============================================================================'
Write-Host ' Chromium Windows build'
Write-Host '============================================================================'
Write-Host " Root        : $Root"
Write-Host " depot_tools : $DepotTools"
Write-Host " Source      : $Src"
Write-Host " Build dir   : $BuildDir"
Write-Host " Version     : $VersionReq"
Write-Host " Targets     : $($Targets -join ', ')"
Write-Host " History     : shallow (--no-history, depth 1)"
Write-Host " Config      : $(if ($Release) { 'release' } else { 'debug' })"
Write-Host " Pinned      : $(if ($Pinned) { 'yes (fetch only this revision)' } else { 'no (fetch main, then switch)' })"
Write-Host " PGO         : $(if ($Pgo) { 'enabled (download profiles + chrome_pgo_phase=2)' } else { 'disabled' })"
Write-Host " Arch        : $(if ($Arch) { $Arch } else { 'host default (x64)' })"
Write-Host " WinToolchain: DEPOT_TOOLS_WIN_TOOLCHAIN=$WinToolchain"
Write-Host '============================================================================'

if ($Root -match '\s') {
    Write-Warn2 "WARNING: the path '$Root' contains spaces. Chromium builds can fail with spaces in the path."
}

# ---- 1. git -----------------------------------------------------------------
Write-Step 'Checking for git'
Ensure-Git

if ($AddDefenderExclusions) {
    Write-Step 'Adding Windows Defender exclusions'
    Add-DefenderExclusions
}

# ---- 2. root directory ------------------------------------------------------
New-Item -ItemType Directory -Force -Path $Root | Out-Null

# ---- 3. depot_tools ---------------------------------------------------------
Write-Step 'Cloning depot_tools (if needed)'
if (-not (Test-Path -LiteralPath (Join-Path $DepotTools 'gclient.bat'))) {
    # Shallow clone keeps depot_tools' .git small as well.
    Invoke-Native -FilePath 'git' -ArgumentList @('clone', '--depth', '1', $GitRepoUrl, $DepotTools)
} else {
    Write-Ok 'depot_tools already present.'
}

# ---- 4. git configuration ---------------------------------------------------
Write-Step 'Configuring git'
Invoke-Native -FilePath 'git' -ArgumentList @('config', '--global', 'core.autocrlf', 'false')
Invoke-Native -FilePath 'git' -ArgumentList @('config', '--global', 'core.filemode', 'false')
Invoke-Native -FilePath 'git' -ArgumentList @('config', '--global', 'core.longpaths', 'true')
# Recommended by depot_tools (also silences its nag message).
Invoke-Native -FilePath 'git' -ArgumentList @('config', '--global', 'core.fscache', 'true')
Invoke-Native -FilePath 'git' -ArgumentList @('config', '--global', 'core.preloadindex', 'true')

# ---- 5. environment ---------------------------------------------------------
# depot_tools must be at the FRONT of PATH.
$env:PATH = "$DepotTools;$env:PATH"
# 1 = prebuilt win_toolchain (internal bucket, or a mirror via the URL below);
# 0 = use a locally installed Visual Studio.
$env:DEPOT_TOOLS_WIN_TOOLCHAIN = $WinToolchain
if ($WinToolchainUrl) {
    # get_toolchain_if_necessary.py accepts a directory that contains
    # "<toolchain-hash>.zip", either a local path (file://) or an http(s) URL.
    $u = $WinToolchainUrl
    if ($u -match '^file://') {
        $u = $u.Substring(7)
        if ($u -match '^/[A-Za-z]:') { $u = $u.Substring(1) }   # file:///D:/ -> D:/
    } elseif ($u -match '^https?://' -and -not $u.EndsWith('/')) {
        $u = "$u/"
    }
    $env:DEPOT_TOOLS_WIN_TOOLCHAIN_BASE_URL = $u
    Write-Ok "Win toolchain archive base URL: $u"
    if ($u -notmatch '^https?://') { $ToolchainUrlLocalDir = $u }   # local dir -> can auto-detect the zip
}

# ---- 6. bootstrap depot_tools (downloads python, etc.) ----------------------
Write-Step 'Initializing gclient (first run bootstraps python etc.)'
Invoke-Native -FilePath $GclientBat -ArgumentList @()

# ---- 6b. stop here for --depot-tools-only -----------------------------------
# depot_tools is now cloned, configured and bootstrapped (python/CIPD). Nothing
# else is downloaded. Print how to use it and exit.
if ($DepotToolsOnly) {
    Write-Host ''
    Write-Host '============================================================================'
    Write-Host ' depot_tools is ready'
    Write-Host '============================================================================'
    Write-Host " Location : $DepotTools"
    Write-Host " gclient  : $GclientBat"
    Write-Host ''
    Write-Host ' To use it in your own shell (cmd.exe):'
    Write-Host "   set PATH=$DepotTools;%PATH%"
    Write-Host '   set DEPOT_TOOLS_WIN_TOOLCHAIN=1     & rem (or 0 to use local VS)'
    Write-Host ' (PowerShell)'
    Write-Host "   `$env:PATH = `"$DepotTools;`$env:PATH`""
    Write-Host '   gclient'
    Write-Host ''
    Write-Host ' Then, to get Chromium later, run this script WITHOUT --depot-tools-only,'
    Write-Host ' or:  mkdir <root>\chromium && fetch --nohooks --no-history chromium'
    Write-Host '============================================================================'
    exit 0
}

# ---- 7. resolve requested version (before fetch: needed by --pinned) --------
if ($MilestoneReq) {
    $resolved = Resolve-Milestone -Milestone ([int]$MilestoneReq)
    Write-Step "Resolved milestone '$MilestoneReq' -> $($resolved.Ref) [$($resolved.Note)]"
} else {
    $resolved = Resolve-RequestedVersion -Requested $VersionReq
    Write-Step "Resolved version '$VersionReq' -> $($resolved.Ref) [$($resolved.Note)]"
}

# ---- 8. fetch source --------------------------------------------------------
# A checkout is only "present" if BOTH .gclient and the src directory exist.
# (.gclient can remain after src is deleted, e.g. when starting over for a
# minimal pinned checkout.)
$hasGclient = Test-Path -LiteralPath (Join-Path $Chromium '.gclient')
$hasSrc     = Test-Path -LiteralPath $Src

if ($hasGclient -and $hasSrc) {
    Write-Ok 'Chromium source already present, skipping fetch.'
} elseif ($SkipFetch) {
    throw "Source directory not found: $Src (and --skip-fetch was given)."
} elseif ($hasGclient -and -not $hasSrc) {
    Write-Ok 'Existing .gclient found but src is missing; gclient sync will recreate it.'
} else {
    New-Item -ItemType Directory -Force -Path $Chromium | Out-Null
    if ($Pinned) {
        # Smallest .git: configure gclient, then sync ONLY the requested
        # revision (no intermediate shallow sync of main).
        Write-Step 'Configuring gclient for a single pinned checkout'
        Invoke-Native -FilePath $GclientBat -ArgumentList @('config', '--name', 'src', $ChromiumUrl) -WorkingDirectory $Chromium
    } else {
        Write-Step 'Fetching Chromium source (this can take a very long time)'
        # --no-history = shallow (depth 1) checkout: smallest possible .git
        $fetchArgs = @('--nohooks', '--no-history', 'chromium')
        $attempts = $Retries + 1
        for ($attempt = 1; $attempt -le $attempts; $attempt++) {
            try {
                Invoke-Native -FilePath $FetchBat -ArgumentList $fetchArgs -WorkingDirectory $Chromium
                break
            } catch {
                if ($attempt -lt $attempts) {
                    $wait = 30 * $attempt
                    Write-Warn2 "fetch attempt $attempt/$attempts failed; retrying in $wait s..."
                    Write-Warn2 '(HTTP 429 rate limiting and network hiccups are usually transient.)'
                    Start-Sleep -Seconds $wait
                    continue
                }
                Write-Host ''
                Write-Warn2 'fetch failed. Common causes:'
                Write-Warn2 '  * Google source servers rate-limited you:'
                Write-Warn2 '    "RESOURCE_EXHAUSTED ... HTTP 429" / "expected packfile"'
                Write-Warn2 '  * a download stalled (look for "STALL DETECTED")'
                Write-Warn2 '  * Windows Defender quarantined a CIPD package:'
                Write-Warn2 '    "contains a virus or potentially unwanted software"'
                Write-Warn2 '  * flaky network / proxy / disk space'
                Write-Host ''
                Write-Warn2 'You can simply re-run this script: an existing .gclient makes it'
                Write-Warn2 'resume with "gclient sync" instead of fetching from scratch.'
                Write-Warn2 'For Defender, run as Administrator:'
                Write-Warn2 "  Add-MpPreference -ExclusionPath `"$Root`""
                Write-Warn2 'or re-run with --add-defender-exclusions. Manual resume:'
                Write-Warn2 "  cd `"$Src`"; gclient sync --nohooks --no-history"
                throw
            }
        }
    }
}

# Leftover git temp packs from an interrupted fetch are never reused - drop them.
# (No-op when src does not exist yet; gclient sync will create it below.)
Remove-StaleTmpPacks

# ---- 9. enable optional dependency gates (before sync / runhooks) -----------
# Writing custom_vars before the sync makes gclient fetch the extra deps now,
# while the network is available.
Set-GclientCustomVars -Vars (Get-RequestedCustomVars)

# ---- 10. apply the requested revision ---------------------------------------
if ($resolved.Kind -eq 'main') {
    # Complete/repair the checkout (also recovers from a previous aborted fetch).
    if (-not $SkipFetch) {
        Write-Step 'Syncing dependencies (gclient sync --nohooks --no-history)'
        Invoke-Native -FilePath $GclientBat -ArgumentList @('sync', '--nohooks', '--no-history') -WorkingDirectory $Chromium
    }
} else {
    # Only fall back to the latest stable when the requested ref truly does not
    # exist upstream. A failed sync (e.g. transient HTTP 429 on a dependency)
    # must NOT silently change the requested version.
    $status = Get-ChromiumRefStatus -Ref $resolved.Ref
    Write-Ok "Revision check: $($resolved.Ref) -> $status upstream"

    if ($status -eq 'missing') {
        Write-Warn2 "Revision '$($resolved.Ref)' does not exist upstream - falling back to latest stable."
        $fallback = Resolve-RequestedVersion -Requested 'stable'
        if ($fallback.Ref -ne $resolved.Ref -and (Get-ChromiumRefStatus -Ref $fallback.Ref) -eq 'found') {
            Set-ChromiumRevision -Resolved $fallback
            $resolved = $fallback
            Write-Ok "Checked out fallback $($resolved.Ref)"
        } else {
            throw "Requested revision '$($resolved.Ref)' was not found and no fallback is available."
        }
    } else {
        try {
            Set-ChromiumRevision -Resolved $resolved
            Write-Ok "Checked out $($resolved.Ref)"
        } catch {
            Write-Warn2 "Sync of '$($resolved.Ref)' failed: $($_.Exception.Message)"
            if ($status -eq 'unknown') {
                Write-Warn2 'The revision could not be verified (network problem?).'
            } else {
                Write-Warn2 'The revision DOES exist - this was most likely a transient'
                Write-Warn2 'failure (HTTP 429 rate limiting / network). The version was NOT'
                Write-Warn2 'changed. Simply re-run this script to resume.'
            }
            throw
        }
    }
}

if ($RunGc) {
    Write-Step 'Running git gc (prunes unreachable objects to shrink .git)'
    Invoke-Native -FilePath 'git' -ArgumentList @('-C', $Src, 'gc', '--prune=now')
}

# ---- map a self-built toolchain archive to the canonical hash ---------------
# Chromium's build/vs_toolchain.py does:
#   os.environ.get('GYP_MSVS_HASH_' + TOOLCHAIN_HASH, TOOLCHAIN_HASH)
# so a locally packaged archive (<local-hash>.zip) can satisfy the canonical
# <TOOLCHAIN_HASH>.zip request. With a local --win-toolchain-url directory the
# local hash is auto-detected; for http pass --win-toolchain-hash explicitly.
if ($WinToolchainUrl) {
    $localHash = $WinToolchainHash
    if (-not $localHash -and $ToolchainUrlLocalDir -and (Test-Path -LiteralPath $ToolchainUrlLocalDir -PathType Container)) {
        $zips = @(Get-ChildItem -LiteralPath $ToolchainUrlLocalDir -Filter '*.zip' -File -ErrorAction SilentlyContinue)
        if ($zips.Count -eq 1) {
            $localHash = $zips[0].BaseName
        } elseif ($zips.Count -gt 1) {
            Write-Warn2 "Multiple .zip files found in $ToolchainUrlLocalDir; pass --win-toolchain-hash."
        }
    }
    if ($localHash) {
        $canonical = Get-CanonicalToolchainHash
        if ($canonical) {
            Set-Item -Path ("Env:GYP_MSVS_HASH_" + $canonical) -Value $localHash
            Write-Ok "Toolchain hash mapping: GYP_MSVS_HASH_$canonical=$localHash"
        } else {
            Write-Warn2 'Could not read TOOLCHAIN_HASH from build/vs_toolchain.py.'
            Write-Warn2 'Set GYP_MSVS_HASH_<canonical> manually if the download 404s.'
        }
    }
}

# ---- hooks -> download complete toolchain (+ PGO profiles when enabled) -----
if (-not $SkipHooks) {
    Write-Step 'Running gclient runhooks (downloads the complete win_toolchain)'
    # The first vpython venv build is occasionally blocked/rolled back by
    # antivirus, so retry like the other network steps.
    $attempts = $Retries + 1
    for ($attempt = 1; $attempt -le $attempts; $attempt++) {
        try {
            Invoke-Native -FilePath $GclientBat -ArgumentList @('runhooks') -WorkingDirectory $Src
            break
        } catch {
            if ($attempt -lt $attempts) {
                $wait = 30 * $attempt
                Write-Warn2 "runhooks attempt $attempt/$attempts failed; retrying in $wait s..."
                Start-Sleep -Seconds $wait
                continue
            }
            Write-Host ''
            Write-Warn2 'gclient runhooks failed. Common causes:'
            Write-Warn2 '  * "401"/"403" or "chrome-wintoolchain": the prebuilt toolchain is'
            Write-Warn2 '    Google-internal. Install Visual Studio / Build Tools with'
            Write-Warn2 '    "Desktop development with C++" + "MFC/ATL", then run with'
            Write-Warn2 '    --win-toolchain 0.'
            Write-Warn2 '  * vpython/venv creation error: usually transient; re-run the script.'
            throw
        }
    }
} else {
    Write-Warn2 'Skipping gclient runhooks (--skip-hooks). The toolchain may be missing.'
}

if ($SkipBuild) {
    Write-Host ''
    Write-Ok 'Skipping build (--skip-build). Checkout is ready.'
    exit 0
}

# ---- 10. GN generate --------------------------------------------------------
$gnArgs = @()
if ($Release) { $gnArgs += 'is_debug=false' }
# target_cpu selects the output CPU. On an x64 host, "x64" is the default; "x86"
# and "arm64" cross-compile (the downloaded toolchain ships ARM64 libraries).
# target_os stays "win" because we run on Windows. Don't duplicate a user value.
if ($Arch -and ($ExtraGnArgs -notmatch 'target_cpu')) {
    $gnArgs += ('target_cpu="{0}"' -f $Arch)
}
# chrome_pgo_phase=2 tells the compiler to consume the downloaded profiles.
# pgo.gni defaults it to 2 only for is_official_build; setting it explicitly
# lets a non-official release build use PGO too. Don't duplicate a user value.
if ($Pgo -and ($ExtraGnArgs -notmatch 'chrome_pgo_phase')) {
    $gnArgs += 'chrome_pgo_phase=2'
}
if ($ExtraGnArgs) { $gnArgs += $ExtraGnArgs }
$gnArgString = ($gnArgs -join ' ')

Write-Step 'Generating build files with gn'
if (-not $gnArgString) {
    Invoke-Native -FilePath $GnBat -ArgumentList @('gen', $BuildDir) -WorkingDirectory $Src
} else {
    Write-Ok "GN args: $gnArgString"
    Invoke-Native -FilePath $GnBat -ArgumentList @('gen', $BuildDir, "--args=$gnArgString") -WorkingDirectory $Src
}

# ---- 11. build each target --------------------------------------------------
$results = [ordered]@{}
$failed = 0

foreach ($target in $Targets) {
    Write-Step "Building target: $target"
    $ninjaArgs = @('-C', $BuildDir)
    if ($Jobs -gt 0) { $ninjaArgs += @('-j', [string]$Jobs) }
    $ninjaArgs += $target
    try {
        Invoke-Native -FilePath $AutoninjaBat -ArgumentList $ninjaArgs -WorkingDirectory $Src
        $results[$target] = 'OK'
        Write-Ok "Built $target"
    } catch {
        $results[$target] = 'FAILED'
        $failed++
        Write-Warn2 "Target '$target' failed: $($_.Exception.Message)"
    }
}

# ---- 12. summary ------------------------------------------------------------
Write-Host ''
Write-Host '============================================================================'
Write-Host ' Build summary'
Write-Host '============================================================================'
# Iterate keys (property access) instead of GetEnumerator() - method calls on
# non-core types are blocked in ConstrainedLanguage mode.
foreach ($key in @($results.Keys)) {
    $value = $results[$key]
    $color = if ($value -eq 'OK') { 'Green' } else { 'Red' }
    Write-Host ("  {0,-16} {1}" -f $key, $value) -ForegroundColor $color
}
Write-Host " Revision: $($resolved.Ref)"
Write-Host " Output  : $Src\$BuildDir"
Write-Host '============================================================================'

if ($failed -gt 0) { exit 1 }
exit 0
